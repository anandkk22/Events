export const environment = {
  production: true,
  hmr: false,
  serverUrl: '/api',
  SERVER_API_URL: 'http://localhost:8082/',
  SERVER_URL :"http://localhost:9000",
  defaultLanguage: 'en-US',
  supportedLanguages: ['en-US', 'fr-FR']
};
