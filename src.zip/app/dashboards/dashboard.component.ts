import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
    selector: 'app-dashoboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class Dashboard implements OnInit {
    todaysDate = new Date();
    showDashaboard: boolean = false;
    constructor(private _router: Router){}

    ngOnInit() {

    }

    showDashboard() {
        this.showDashaboard = !this.showDashaboard
    }

    categoryPage(){
        console.log("*********");
        this._router.navigate(['/category'])
    }
}