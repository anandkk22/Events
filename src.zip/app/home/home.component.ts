import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoginService } from '../core/login/login.service';

@Component({
    selector: 'jhi-home',
    templateUrl: './home.component.html',
    styleUrls: ['home.scss']
})
export class HomeComponent implements OnInit {
    account: Account;
    authenticationError = false;
    usernameBlock = true;
    passwordBlock = false;
    completeForgotPassword = false;
    forgotPasswordBlock = false;
    changePasswordSuccess = false;
    changePasswordError = false;
    sendOtpError = false;
    sendOtpErrorMsg = '';
    changePasswordErrorMsg = '';
    username = '';
    password = '';
    emailId = '';
    otp = '';
    currRole = null;
    currentYear: number = new Date().getFullYear();
    userFilter: any = { iconText: '' };
    permissions = [];
    permissionStatus: boolean;
    accessStatus: boolean;
    durationInSeconds = 2;
    rNewPassword: any;
    hide: boolean;
    emailCondition: boolean;
    blob: Blob;
    logoToShow: any;
    userProfile: any;
    loginErrorMsg: string;
    accountInfo: any;
    auth: boolean;
    errorMsg: boolean = false;
    passErrorMsg:  boolean = false;
    menuDashBoard: any[] = [
        // {
        //     link: 'portfolio-base/portfolio',
        //     icon: 'icon apo-icon-portfolio-selected home-icons-yellow',
        //     toolTip: [
        //         // tslint:disable-next-line:max-line-length
        //         'One stop overview of your plants.'
        //     ],
        //     iconText: 'Portfolio',
        //     id: 'Portfolio',
        //     permissionCode: [permissionCodes.PORTFOLIO_MGMT_R],
        //     menuType: 'user'
        // },
        {
            link: 'portfolio-base/roc-base/remote-monitoring',
            icon: 'icon apo-icon-command-center home-icons-yellow',
            toolTip: ['Receive latest operations status of your plant and assets.'],
            iconText: 'RoC',
            id: 'roc',
            // permissionCode: [permissionCodes.ROC_R],
            menuType: 'user'
        },
        {
            link: 'portfolio-base/events',
            icon: 'icon apo-icon-events-selected home-icons-yellow',
            toolTip: [
                // tslint:disable-next-line:max-line-length
                'Get realtime updates on the alarms.'
            ],
            iconText: 'Event',
            id: 'Events',
            // permissionCode: [permissionCodes.EVENT_MGMT_R],
            menuType: 'user'
        },

    ];

    constructor(private http: HttpClient, private route: Router, private loginService: LoginService) {
        this.hide = true;
        this.emailCondition = false;
        this.username = '';
        this.password = '';
        this.auth = false;
        this.errorMsg = false;
        this.passErrorMsg= false;
    }

    ngOnInit() {
        // window.location.reload();

        this.accessStatus = true;
    }
    show_password_block() {
        this.passwordBlock = true;
        this.usernameBlock = false;
        this.forgotPasswordBlock = false;
        this.completeForgotPassword = false;
        this.errorMsg = true;
    }

    // back
    show_username_block() {
        this.passwordBlock = false;
        this.usernameBlock = true;
        this.forgotPasswordBlock = false;
        this.completeForgotPassword = false;
        this.sendOtpError = false;
        this.changePasswordSuccess = false;
        this.changePasswordError = false;
        if (this.authenticationError === true) {
            // this.hideErrMessage = true;
        }
    }

    show_forgot_password_block() {
        this.forgotPasswordBlock = true;
        this.usernameBlock = false;
        this.passwordBlock = false;
        this.completeForgotPassword = false;
    }

    show_complete_forgot_password_block() {
        this.completeForgotPassword = true;
        this.forgotPasswordBlock = false;
        this.usernameBlock = false;
        this.passwordBlock = false;
    }

    login() {
        console.log(this.username, this.password);
        this.loginService.login({
            username: this.username,
            password: this.password,
            rememberMe: true
        }).subscribe((result) => {
            console.log("result", result);
            if (result != null) {
                this.route.navigate(['category']);
                // this.isAuthenticated()
            }
        });

        this.passErrorMsg= true;
    }

    isAuthenticated() {
        this.auth = true;
    }

}
