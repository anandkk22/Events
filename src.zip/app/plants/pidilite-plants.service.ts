import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { pidiliteMainModel } from '../models/pidilite-model';
import { environment } from '../../environments/environment';
import { CustomerTypeModel } from '../models/customerType.model';
import { segmentModel } from '../models/segment.model';
import { subSiteTypeModel } from '../models/subSiteTypeModel';
import { subSegmentModel } from '../models/subSegmentModel';
import { customerType } from '../models/customerTypeModel';
import { OrgTypeModel } from '../models/orgTypeModel';

@Injectable({ providedIn: 'root' })
export class PidilitePlantsService {

    public planturl: string = environment.PROCESS_API_URL + 'api/plant'; 
    public listofPlantUrl: string = environment.PROCESS_API_URL + 'api/plant/org/3';
    public deletePlantUrl: string = environment.PROCESS_API_URL + 'api/plant';
    public addPlantUrl: string = environment.PROCESS_API_URL + 'api/plant';
    public segmentUlr: string = environment.PROCESS_API_URL + 'api/segment';
    public subSegmentUlr: string = environment.PROCESS_API_URL + 'api/subsegment';
    public subSiteTypeUlr: string = environment.PROCESS_API_URL + 'api/SubSiteType';
    public customerTypeUlr: string = environment.PROCESS_API_URL + 'api/customerType';
    public orgTypeUrl: string = environment.PROCESS_API_URL + 'api/org/type/';
    public getPlantAssetUrl: string = environment.PROCESS_API_URL + 'api/plant/asset';

    constructor(private _http: HttpClient) { }

    getPlantById(id: number): Observable<pidiliteMainModel>{
        return this._http.get<pidiliteMainModel>(`${this.planturl}/${id}`)
        
    }

    getListofPlant(): Observable<pidiliteMainModel[]> {
        return this._http.get<pidiliteMainModel[]>(this.listofPlantUrl)
    }
    
    addPlant(plant: pidiliteMainModel): Observable<pidiliteMainModel> {
        console.log(this.addPlantUrl)
        return this._http.post<pidiliteMainModel>(`${this.addPlantUrl}`, plant, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updatePlant(plant:pidiliteMainModel): Observable<void> {
        return this._http.put<void>(`${this.addPlantUrl}`, plant, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deletePlant(id: number): Observable<void> {
        return this._http.delete<void>(`${this.deletePlantUrl}/${id}`)
        .pipe(catchError(this.handleError))
    }  
    
    getSegments(): Observable<segmentModel[]>{
        return this._http.get<segmentModel[]>(this.segmentUlr);
    }

    getSubSegments(): Observable<subSegmentModel[]>{
        return this._http.get<subSegmentModel[]>(this.subSegmentUlr);
    }

    getSubSiteType(): Observable<subSiteTypeModel[]>{
        return this._http.get<subSiteTypeModel[]>(this.subSiteTypeUlr);
    }

    getCustomerType(): Observable<customerType[]>{
        return this._http.get<customerType[]>(this.customerTypeUlr);
    }

    getOrgType(code): Observable<OrgTypeModel[]>{
        return this._http.get<OrgTypeModel[]>(this.orgTypeUrl + code);
    }
    
    getPlantAssetDetails(id: number): Observable<any> {
        return this._http.get<any>(`${this.getPlantAssetUrl}/${id}`)
    }    

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }   

}