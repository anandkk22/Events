import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { MoldMasterService } from 'src/app/product-configurator/mold-master/moldmaster.service';
import { ProductionLineService } from '../production-line/production-line.service';
import { InjectionMoldingMachineRelationshipComponent } from './injection-molding-machine-relationship';
import { InjectionMoldingMachineModel, MoldMaster } from './injection-molding-machine.model';
import { InjectionMoldingMachineService } from './injection-molding-machine.service';

@Component({
  selector: 'app-injection-molding-machine',
  templateUrl: './injection-molding-machine.component.html',
  styleUrls: ['../plant-configuration.component.scss']
})
export class InjectionMoldingMachineComponent implements OnInit {

  injectionMoldingMachineList: InjectionMoldingMachineModel[];
  injectionMoldingMachineConfig: InjectionMoldingMachineModel = {};
  injectionMoldingMachine: InjectionMoldingMachineModel;
  hideForm: boolean = true;
  prodLineList: any = [];
  typeList: any = []
  moldMasterList: any = []
  moldListName: any = []
  allowedMolds = new FormControl();
  maxDate = moment(new Date()).format('YYYY-MM-DD')
  $localInjectionMoldingMachineId: any;
  //moldMasterList: any = []

  constructor(private injectionMoldingMachineService: InjectionMoldingMachineService, private prodLineService: ProductionLineService, private moldMasterService: MoldMasterService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {


    this.injectionMoldingMachineService.getAllInjectionMoldingMachines().subscribe(injectionMold => {

      console.log("resp is", injectionMold)
      if (injectionMold instanceof Array)
        this.injectionMoldingMachineList = injectionMold
      console.log("cnc machine list is", this.injectionMoldingMachineList)
    })

    this.prodLineService.getAllProductionLines().subscribe(resp => {
      this.prodLineList = resp
    })

    this.injectionMoldingMachineService.getInjMachineType().subscribe(resp => {
      this.typeList = resp;
    })

    this.moldMasterService.getListofMoldMaster().subscribe(resp => {
      this.moldMasterList = resp

    })


  }

  addnew() {
    this.injectionMoldingMachineConfig = new InjectionMoldingMachineModel();
    this.hideForm = false;
  }

  details(id) {
    this.injectionMoldingMachineList.forEach(cncMachineObject => {
      if (cncMachineObject.id === id) {
        this.injectionMoldingMachineConfig = cncMachineObject;
        let tempList = this.injectionMoldingMachineConfig.allowedMolds;
        if (tempList.length != 0) {
          let idList: any = []
          for (var i = 0; i < tempList.length; i++) {
            let id = tempList[i].id
            idList.push(id)
          }
          this.injectionMoldingMachineConfig.tempMolds = idList
        }
        this.hideForm = false;

      }
    });
  }

  change($event) {
    console.log("event is", $event, this.injectionMoldingMachineConfig.allowedMolds)
  }

  cancel() {
    this.injectionMoldingMachineConfig = null;
    this.hideForm = true
  }

  isActiveClass(injectionMold) {
    this.injectionMoldingMachineService.isActiveClass(this.injectionMoldingMachineList, injectionMold)
  }

  showRelationship(injectionMoldingMachineId): void {
    this.$localInjectionMoldingMachineId = localStorage.setItem('injectionMoldingMachineId', JSON.stringify(injectionMoldingMachineId));
    const dialogRef = this.dialog.open(InjectionMoldingMachineRelationshipComponent, {
      width: '450px'
    });
  }

  getmfgMoldsDetails(mfgMolds: any[]): string {
    let moldName: string = '';
    for (var i = 0; i < mfgMolds.length; i++) {
      moldName = moldName.concat(mfgMolds[i].moldName).concat(',');
    }
    return moldName.slice(0, -1);
  }

  getMoldList(list: MoldMaster[]): string {
    let injToolName: string = ''
    let toolNameList: any = []
    if (list.length != 0) {
      for (var i = 0; i < list.length; i++) {
        let moldList = list[i].moldList
        if (moldList != null && moldList.length != 0) {
          for (var j = 0; j < moldList.length; j++) {
            let finalToolList = moldList[j]

            //injToolName = injToolName.concat(finalToolList[j].injMoldName).concat(',');
            toolNameList.push(finalToolList.injMoldName)


          }
        }
      }
    }
    var filteredArray = toolNameList.filter(function (item, pos) {
      return toolNameList.indexOf(item) == pos;
    });

    return filteredArray
  }

  save() {
    let allowedMoldList: { id: number }[] = [];
    console.log("data is", typeof (this.allowedMolds))
    if (this.allowedMolds) {

      for (var val of this.allowedMolds.value) {
        allowedMoldList.push({ id: +val });

        this.injectionMoldingMachineConfig.allowedMolds = allowedMoldList

      }
    }
    console.log("data is", this.injectionMoldingMachineConfig)
    if (this.injectionMoldingMachineConfig.id == undefined) {
      this.injectionMoldingMachineService.saveDeviceData(this.injectionMoldingMachineConfig).subscribe(
        (data: InjectionMoldingMachineModel) => {
          console.log(data);
        }
      )
      this.hideForm = true;
    }
    else {
      this.injectionMoldingMachineService.updateDeviceData(this.injectionMoldingMachineConfig).subscribe(
        () => {
          console.log('updated Procell Cell')
        }
      )
      this.hideForm = true;
    }
  }

  // confirmDelete(id): void {
  //   const dialogRef = this.dialog.open(DeletePlant, {
  //     width: '250px'
  //   });
  //   dialogRef.afterClosed().subscribe(result => {
  //     if (result === 'delete') {
  //       this.cncMachineService.onDeviceDelete(id).subscribe(
  //         () => console.log(`Process cell deleted with id =  ${id} deleted`)
  //       )
  //     }
  //   })
  // }


}
