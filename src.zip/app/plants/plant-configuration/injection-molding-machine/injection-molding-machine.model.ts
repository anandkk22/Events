export class InjectionMoldingMachineModel {
  id?: number
  equipmentName?: string

  equipmentMake?: string

  equipmentModel?: string

  injMachineType?: string

  serialNumber?: string

  installationDate?: string

  mfgconnectProductionLineId?: number

  warrantyExpiryDate?: string
  allowedMolds?: MoldMaster[]
  tempMolds?: any[]

}

export class MoldMaster {
  id?: number
  moldName?: string
  moldList?: InjMold[]
}

export class InjMold {
  id?: number
  injMoldName?: string
}

