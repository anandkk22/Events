export class ProductionLineModel {
  id?: number
  name?: string
  mfgconnectAreaId?: number
}
