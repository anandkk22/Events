import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { ProductionLineService } from '../production-line/production-line.service';
import { InjectionMoldRelationshipComponent } from './injection-mold-relationship';
import { InjectionMoldModel } from './injection-mold.model';
import { InjectionMoldService } from './injection-mold.service';

@Component({
  selector: 'app-injection-mold',
  templateUrl: './injection-mold.component.html',
  styleUrls: ['../plant-configuration.component.scss']
})
export class InjectionMoldComponent implements OnInit {

  injectionMoldList: InjectionMoldModel[];
  injectionMoldConfig = null;
  injectionMold: InjectionMoldModel;
  moldMasterList: any = []
  hideForm: boolean = true;
  prodList: any = []
  $localInjectionMoldId: any;
  constructor(private injectionMoldService: InjectionMoldService, private prodLineService: ProductionLineService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {

    this.injectionMoldService.getAllMolds().subscribe(injectionMold => {

      console.log("resp is", injectionMold)
      if (injectionMold instanceof Array)
        this.injectionMoldList = injectionMold
      console.log("cnc machine list is", this.injectionMoldList)
    })

    this.injectionMoldService.getMoldMasterData().subscribe(response => {
      this.moldMasterList = response
    })

    this.prodLineService.getAllProductionLines().subscribe(resp => {
      this.prodList = resp;
    })

  }

  addnew() {
    this.injectionMoldConfig = new InjectionMoldModel();
    this.hideForm = true
  }

  showRelationship(injectionMoldId): void {
    this.$localInjectionMoldId = localStorage.setItem('injectionMoldId', JSON.stringify(injectionMoldId));
    const dialogRef = this.dialog.open(InjectionMoldRelationshipComponent, {
      width: '450px'
    });
  }

  details(id) {
    this.injectionMoldList.forEach(cncMachineObject => {
      if (cncMachineObject.id === id) {
        this.injectionMoldConfig = cncMachineObject;
      }
      this.hideForm = true
    });
  }

  cancel() {
    this.injectionMoldConfig = null;
  }

  isActiveClass(injectionMold) {
    this.injectionMoldService.isActiveClass(this.injectionMoldList, injectionMold)
  }

  getMachineDetails(machineList: any[]): string {
    let machineName: string = '';
    for (var i = 0; i < machineList.length; i++) {
      machineName = machineName.concat(machineList[i].equipmentName).concat(',');
    }
    return machineName.slice(0, -1);
  }

  save() {
    console.log("data is", this.injectionMoldConfig)
    if (this.injectionMoldConfig.id == undefined) {
      this.injectionMoldService.saveDeviceData(this.injectionMoldConfig).subscribe(
        (data: InjectionMoldModel) => {
          console.log(data);
        }
      )
      this.hideForm = false
    }
    else {
      this.injectionMoldService.updateDeviceData(this.injectionMoldConfig).subscribe(
        () => {
          console.log('updated Procell Cell')
        }
      )
      this.hideForm = false
    }
  }

  // confirmDelete(id): void {
  //   const dialogRef = this.dialog.open(DeletePlant, {
  //     width: '250px'
  //   });
  //   dialogRef.afterClosed().subscribe(result => {
  //     if (result === 'delete') {
  //       this.cncMachineService.onDeviceDelete(id).subscribe(
  //         () => console.log(`Process cell deleted with id =  ${id} deleted`)
  //       )
  //     }
  //   })
  // }


}
