export class InjectionMoldModel {
  id?: number;
  injMoldName?: string

  injMoldCode?: string

  mfgconnectInjMoldMasterId?: number
  mfgconnectProductionLineId?: number
  allowedMachines?: EquipmentModel[]

}

export class EquipmentModel {
  id?: number;
  equipmentName?: string
}
