import { OnInit, Component, ViewChild, PipeTransform, Pipe } from '@angular/core';
import { AreaService } from './area.service';
import { MatDialog, MatDialogRef,  } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { ActivatedRoute } from '@angular/router';
import { AreaModel } from './area.model';
import { AreaRelationshipComponent } from './area-relationship';
import { AllTimezoneService } from 'src/app/shared/timezone.service';
import {  MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

@Component({
    selector: 'area',
    templateUrl: './area.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class AreaComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    plantConfigAreaDetails: AreaModel[];
    filteredArea: AreaModel[];
    area: any;
    plantConfigAreaDetail: any = {
        mfgconnectSiteId: '',
        plantId: ''
    }
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    processUnits: any = [];
    getPlantId: any;
    hideForm: boolean = true;
    activityTypes: any;
    $localAreaId: any;
    allTimezone: any;

    constructor(private _areaService: AreaService, public dialog: MatDialog,
        private _route: ActivatedRoute, private _allTimzone: AllTimezoneService,
        private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId');
        this.plantConfigAreaDetail.mfgconnectSiteId = this.getPlantId;
        this._areaService.getAreaById(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("Area", this.processUnits);
        });
        this.plantConfigAreaDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.onLoad();
        this.getActivityType();
        this.getTimezoneCountries();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._areaService.getListofAreas(this.getPlantId).subscribe(
                area => {
                    this.plantConfigAreaDetails = area                       
                }
            )
        })
    }

    getTimezoneCountries() {
        this._allTimzone.getTimezoneCountries().subscribe(
            timezone => this.allTimezone = timezone
        );
    }

    getActivityType() {
        this._areaService.getActivityType().subscribe(
            activityType => {
                this.activityTypes = activityType
            })
    }

    confirmDelete(id) {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._areaService.deleteAreaById(id).subscribe((resp) => {
                    console.log("Area deleted", resp);
                    () => this.onLoad();
                });                      
            }           
        })
    }

    showRelationship(getAreaId): void {
        this.$localAreaId = localStorage.setItem('areaId', JSON.stringify(getAreaId));
        const dialogRef = this.dialog.open(AreaRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigAreaDetails.forEach(area => {
            if (area.id === id) {
                this.plantConfigAreaDetail = area;

            }
            this.hideForm = true;
        });
    }

    addnew() {
        this.plantConfigAreaDetail = {};
        this.hideForm = true;
    }

    isActiveClass(area) {
        this._areaService.isActiveClass(this.plantConfigAreaDetails, area)
    }

    save() {
        if (this.plantConfigAreaDetail.id == undefined || this.plantConfigAreaDetail.id == null) {
            this.plantConfigAreaDetail.plantId = this.getPlantId;
            console.log("******");
            console.log(this.plantConfigAreaDetail)
            this._areaService.createNewArea(this.plantConfigAreaDetail).subscribe((data) => {
                console.log("data", data)
                this.onLoad();
            });
            this.hideForm = false;
        }
        else {
            this._areaService.updateArea(this.plantConfigAreaDetail).subscribe(() => {
                console.log('updated Area');
                this.onLoad();
            });
        }
        this.hideForm = false;
    }

    cancel() {
        this.plantConfigAreaDetail = null;
        // this.getlistOfAreas();
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigAreaDetails) {
            // this.searchText = '';
            if (sortFilter === 'externalId') {
                this.plantConfigAreaDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigAreaDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

}


@Pipe({ name: 'searchByName' })
export class searchAreaPlantName implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}
