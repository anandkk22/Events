import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plantevents',
  templateUrl: './plantevents.component.html',
  styleUrls: ['./plantevents.component.scss']
})
export class PlanteventsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  minus_plus_icon_toggle(id) {
    const element = document.getElementById('minus-image-' + id);
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-' + id);
    element2.classList.toggle('d-none');
  }
}
