import { Component, OnInit } from '@angular/core';
import { EnergyServiceService } from './energy-service.service';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import * as am4maps from '@amcharts/amcharts4/maps';
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { matMenuAnimations } from '@angular/material';
import { CodeNode } from 'source-list-map';
import { areAllEquivalent } from '@angular/compiler/src/output/output_ast';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { identifierModuleUrl } from '@angular/compiler';

am4core.useTheme(am4themes_animated);

@Component({
  selector: 'app-energy-dashboard',
  templateUrl: './energy-dashboard.component.html',
  styleUrls: ['./energy-dashboard.component.scss']
})
export class EnergyDashboardComponent implements OnInit {

  public userFilter: any = { displayName: '' };

  public orgBredCrumb: any = {
    processUnit: '',
    processCellName: '',
    areaName: '',
    plantName: '',
    orgName: ''
  }

  public processStatusTimeSpans: any = ['Today', 'Custom'];
  public isCustom: boolean = false;

  public lineChart: any = [];
  public areas: any = [];
  public productionLines: any = [];
  public workCells: any = [];
  public areaId: any;
  public productionLineId: any;
  public workCellId: any;

  public equipments: any = [];
  public activePowerFrom: any;
  public activePowerTo: any;

  public formGroup = new FormGroup({
    activePowerFrom: new FormControl(null),
    activePowerTo: new FormControl(null)
  })

  public from: any;
  public to: any;

  monthlyPowerCut: any;
  plant: any;
  public toDate = new Date();
  public fromDate1 = new Date(this.toDate.getTime() - (1 * 60 * 60 * 1000));

  public fromDate = new Date();

  public oneYearBack = new Date(this.toDate.getTime() - (365 * 24 * 60 * 60 * 1000));

  thisYear = (new Date()).getFullYear();
  start = new Date("1/1/" + this.thisYear);
  defaultStart = moment(this.start.valueOf());

  public powerCutYear: any;
  public consWithAreaYear: any;
  public quarterYear: any;
  public currentYear: any;

  plantId = 65;

  public equipmentId: any = [];
  public range: any;
  public productionRejectionRange: any;
  public utilityRange: any;
  public shopFloorRange: any;
  public sankeyRange: any;
  public overallConsRange: any;

  overallConsCustom: any;
  sankeyCustom: any;
  shopFloorCustom: any;
  utilityCustom: any;
  productionRejectionCustom: any;
  activePowerCustom: any;

  productionRejectionFrom: any;
  productionRejectionTo: any;
  utilityFrom: any;
  utilityTo: any;
  shopFloorFrom: any;
  shopFloorTo: any;
  overallConsFrom: any;
  overallConsTo: any;
  sankeyFrom: any;
  sankeyTo: any;
  activePowerFrom1: any
  activePowerTo1: any;

  utilityConsumption: any;
  shopFloorConsumption: any;
  productionRejection: any;
  energyConsumptionByArea: any;
  sankeyData: any;
  public chart: any;

  public valueAxis2: any;
  public categoryAxis: any;

  public arr = [];
  public nameArr = [];
  public quarterData = [];
  public consumptionWithArea = [];
  constructor(private service: EnergyServiceService,
    private spinner: NgxSpinnerService, ) { }
  jsonData = [];

  globalTo: any;
  globaFrom: any;
  mtdValue: any;
  ytdValue: any;
  avgDaily: any;
  specificEnergy: any;
  lastMonth: any;
  lastYear: any;
  todaysConsumption: any;
  selected: any;

  date = new Date();
  firstDay = new Date(this.date.getFullYear(), this.date.getMonth(), 1);
  ngOnInit() {
    this.fromDate.setHours(0, 0, 0, 0);

    this.globalTo = moment(this.toDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
    this.globaFrom = moment(this.fromDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z"
    this.currentYear = moment().year();

    this.service.getAreaByPlantId(this.plantId).subscribe((resp) => {
      this.areas = resp;
      console.log("bred crumb", this.areas);
      this.service.getUtilityConsumption(this.plantId, this.areas[1].id, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log(resp);
        this.utilityConsumption = resp;
        if (this.utilityConsumption != null) {
          this.barChart('chartdiv6', this.utilityConsumption);
        }
      });
      this.service.getShopFloorConsumption(this.plantId, this.areas[0].id, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log(resp);
        this.shopFloorConsumption = resp;
        if (this.shopFloorConsumption != null) {
          this.mixedChart('chartdiv3', this.shopFloorConsumption);
        }
      });
    });

    let firstDay = moment(this.firstDay).utc().format("YYYY-MM-DDTHH:mm:00") + "Z"
    this.service.getMTDValue(this.plantId, firstDay, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.mtdValue = resp;
      this.ytdValue = resp;
    });

    this.service.getAvgDaily(this.plantId, firstDay, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.avgDaily = resp;
    });

    this.service.getSpecificEnergy(this.plantId, firstDay, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.specificEnergy = resp;
    });

    this.service.getLastMonth(this.plantId, firstDay, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.lastMonth = resp;
    });

    this.service.getLastYear(this.plantId, this.currentYear).subscribe((resp) => {
      console.log(resp);
      this.lastYear = resp;
    });

    this.chart = am4core.create("chartdiv", am4charts.XYChart);
    this.valueAxis2 = this.chart.yAxes.push(new am4charts.ValueAxis());
    this.categoryAxis = this.chart.xAxes.push(new am4charts.CategoryAxis());
    this.chart.legend = new am4charts.Legend();

    this.activePowerChart();
    this.range = 'Today';

    console.log("one ", this.fromDate);
    this.service.getPlant().subscribe((resp) => {
      this.plant = resp;
      console.log("bred crumb", this.plant);
    });

    this.service.getBredCrumbData().subscribe((resp) => {
      this.orgBredCrumb = resp;
      console.log("bred crumb", this.orgBredCrumb);
    });


    console.log("one11 ", this.globaFrom);


    this.service.getProductionRejection(this.plantId, firstDay, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.productionRejection = resp;
    });


    let from = moment(this.fromDate1).utc().format("YYYY-MM-DDTHH:mm:00") + "Z"

    this.service.getEnergyConsumptionByArea(this.plantId, this.globaFrom, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.energyConsumptionByArea = resp;
      if (this.energyConsumptionByArea != null) {
        this.mixedChart('chartdiv4', this.energyConsumptionByArea);
      }
    });

    this.service.overAllConsumption(this.plantId, this.globaFrom, this.globalTo).subscribe((resp) => {
      console.log(resp);
      this.todaysConsumption = resp;
      this.todaysConsumption = Math.round(this.todaysConsumption);
    });

    this.spinner.show();
    setTimeout(() => {
      this.service.getSankeyDataplantId(this.plantId, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log(resp);
        this.sankeyData = resp;
        if (this.sankeyData != null) {
          this.sankeyChart('chartdiv7', this.sankeyData);
        }
        this.spinner.hide();
      });
    }, 3000);

    this.service.getQuarterData(this.plantId, this.currentYear).subscribe((resp) => {
      console.log(resp);
      this.quarterData = resp;
      if (this.quarterData != null) {
        this.mixedChart('chartdiv5', this.quarterData);
      }
    });

    this.service.getConsumptionWithArea(this.plantId, this.currentYear).subscribe((resp) => {
      console.log(resp);

      this.consumptionWithArea = resp;
      let arr = [];
      let val = [];
      let data1 = [];
      for (let i = 0; i < this.consumptionWithArea.length; i++) {
        let obj = { "month": this.consumptionWithArea[i].month }

        arr = Object.keys(this.consumptionWithArea[i].data)
        val = Object.values(this.consumptionWithArea[i].data);
        for (let j = 0; j < arr.length; j++) {
          obj[arr[j]] = val[j];
        }
        data1.push(obj);
      }

      if (data1 != null) {
        this.stackedBarChart('chartdiv1', data1, arr);
      }
    });


    this.service.getAreaByPlantId(this.plantId).subscribe((resp) => {
      this.areas = resp;
      if (this.areas != null) {
        this.areaId = this.areas[0].id;
        this.service.getProductionLineByAreaId(this.areas[0].id).subscribe((resp) => {
          this.productionLines = resp;
          if (this.productionLines != null) {
            this.productionLineId = this.productionLines[0].id;
            this.service.getWorkCellByProductionLineId(this.productionLines[0].id).subscribe((resp) => {
              this.workCells = resp;
              if (this.workCells != null) {
                this.workCellId = this.workCells[0].id;
                this.service.getMachineByWorCellId(this.workCells[0].id).subscribe((resp) => {
                  this.equipments = resp;
                  if (this.equipments != null) {
                    this.equipmentId.push(this.equipments[0]);
                    this.service.getActivePowerData(this.equipments[0].id, this.globaFrom, this.globalTo).subscribe((resp) => {
                      this.lineChart = resp;
                      if (this.lineChart != null) {
                        this.arr.push(this.lineChart);
                        this.nameArr.push(this.equipments[0].machineName);
                        this.addseries(this.arr, this.nameArr);
                        console.log("line chart data", this.lineChart);
                      }
                    });
                  }
                });
              }
            });
          }
        });
      }
    });

    this.service.getMonthlyPowerCut(this.plantId, this.currentYear).subscribe((resp) => {
      this.monthlyPowerCut = resp;
      console.log("ddddd", this.monthlyPowerCut);
      if (this.monthlyPowerCut != null) {
        this.lineArea("chartdiv8", this.monthlyPowerCut);
      }
    });

  }
  initialChart() {

  }
  ////modify
  // setMonthlyPowerCut()
  // {
  //   this.service.getMonthlyPowerCut(65, 2020, 1, 1).subscribe((resp) => {
  //     this.monthlyPowerCut = resp;
  //     console.log("monthly power cut", this.monthlyPowerCut);
  //   });

  // }

  setProductionLine(event) {
    this.workCells = null;
    this.equipments = null;
    console.log("ffff", event);
    this.service.getProductionLineByAreaId(event.value).subscribe((resp) => {
      this.productionLines = resp;
      console.log("bred crumb", this.productionLines);
    });
  }

  setWorkCell(event) {
    this.equipments = null;
    this.service.getWorkCellByProductionLineId(event.value).subscribe((resp) => {
      this.workCells = resp;
      console.log("bred crumb", this.workCells);
    });
  }

  setEquipments(event) {
    this.service.getMachineByWorCellId(event.value).subscribe((resp) => {
      this.equipments = resp;
      console.log("equipments crumb", this.equipments);
    });
  }
  minus_plus_icon_toggle_h1() {
    const element = document.getElementById('minus-image-h1');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h1');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h2() {
    const element = document.getElementById('minus-image-h2');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h2');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h4() {
    const element = document.getElementById('minus-image-h4');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h4');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h5() {
    const element = document.getElementById('minus-image-h5');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h5');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h6() {
    const element = document.getElementById('minus-image-h6');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h6');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h7() {
    const element = document.getElementById('minus-image-h7');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h7');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h8() {
    const element = document.getElementById('minus-image-h8');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h8');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h9() {
    const element = document.getElementById('minus-image-h9');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h9');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h10() {
    const element = document.getElementById('minus-image-h10');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h10');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h11() {
    const element = document.getElementById('minus-image-h11');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h11');
    element2.classList.toggle('d-none');
  }

  scrollPositionPortfolio() {
    const elmnt = document.getElementById('scroll-position-window-top');
    elmnt.scrollIntoView();
    /* window.scrollTo(0, 0); */
  }

  activePowerChart() {
    // var chart = am4core.create(id, am4charts.XYChart);
    this.chart.logo.disabled = true;

    // Add data
    // this.chart.data = data;
    // this.chart.dateFormatter.utc = true;

    // var valueAxis2 = this.chart.yAxes.push(new am4charts.ValueAxis());

    // let categoryAxis = this.chart.xAxes.push(new am4charts.CategoryAxis());
    this.categoryAxis.dataFields.category = "timestamp";

    // Add legend

    // Add cursor
    this.chart.cursor = new am4charts.XYCursor();
    this.chart.cursor.xAxis = this.categoryAxis;
    this.chart.cursor.fullWidthLineX = true;

    this.valueAxis2.title.text = "Active Power(KW)"
    this.categoryAxis.renderer.fontSize = 10;

    // categoryAxis.renderer.labels.template.rotation = 270;
  }

  addseries(arr, name) {
    for (let i = 0; i < arr.length; i++) {
      this.chart.data = arr[i];
      console.log(arr.length, arr[i]);
      var series2 = this.chart.series.push(new am4charts.LineSeries());
      series2.data = this.chart.data;
      series2.dataFields.valueY = "activePower";
      // dateAxis.renderer.minGridDistance = 45;
      series2.dataFields.categoryX = "timestamp";
      series2.name = name[i];

      series2.strokeWidth = 1.5;
      // let chartColor = '#ff6600';
      // series2.propertyFields.stroke = "color";
      // series2.stroke = am4core.color(chartColor);
      // series2.yAxis = this.valueAxis2;
      series2.tooltipText = "{name}:[bold]{valueY}[/]";

    }
    // this.chart.invalidateData();
    // series2 = this.chart.series.push(series2);
  }
  stackedBarChart(chartName, data, nameArr) {
    let chart = am4core.create(chartName, am4charts.XYChart);
    chart.logo.disabled = true;

    // Add data
    chart.data = data;

    // Create axes
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "month";
    categoryAxis.renderer.grid.template.location = 0;


    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.min = 0;
    valueAxis.title.text = "Energy Consumption (kWh)";

    // Create series
    function createSeries(field, name) {

      // Set up series
      let series = chart.series.push(new am4charts.ColumnSeries());
      series.name = name;
      series.dataFields.valueY = field;
      series.dataFields.categoryX = "month";
      series.sequencedInterpolation = true;

      // Make it stacked
      series.stacked = true;

      // Configure columns
      series.columns.template.width = am4core.percent(20);
      series.columns.template.tooltipText = "[bold]{name}[/]\n[font-size:14px]{categoryX}: {valueY}";

      // Add label
      let labelBullet = series.bullets.push(new am4charts.LabelBullet());
      labelBullet.label.text = "{valueY}";
      labelBullet.locationY = 0.5;
      labelBullet.label.hideOversized = true;

      return series;
    }

    for (let i = 0; i < nameArr.length; i++) {
      createSeries(nameArr[i], nameArr[i]);
    }


    // Legend
    chart.legend = new am4charts.Legend();
    chart.legend.labels.template.fill = am4core.color('#10c3d7');
  }

  mixedChart(chartName, data) {
    let chart = am4core.create(chartName, am4charts.XYChart);
    chart.logo.disabled = true;
    // Export
    // chart.exporting.menu = new am4core.ExportMenu();

    // Data for both series
    chart.data = data;

    /* Create axes */
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    if (chartName == "chartdiv3") {
      categoryAxis.dataFields.category = "name";
    }
    else if (chartName == "chartdiv5") {
      categoryAxis.dataFields.category = "quarter";
    }
    else {
      categoryAxis.dataFields.category = "areaName";
    }
    categoryAxis.renderer.minGridDistance = 30;

    /* Create value axis */
    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.renderer.opposite = true;

    let valueAxis1 = chart.yAxes.push(new am4charts.ValueAxis());
    /* Create series */
    let columnSeries = chart.series.push(new am4charts.ColumnSeries());
    columnSeries.name = "Production";

    if (chartName == "chartdiv4") {
      columnSeries.dataFields.valueY = "energyPercentage";
    }
    if (chartName == "chartdiv3" || chartName == "chartdiv5") {
      columnSeries.dataFields.valueY = "production";
    }


    if (chartName == "chartdiv3") {
      columnSeries.dataFields.categoryX = "name";
    }
    else if (chartName == "chartdiv5") {
      columnSeries.dataFields.categoryX = "quarter";
    }
    else {
      columnSeries.dataFields.categoryX = "areaName";

    }
    if (data.length < 2)
      columnSeries.columns.template.width = am4core.percent(20);

    columnSeries.columns.template.tooltipText = "[#fff font-size: 15px]{name} in {categoryX}:\n[/][#fff font-size: 20px]{valueY}[/] [#fff]{additional}[/]"
    columnSeries.columns.template.propertyFields.fillOpacity = "fillOpacity";
    columnSeries.columns.template.propertyFields.stroke = "stroke";
    columnSeries.columns.template.propertyFields.strokeWidth = "strokeWidth";
    columnSeries.columns.template.propertyFields.strokeDasharray = "columnDash";
    columnSeries.tooltip.label.textAlign = "middle";
    columnSeries.yAxis = valueAxis1;
    columnSeries.columns.template.fill = am4core.color('#33ccff');

    let lineSeries = chart.series.push(new am4charts.LineSeries());
    lineSeries.name = "Energy Consumption";
    lineSeries.dataFields.valueY = "energyConsumption";
    if (chartName == "chartdiv3") {
      lineSeries.dataFields.categoryX = "name";
    }

    else if (chartName == "chartdiv5") {
      lineSeries.dataFields.categoryX = "quarter";
    }

    else {
      lineSeries.dataFields.categoryX = "areaName";

    }
    lineSeries.stroke = am4core.color("#ff9933");
    lineSeries.strokeWidth = 3;
    lineSeries.propertyFields.strokeDasharray = "lineDash";
    lineSeries.tooltip.label.textAlign = "middle";
    lineSeries.yAxis = valueAxis;
    // lineSeries.tooltipText = "[#000]{valueY.value}[/]";

    let bullet = lineSeries.bullets.push(new am4charts.Bullet());
    bullet.fill = am4core.color("#fdd400"); // tooltips grab fill from parent by default
    bullet.tooltipText = "[#fff font-size: 15px]{name} in {categoryX}:\n[/][#fff font-size: 20px]{valueY}[/] [#fff]{additional}[/]"
    let circle = bullet.createChild(am4core.Circle);
    circle.radius = 3;
    circle.fill = am4core.color("#fff");
    circle.strokeWidth = 3;

    chart.legend = new am4charts.Legend();
    valueAxis.title.text = "Energy Consumption(kWh)"
    if (chartName == "chartdiv4") {
      valueAxis1.title.text = "Energy Percentage"
    }
    else {
      valueAxis1.title.text = "Production (PPM)"
    }

  }

  lineArea(chartName, data) {
    am4core.useTheme(am4themes_animated);
    // Themes end

    var chart = am4core.create(chartName, am4charts.XYChart);
    chart.logo.disabled = true;

    chart.data = data;

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "monthName";

    var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.tooltip.disabled = true;

    var valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis2.tooltip.disabled = true;
    valueAxis2.renderer.opposite = true;

    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.categoryX = "monthName";
    series.name = "Duration";
    series.dataFields.valueY = "duration";
    series.tooltipText = "[#000]{valueY.value}[/]";
    series.tooltip.background.fill = am4core.color("#FFF");
    series.tooltip.getStrokeFromObject = true;
    series.tooltip.background.strokeWidth = 3;
    series.tooltip.getFillFromObject = false;
    series.fillOpacity = 0.6;
    series.strokeWidth = 2;
    // series.stacked = true;

    var series2 = chart.series.push(new am4charts.LineSeries());
    series2.name = "Power Cut";
    series2.dataFields.categoryX = "monthName";
    series2.dataFields.valueY = "powerCut";
    series2.tooltipText = "[#000]{valueY.value}[/]";
    series2.tooltip.background.fill = am4core.color("#FFF");
    series2.tooltip.getFillFromObject = false;
    series2.tooltip.getStrokeFromObject = true;
    series2.tooltip.background.strokeWidth = 3;
    series2.sequencedInterpolation = true;
    series2.fillOpacity = 0.6;
    // series2.stacked = true;
    series2.strokeWidth = 2;
    series2.yAxis = valueAxis2;
    chart.cursor = new am4charts.XYCursor();
    chart.cursor.xAxis = categoryAxis;

    // Add a legend
    chart.legend = new am4charts.Legend();
    chart.legend.position = "top";

    categoryAxis.title.text = "Months"

  }

  barChart(chartName, data) {
    let chart = am4core.create(chartName, am4charts.XYChart);
    chart.logo.disabled = true;
    // Add data
    chart.data = data;

    // Create axes

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "name";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 30;



    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

    // Create series
    let series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = "energyConsumption";
    series.dataFields.categoryX = "name";
    series.name = "Energy Consumption";
    series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
    series.columns.template.fillOpacity = .8;

    let columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 2;
    columnTemplate.strokeOpacity = 1;
    series.columns.template.fill = am4core.color('#33ccff');
    valueAxis.title.text = "Energy Consumption(kWh)"
    series.columns.template.width = am4core.percent(55);

  }

  selectActivePowerTimeSpan(event) {
    if (event.value == 'Custom') {
      this.activePowerCustom = true;
    }
    else {
      this.activePowerCustom = false;
    }
  }

  selectProductionRejectionTimeSpan(event) {
    if (event.value == 'Custom') {
      this.productionRejectionCustom = true;
    }
    else {
      this.productionRejectionCustom = false;
    }
  }
  selectUtilityTimeSpan(event) {
    if (event.value == 'Custom') {
      this.utilityCustom = true;
    }
    else {
      this.utilityCustom = false;
    }
  }

  selectConsumptionByAreaTimeSpan(event) {
    if (event.value == 'Custom') {
      this.overallConsCustom = true;
    }
    else {
      this.overallConsCustom = false;
    }
  }

  selectShopFloorTimeSpan(event) {
    if (event.value == 'Custom') {
      this.shopFloorCustom = true;
    }
    else {
      this.shopFloorCustom = false;
    }
  }
  selectSankeyTimeSpan(event) {
    if (event.value == 'Custom') {
      this.sankeyCustom = true;
    }
    else {
      this.sankeyCustom = false;
    }
  }
  selectParameter(event) {
    this.equipmentId = [];
    this.equipmentId = event.value;
  }

  onSubmit() {
    this.arr = [];
    this.nameArr = [];
    if (this.range == "Today") {
      let to = moment(this.toDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      let from = moment(this.fromDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";

      for (let i = 0; i < this.equipmentId.length; i++) {

        this.service.getActivePowerData(this.equipmentId[i].id, from, to).subscribe((resp) => {
          this.lineChart = resp;
          if (this.lineChart != null) {
            this.arr.push(this.lineChart);
            this.nameArr.push(this.equipmentId[i].machineName);
            if (this.arr.length == this.equipmentId.length)
              this.addseries(this.arr, this.nameArr);

            console.log("line chart data", this.arr);
          }

        });

      }
    }
    else {
      this.arr = [];
      this.nameArr = [];
      console.log("idddd", this.equipmentId);
      let from = (moment(this.formGroup.get('activePowerFrom').value).utc().format("YYYY-MM-DDTHH:mm:00") + "Z");
      let to = (moment(this.formGroup.get('activePowerTo').value).utc().format("YYYY-MM-DDTHH:mm:00") + "Z");

      for (let i = 0; i < this.equipmentId.length; i++) {
        this.service.getActivePowerData(this.equipmentId[i].id, from, to).subscribe((resp) => {
          console.log("data33333", resp);
          this.lineChart = resp;
          if (this.lineChart != null) {
            this.arr.push(this.lineChart);
            this.nameArr.push(this.equipmentId[i].machineName);
            if (this.arr.length == this.equipmentId.length)
              this.addseries(this.arr, this.nameArr);

            console.log("line chart data", this.arr);
          }
        });
      }

    }
  }

  selectedDate(event, datepicker) {
    this.powerCutYear = moment(event).year();
    console.log("from ", this.powerCutYear);

    datepicker.close();
  }

  selectQuarterYear(event, datepicker) {
    this.quarterYear = moment(event).year();
    console.log("from ", this.quarterYear);

    datepicker.close();
  }
  selectConsWithArea(event, datepicker) {
    this.consWithAreaYear = moment(event).year();
    console.log("from ", this.consWithAreaYear);

    datepicker.close();
  }

  loadPowerCutChart() {
    this.service.getMonthlyPowerCut(this.plantId, this.powerCutYear).subscribe((resp) => {
      this.monthlyPowerCut = resp;
      console.log("ddddd", this.monthlyPowerCut);
      if (resp != null) {
        this.lineArea("chartdiv8", this.monthlyPowerCut);
      }
    },
      (err) => { this.lineArea("chartdiv8", null) }
    );
  }

  loadStackChart() {
    this.service.getConsumptionWithArea(this.plantId, this.consWithAreaYear).subscribe((resp) => {
      console.log(resp);

      this.consumptionWithArea = resp;
      let arr = [];
      let val = [];
      let data1 = [];
      for (let i = 0; i < this.consumptionWithArea.length; i++) {
        let obj = { "month": this.consumptionWithArea[i].month }

        arr = Object.keys(this.consumptionWithArea[i].data)
        val = Object.values(this.consumptionWithArea[i].data);
        for (let j = 0; j < arr.length; j++) {
          obj[arr[j]] = val[j];
        }
        data1.push(obj);
      }

      if (data1 != null) {
        this.stackedBarChart('chartdiv1', data1, arr);
      }
    });

  }

  selectRange(event) {
    let temp = event.value;
    let temp1 = moment(event.value).add(24, "hours");
    this.from = moment(temp).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
    this.to = moment(temp1).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
    // this.formGroup.get('activePowerTo').setValue = null;
    console.log("rangggg", event);
    this.formGroup.patchValue({
      activePowerTo: ''
    });
  }

  loadProductionRejection() {
    if (this.productionRejectionRange == "Today") {
      this.service.getProductionRejection(this.plantId, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log(resp);
        this.productionRejection = resp;
      });
    }
    else {
      let from = moment(this.productionRejectionFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      let to = moment(this.productionRejectionTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      console.log("pr fromto", from, to);
      this.service.getProductionRejection(this.plantId, from, to).subscribe((resp) => {
        console.log(resp);
        this.productionRejection = resp;
      });
    }
  }

  loadUtilityConsumption() {
    if (this.utilityRange == "Today") {
      this.service.getUtilityConsumption(this.plantId, this.areas[1].id, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log(resp);
        this.utilityConsumption = resp;
        if (this.utilityConsumption != null) {
          this.barChart('chartdiv6', this.utilityConsumption);
        }

      });
    }
    else {
      let from = moment(this.utilityFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      let to = moment(this.utilityTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      console.log("pr fromto", from, to);
      this.service.getUtilityConsumption(this.plantId, this.areas[1].id, from, to).subscribe((resp) => {
        console.log(resp);
        this.utilityConsumption = resp;
        if (this.utilityConsumption != null) {
          this.barChart('chartdiv6', this.utilityConsumption);
        }
      });
    }
  }

  loadShopFloorConsumptionProduction() {
    if (this.shopFloorRange == "Today") {
      this.service.getShopFloorConsumption(this.plantId, this.areas[0].id, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log("shop", resp);
        this.shopFloorConsumption = resp;
        if (this.shopFloorConsumption != null) {
          this.mixedChart('chartdiv3', this.shopFloorConsumption);
        }
      });
    }
    else {
      let from = moment(this.shopFloorFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      let to = moment(this.shopFloorTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      console.log("pr fromto", from, to);
      this.service.getShopFloorConsumption(this.plantId, this.areas[0].id, from, to).subscribe((resp) => {
        console.log("shop", resp);
        this.shopFloorConsumption = resp;
        if (this.shopFloorConsumption != null) {
          this.mixedChart('chartdiv3', this.shopFloorConsumption);
        }
      });
    }
  }

  loadEnergyConsumptionByArea() {
    if (this.overallConsRange == "Today") {
      this.service.getEnergyConsumptionByArea(this.plantId, this.globaFrom, this.globalTo).subscribe((resp) => {
        console.log(resp);
        this.energyConsumptionByArea = resp;
        if (this.energyConsumptionByArea != null) {
          this.mixedChart('chartdiv4', this.energyConsumptionByArea);
        }
      });
    }
    else {
      let from = moment(this.overallConsFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      let to = moment(this.overallConsTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
      console.log("pr fromto", from, to);
      this.service.getEnergyConsumptionByArea(this.plantId, from, to).subscribe((resp) => {
        console.log(resp);
        this.energyConsumptionByArea = resp;
        if (this.energyConsumptionByArea != null) {
          this.mixedChart('chartdiv4', this.energyConsumptionByArea);
        }
      });
    }
  }

  loadQuarterConsumptionChart() {
    this.service.getQuarterData(this.plantId, this.quarterYear).subscribe((resp) => {
      console.log(resp);
      this.quarterData = resp;
      if (this.quarterData != null) {
        this.mixedChart('chartdiv5', this.quarterData);
      }
    });

  }

  loadSankeyChart() {
    if (this.sankeyRange == "Today") {
      this.spinner.show();
      setTimeout(() => {
        this.service.getSankeyDataplantId(this.plantId, this.globaFrom, this.globalTo).subscribe((resp) => {
          console.log(resp);
          this.sankeyData = resp;
          if (this.sankeyData != null) {
            this.sankeyChart('chartdiv7', this.sankeyData);
          }
          this.spinner.hide();
        });
      }, 3000);
    }
    else {
      this.spinner.show();
      setTimeout(() => {
        let from = moment(this.sankeyFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
        let to = moment(this.sankeyTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
        this.service.getSankeyDataplantId(this.plantId, from, to).subscribe((resp) => {
          console.log(resp);
          this.sankeyData = resp;
          if (this.sankeyData != null) {
            this.sankeyChart('chartdiv7', this.sankeyData);
          }
          this.spinner.hide();
        });
      }, 3000);
    }
  }

  sankeyChart(chartName, data) {
    let chart = am4core.create(chartName, am4charts.SankeyDiagram);
    chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

    chart.logo.disabled = true;

    chart.data = data;
    let hoverState = chart.links.template.states.create("hover");
    hoverState.properties.fillOpacity = 0.6;

    chart.dataFields.fromName = "from";
    chart.dataFields.toName = "to";
    chart.dataFields.value = "value";

    // for right-most label to fit
    chart.paddingRight = 80;

    // make nodes draggable
    let nodeTemplate = chart.nodes.template;
    nodeTemplate.inert = true;
    nodeTemplate.readerTitle = "Drag me!";
    nodeTemplate.showSystemTooltip = true;
    nodeTemplate.width = 20;
    nodeTemplate.propertyFields.zIndex = "100";

    var labelBullet = chart.links.template.bullets.push(new am4charts.LabelBullet());
    labelBullet.label.propertyFields.text = "value";
    labelBullet.label.textAlign = "middle";
    labelBullet.label.fillOpacity = 1;

    // make nodes draggable
    // let nodeTemplate1 = chart.nodes.template;
    // nodeTemplate1.readerTitle = "Click to show/hide or drag to rearrange";
    // nodeTemplate1.showSystemTooltip = true;
    // nodeTemplate1.cursorOverStyle = am4core.MouseCursorStyle.pointer


  }

}
