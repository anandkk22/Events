export class MoldMasterModel {
    id?: number;
    cycleTime?: number;       
    noOfCavities?: number;
    moldName?: string;
    moldCode?: number;
    moldDescription?: string;
    quanity?: number;
    moldList?:[];
    allowedEquipments?: Equipments[];
}

export class Equipments {
    id?: number;
    equipmentName?: string;
    equipmentMake?: string;
    equipmentModel?: string;
    standardRunningHoursForMaintenance?: string;
    ratedPowerCapacity?: string;
    powerSupplyTypeId?: string;
    mfgconnectSite?: string;
    mfgconnectProcessCell?: string;
    mfgconnectProductionLine?: string;
    mfgconnectProductionUnit?: string;
    mfgconnectWorkCell?: string;
    mfgconnectProcessUnit?: string;
    mfgconnectArea?: string;
    lastUpdated?: string;
    isActive?: string;
    outputEquipment?: string;
    machineName?: string;
    machineType?: string;
    serialNumber?: string;
    installationDate?: string;
    manufacturingYear?: string;
    make?: string;
    model?: string;
    praedgeDeviceId?: string;
}