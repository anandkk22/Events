import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';

import { catchError } from 'rxjs/operators';
import { MoldMasterModel } from './mold-master.model';

@Injectable({ providedIn: 'root' })
export class MoldMasterService {
    public moldMaster: string = environment.CNC_API_URL + 'api/mfgconnect-moldMaster'; 
    public relationship: string = environment.CNC_API_URL + 'api/mfgconnect-moldMaster/get-relationship';  
    public machineAllowed: string = environment.CNC_API_URL + 'api/mfgconnect-cnc-machines';    

    constructor(private _http: HttpClient) { }

    getListofMoldMaster(): Observable<MoldMasterModel[]> {
        return this._http.get<MoldMasterModel[]>(`${this.moldMaster}`)
    }

    getMoldMasterById(id: number): Observable<MoldMasterModel> {
        return this._http.get<MoldMasterModel>(`${this.moldMaster}/${id}`)
    }

    getMachineAllowedList(): Observable<any[]>{
        return this._http.get<any[]>(`${this.machineAllowed}`)
    }

    createMoldMaster(moldMaster: MoldMasterModel): Observable<any> {
        return this._http.post<any>(`${this.moldMaster}`, moldMaster, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateMoldMaster(moldMaster: MoldMasterModel): Observable<void> {
        return this._http.put<void>(`${this.moldMaster}`, moldMaster, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteMoldMasterById(id: number) {
        return this._http.delete(this.moldMaster+"/"+ id, {responseType: 'text'})
        .pipe(catchError(this.handleError))
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
        }         
        return throwError(errorMessage);      
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}