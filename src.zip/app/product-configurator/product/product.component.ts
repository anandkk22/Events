import { OnInit, Component, ViewChild, PipeTransform, Pipe } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DeleteProduct } from '../delete-plantconfigurator/delete-plantconfigurator';
import { ProductRelationship } from './product-relationship';
import { ProductModel } from './product.model';
import { ProductService } from './product.service';
import { FormControl } from '@angular/forms';
import { ProductFamilyModel } from '../product-family/product.model';
import { ProductFamilyService } from '../product-family/product-family.service';

@Component({
    selector: 'product',
    templateUrl: './product.component.html',
    styleUrls: ['../../plants/plant-configuration/plant-configuration.component.scss', './product.component.scss']
})

export class Product implements OnInit {
    productDetails: ProductModel[];
    productFamilyDetails: ProductFamilyModel[];
    productDetail: ProductModel = {};
    hideForm: boolean = false
    $localProductId: any;
    noOfManuProcess: any[];
    menuProcess = new FormControl();
    
    selectedManuProcess;

    constructor(private _productService: ProductService, public dialog: MatDialog, 
        private _productFamilyService: ProductFamilyService) { }

    ngOnInit() {
        this.loadProduct();
        this.loadProductFamily();
        this.noOfManuProcess = [{ code: 1, name: 'Process 1' }, { code: 2, name: 'Process 2' }, { code: 3, name: 'Process 3' }, { code: 4, name: 'Process 4' }]
    }

    addnew() {
        this.productDetail = {}
        this.hideForm = true;
    }

    details(id) {
        this.productDetails.forEach(productFamily => {
            if (productFamily.id === id) {
                this.productDetail = productFamily;
            }
            this.hideForm = true;
        });
    }

    loadProduct() {
        this._productService.getListofproduct().subscribe(
            data => this.productDetails = data
        )
    }

    loadProductFamily() {
        this._productFamilyService.getListofproductFamily().subscribe(
            data => this.productFamilyDetails = data
        )
    }

    confirmDelete(id) {
        const dialogRef = this.dialog.open(DeleteProduct, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._productService.deleteProductById(id).subscribe((resp) => {
                    console.log(`Product deleted with id =  ${id} deleted`, resp);
                    () => this.loadProduct();
                })
            }
        })
    }

    showRelationship(getProductId): void {
        this.$localProductId = localStorage.setItem('productId', JSON.stringify(getProductId));
        const dialogRef = this.dialog.open(ProductRelationship, {
            width: '450px'
        });
    }

    save() {      
        if (this.productDetail.id == undefined ||  this.productDetail.id == null) {  
            this._productService.createProduct(this.productDetail).subscribe((data) => {
                this.loadProduct();
            });
            this.hideForm = false;
        }
        else {
            this._productService.updateProduct(this.productDetail).subscribe(() => {
                this.loadProduct();
            });
        }
        this.hideForm = false;
    }

    cancel() {
        this.productDetail = null;
    }
}

@Pipe({ name: 'searchByProductName' })
export class searchByProductName implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.productName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}

@Pipe({ name: 'OrderByProductPipe' })
export class OrderByProductPipe implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}