export class ProductModel {    
    id?: number;
    productName?: string;
    productNumber?: string;
    productDescription?: string;    
    erpProductCode?: string;   
    erpMaterialCode?: string;
    erpProductNumber?: string;
    mfgconnectProductFamilyId?: number;
    productType?: string;
    familyName?: string;
    processPhase?: string;
    noOfManuProcessId?: string;
}