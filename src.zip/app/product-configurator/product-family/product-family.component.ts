import { OnInit, Component, ViewChild, PipeTransform, Pipe } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DeleteProduct } from '../delete-plantconfigurator/delete-plantconfigurator';
import { ProductFamilyRelationshipComponent } from './product-family-relationship';

import { ProductFamilyService } from './product-family.service';
import { ProductFamilyModel } from './product.model';


@Component({
    selector: 'productFamily',
    templateUrl: './product-family.component.html',
    styleUrls: ['../../plants/plant-configuration/plant-configuration.component.scss']
})

export class productFamilyComponent implements OnInit {
    productFamilyDetails: ProductFamilyModel[];
    productFamilyDetail: ProductFamilyModel = {}
    hideForm: boolean = false
    $localProductFamilyId: any;

    constructor(private _productFamilyService: ProductFamilyService, public dialog: MatDialog){}

    ngOnInit(){
        this.loadProductFamily();
    }

    addnew() {
        this.productFamilyDetail = {}
        this.hideForm = true;
    }

    loadProductFamily() {
        this._productFamilyService.getListofproductFamily().subscribe(
            data => this.productFamilyDetails = data
        )
    }

    details(id) {        
        this.productFamilyDetails.forEach(productFamily => {
            if (productFamily.id === id) {
                this.productFamilyDetail = productFamily;
            }
            this.hideForm = true;
        });
    }

    confirmDelete(id) {
        const dialogRef = this.dialog.open(DeleteProduct, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._productFamilyService.deleteProductFamilyById(id).subscribe(
                    () => {console.log(`Product Family deleted with id =  ${id} deleted`)},          
                    () => this.loadProductFamily()    
                )                
            }
        })       
    }

    showRelationship(getProductFamilyId): void {
        this.$localProductFamilyId = localStorage.setItem('productFamilyId', JSON.stringify(getProductFamilyId));
        const dialogRef = this.dialog.open(ProductFamilyRelationshipComponent, {
            width: '450px'
        });
    }

    save() {      
        if (this.productFamilyDetail.id == undefined ||  this.productFamilyDetail.id == null) {           
            console.log(this.productFamilyDetail);
            this._productFamilyService.createProductFamily(this.productFamilyDetail).subscribe((data) => {
                this.loadProductFamily();
            });
            this.hideForm = false;
        }
        else {
            this._productFamilyService.updateProductFamily(this.productFamilyDetail).subscribe(() => {
                this.loadProductFamily();
            });
        }
        this.hideForm = false;
    }


    cancel() {
        this.productFamilyDetail = null;        
    }

}



@Pipe({ name: 'searchByProductFamily' })
export class searchByProductFamilyName implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.productFamilyName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}

@Pipe({ name: 'OrderByProductFamily' })
export class OrderByProductFamilyPipe implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}
