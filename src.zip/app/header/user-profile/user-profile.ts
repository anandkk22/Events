import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/core';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.html',
  styleUrls: ['./user-profile.scss']
})
export class UserProfile implements OnInit {

  constructor(private _mdr: MatDialogRef<UserProfile>, private router: Router,
    private authenticationService: AuthenticationService,
    private localStorageService: LocalStorageService,
    ) {

  }
  ngOnInit() {

  }
  CloseDialog() {
    this._mdr.close(false)
  }

  logout() {
    this.CloseDialog();
    // this.router.navigate(['login']);
    this.authenticationService.logout().subscribe(() => this.router.navigate(['login'], { replaceUrl: true }));
    this.localStorageService.clear();
  }
}
