import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { EquipmentMeasureModel, EquipmentTypeModel, DataTypeModel, BaseUnitModel, NatureEnumModel } from './library.model';

@Injectable({providedIn: 'root'})
export class EquipmentMesurementDataService {
    public equipmentMeasureData: string = environment.PROCESS_API_URL + 'api/measurementparam'; 
    public equipmentType: string = environment.PROCESS_API_URL + 'api/eqipType'; 
    public dataType: string = environment.PROCESS_API_URL + 'api/dataType'; 
    public baseUnit: string = environment.PROCESS_API_URL + 'api/baseUnitEnum'; 
    public natureEnum: string = environment.PROCESS_API_URL + 'api/natureEnum'; 

    constructor(private _http: HttpClient){}

    getEquipmentMesData(): Observable<EquipmentMeasureModel[]>{
        return this._http.get<EquipmentMeasureModel[]>(this.equipmentMeasureData);
    }

    getEquipmentType(): Observable<EquipmentTypeModel[]>{
        return this._http.get<EquipmentTypeModel[]>(this.equipmentType);
    }

    getDataType(): Observable<DataTypeModel[]>{
        return this._http.get<DataTypeModel[]>(this.dataType);
    }

    getBaseUnit(): Observable<BaseUnitModel[]>{
        return this._http.get<BaseUnitModel[]>(this.baseUnit);
    }

    getNatureEnum(): Observable<NatureEnumModel[]>{
        return this._http.get<NatureEnumModel[]>(this.natureEnum);
    }

    createNewEquiMeasureData(data: EquipmentMeasureModel): Observable<EquipmentMeasureModel> {
        return this._http.post<EquipmentMeasureModel>(`${this.equipmentMeasureData}`, data, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateNewEquiMeasureData(data:EquipmentMeasureModel): Observable<void> {
        return this._http.put<void>(`${this.equipmentMeasureData}`, data, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteEquipmentMeasure(id: number): Observable<void> {
        return this._http.delete<void>(`${this.equipmentMeasureData}/${id}`);
    }

    getEquipmentMeasureById(id: number): Observable<EquipmentMeasureModel>{
        return this._http.get<EquipmentMeasureModel>(`${this.equipmentMeasureData}/${id}`);        
    }
    
}