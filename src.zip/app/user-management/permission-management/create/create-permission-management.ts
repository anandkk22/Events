import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PermissionModel } from '../permission.model';
import { PermissionManagementService } from '../permission-management.service';


@Component({
    selector: 'create-permission-management',
    templateUrl: './create-permission-management.html',
    styleUrls: ['../../role-managment/role-management.component.scss']
})

export class CreatePermissionComponent implements OnInit {
    permissions: PermissionModel[];
    private _id: number;    
    constructor(private _permissionManagementService: PermissionManagementService, 
        private _route: ActivatedRoute,
        private route: Router
    ) { }

    ngOnInit() {
        this.loadPermission();
        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
        })
        this._permissionManagementService.getReferenccePermissionById(this._id).subscribe(
            permissionDetail => this.permissions = permissionDetail
        )
    }

    loadPermission() {
        this._permissionManagementService.getReferenccePermissions().subscribe(
            permission => {
                this.permissions = permission
            }
        )
    }

    save(formData) {
        this._permissionManagementService.createNewPermission(formData.value).subscribe(
            (data: PermissionModel) => {
                console.log(data)
            },
            (error: any) => console.log(error)
        )
        this.route.navigate(['./permission-management']);        
    }

    cancel() {
        this.route.navigate(['./permission-management']);        
    }
}