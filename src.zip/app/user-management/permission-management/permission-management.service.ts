import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';


@Injectable({ providedIn: 'root' })
export class PermissionManagementService {    
    public permissionUrl: string = environment.PROCESS_API_URL + 'api/permission';    
    
    constructor(private _http: HttpClient) { }

    getReferenccePermissions(): Observable<any[]>{
        return this._http.get<any[]>(this.permissionUrl);
    }

    getReferenccePermissionById(id: number): Observable<any>{
        return this._http.get<any>(`${this.permissionUrl}/${id}`);
    }

    createNewPermission(permission: any): Observable<any> {
        return this._http.post<any>(`${this.permissionUrl}`, permission, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updatePermission(permission: any): Observable<void> {
        return this._http.put<void>(`${this.permissionUrl}`, permission, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deletePermission(id: number): Observable<void> {
        return this._http.delete<void>(`${this.permissionUrl}/${id}`);
    }
}

