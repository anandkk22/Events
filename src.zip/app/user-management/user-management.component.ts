import { Component, OnInit, Inject } from '@angular/core';
import { UserManagementService } from './user-management.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { CreateUserManagementComponent } from './create/create-user-management';

@Component({
    selector: 'user-management',
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {
    // users: any[];
    users =[];
   
    currentPage = 1;
    page = 1;
    pageSize = 10;
    stItemsByPage = 10;

    constructor(private _userManagement: UserManagementService,  public dialog: MatDialog, 
        private matDialog: MatDialog){
        for (let i = 1; i <= 14; i++) {
            this.users.push({ Name: 'Shop ' + i });
        }
    }

    ngOnInit(){
        this.getUserList();        
    }

    getUserList(){
        this._userManagement.getListofUsers().subscribe(
            user => {
                this.users = user
            }
        )
    }

    createUserManagement() {
        const matDialog = this.matDialog.open(CreateUserManagementComponent, {    
            width: '600px',
            height: '600px'       
        });

        matDialog.afterClosed().subscribe(res => {
            // this.getReferenceKPIFamilyList();
        })
    }

    edit(id: number, code: string, desc: string) {
        const dialogRef = this.matDialog.open(EditUserComponent, {
            width: '620px',
            data: { id: id, code: code, desc: desc }
        });
        dialogRef.afterClosed().subscribe(res => {
            // this.getReferenceKPIFamilyList();
        })
    }
}

@Component({
    selector: 'edit-permission-management',
})

export class EditUserComponent implements OnInit {

    constructor(private _userManagement: UserManagementService,
        public dialog: MatDialog, private _mdr: MatDialogRef<EditUserComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) { }

    ngOnInit() {
    }

    update() {
        this._userManagement.updateUser(this.data).subscribe(
            () => {
                console.log('updated')
            }
        )
        this._mdr.close(false);
    }

    CloseDialog() {
        this._mdr.close(false)
    }
}

