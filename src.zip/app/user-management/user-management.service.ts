import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({ providedIn: 'root' })
export class UserManagementService {
    public userList: string = '../../assets/json/users.json';

    constructor(private _http: HttpClient) { }


    getListofUsers(): Observable<any[]> {
        return this._http.get<any[]>(`${this.userList}`)
    }

    createUser(permission: any): Observable<any> {
        return this._http.post<any>(`${this.userList}`, permission, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateUser(permission: any): Observable<void> {
        return this._http.put<void>(`${this.userList}`, permission, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }
}