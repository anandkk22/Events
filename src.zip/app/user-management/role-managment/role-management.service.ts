import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class RoleManagementService {
    public roleType: string = '../../assets/json/roles.json';
    public permissionType: string = '../../assets/json/permission.json';
    public roleUrl: string = environment.PROCESS_API_URL + 'api/userrole';    
    public permissionUrl: string = environment.PROCESS_API_URL + 'api/permission';    

    constructor(private _http: HttpClient) { }

    getAllRoles(): Observable<any[]> {
        return this._http.get<any[]>(this.roleUrl);
    }

    getRolePermissionByRollId(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.roleUrl}/${id}`)
    }

    getPermissionType(): Observable<any[]> {
        return this._http.get<any[]>(`${this.permissionType}`);
    }

    getReferenccePermissions(): Observable<any[]>{
        return this._http.get<any[]>(this.permissionUrl);
    }

    createRolePermission(id: number, role): Observable<any[]> {
        return this._http.post<any[]>(`${this.roleUrl}/${id}`, role, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

}