import { Component, OnInit } from '@angular/core';
import { RoleManagementService } from './role-management.service';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DialogEditPermissionComponent } from './edit/dialog-edit-permission.component';

@Component({
    selector: 'role-management',
    templateUrl: './role-management.component.html',
    styleUrls: ['./role-management.component.scss']
})
export class RoleManagementComponent implements OnInit {
    authorities: any[];
    editPermissionForm: FormGroup;
    getRoleId: any;
    $localRoleId: any;
    allRoleDetails:any[]=[];
    rolesPermissions: any[] = [];

    constructor(private _roleManagementService: RoleManagementService,
        private _route: ActivatedRoute,
        public dialog: MatDialog) { }

    ngOnInit() {
        this.getRoleId = localStorage.getItem('roleId');
        this._route.paramMap.subscribe(parameterMap => {
            const id = +parameterMap.get('id');
        })
        this.getRoles();
        this.getRoleById();
    }

    getRoles() {
        this._roleManagementService.getAllRoles().subscribe(
            authority => {
                this.authorities = authority
            }
        )
    }

    editPermission(getRoleId) {
        this.getAllRoles();
        this.getRoleById();
        this.$localRoleId = localStorage.setItem('roleId', JSON.stringify(getRoleId));
        console.log("********");
        console.log(this.allRoleDetails);
        console.log(this.rolesPermissions);
        const dialogRef = this.dialog.open(DialogEditPermissionComponent, {
            width: '450px',
        });
    }

    getAllRoles(): any {
        this._roleManagementService.getReferenccePermissions().subscribe(
            (roles: any[]) => {

                this.allRoleDetails = roles
            });
    }

    getRoleById() {
        this._roleManagementService.getRolePermissionByRollId(this.getRoleId).subscribe(
            (data: any[]) => {
                this.rolesPermissions = data;
                console.log(this.rolesPermissions);
            }
        )
    }

}
