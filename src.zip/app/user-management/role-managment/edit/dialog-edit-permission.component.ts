import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RoleManagementService } from '../role-management.service';

@Component({
    selector: 'permission-management',
    templateUrl: './dialog-edit-permission.component.html',
    styleUrls: ['../role-management.component.scss']
})
export class DialogEditPermissionComponent implements OnInit {
    permissions = [];
    allRoleDetails:any[]=[];
    userPermissions: any[];
    
    rolesPermissions: any[] = [];
    getRoleId: any;
    editPermissionForm: FormGroup;
    constructor(private _roleManagementService: RoleManagementService,
        private _route: ActivatedRoute,
        private fb: FormBuilder,
        public dialog: MatDialog) { }

    ngOnInit() {
        this.getAllRoles();
        this.getRoleId = localStorage.getItem('roleId');
        this._route.paramMap.subscribe(parameterMap => {
            const id = +parameterMap.get('id');
        })
        this.getPermissionsType();
        this.editPermissionForm = this.fb.group({
            editPermissionControl: []
        });
        this._roleManagementService.getRolePermissionByRollId(this.getRoleId).subscribe(
            data => {
                this.userPermissions = data
            }
        )

        console.log(this.allRoleDetails)
        console.log(this.rolesPermissions)
        
    }

    getAllRoles(): any {
        this._roleManagementService.getReferenccePermissions().subscribe(
            (roles: any[]) => {
                this.allRoleDetails = roles
            });
    }
   

    getRoleById() {
        this._roleManagementService.getRolePermissionByRollId(this.getRoleId).subscribe(
            (data: any[]) => {
                this.rolesPermissions = data;
                console.log(this.rolesPermissions);
            }
        )
    }
    getPermissionsType() {
        this._roleManagementService.getPermissionType().subscribe(
            permission => {
                this.permissions = permission
            }
        )
    }

}