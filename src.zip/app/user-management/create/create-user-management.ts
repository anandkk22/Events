import { Component, OnInit } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserManagementService } from '../user-management.service';

@Component({
    selector: 'create-user-management',
    templateUrl: './create-user-management.html',
    styleUrls: ['../role-managment/role-management.component.scss']
})
export class CreateUserManagementComponent implements OnInit {
    languages: any[];
   
    editPermissionForm: FormGroup;
    constructor(private  _userManagement: UserManagementService,
        public dialog: MatDialog, private _mdr: MatDialogRef<CreateUserManagementComponent>
    ) { }

    ngOnInit() {       
        this.languages = [{code:1, name:'English'},{code:2, name:'Francais'}, {code:3, name:'Deutsch'}];
    }

    save(formData) {
        this._userManagement.createUser(formData.value).subscribe(
            (data: any) => {
                console.log(data)
            },
            (error: any) => console.log(error)
        )
        this._mdr.close(false);
    }

    CloseDialog() {
        this._mdr.close(false)
    }
}