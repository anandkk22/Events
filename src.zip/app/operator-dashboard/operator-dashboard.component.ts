import { Component, OnInit, Input } from '@angular/core';

import { Observable } from 'rxjs';

import * as moment from 'moment';
//import { OperatorService } from './operator.service';
import { ActivatedRoute, Params } from '@angular/router';
import { element } from 'protractor';
import { number } from '@amcharts/amcharts4/core';
import { OperatorService } from './operator-dashboard.service';
import { PlanningDashboardService } from '../planning-dashboard/planning-dashboard.service';
import { MatDialog } from '@angular/material';
import { EventsComponent } from './events.component';
import { EnterDownTimeComponent } from './enterDownTime.component';
import { EventsRejection } from './enterRejction.component';

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import * as am4coreParts from "@amcharts/amcharts4/core";
import * as am4chartsParts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import * as AmCharts from "@amcharts/amcharts3-angular";
import { AmChartsService } from '@amcharts/amcharts3-angular';
am4core.useTheme(am4themes_animated);
am4coreParts.useTheme(am4themes_animated);

@Component({
  selector: 'app-operator-dashboard',
  templateUrl: './operator-dashboard.component.html',
  styleUrls: ['./operator-dashboard.component.scss', '../production-live-dashboard/dashboard.component.scss']
})
export class OperatorDashboardComponent implements OnInit {
  showDashaboard: boolean = false;
  todaysDate = new Date();
  progressbar;
  circularProgress;
  // data: any;
  utilization: any = [];
  parts: any = [];
  operatorData: any;
  operatorList: any = [];
  startTimeStamp: any;
  endTimeStamp: any;
  clock;
  data: any;
  dataPart: any;
  job: string = '';
  jobStatus: string = '';
  jobStartSince: any
  jobStartTime: any
  jobExpectedCycle: any;
  jobExpectedCycleMinutes: any;
  jobExpectedCycleSeconds: any
  jobActualCycle: any;
  jobActualCycleMinutes: any;
  jobActualCycleSeconds: any;
  finalOee = 0;
  finalAvailability = 0;
  finalQuality = 0;
  finalPerformance = 0;
  cncMachineList: any = [];
  machineDetails = new Map();
  final_actualPlan: any = {};
  final_prodPlan: any = {};
  categoryGuide = {};
  masterPlan = {};
  masterActual = {};
  constructor(private opservice: OperatorService, private route: ActivatedRoute, private machineViewService: PlanningDashboardService,
    public dialog: MatDialog, private AmCharts: AmChartsService) { }

  ngOnInit() {
    this.machinUtilization();
    this.partsWidget();
    this.machineAvailabilityStatus();


    console.log("route is", this.route)
    const equipmentId: any = this.route.snapshot.params.id;
    console.log(equipmentId)

    this.endTimeStamp = moment().utc()
    this.startTimeStamp = moment().subtract('minutes', 5).utc().format();
    console.log("cccccc")
    console.log(this.data)

    this.machineViewService.getCNCMachines().subscribe(resp => {
      this.cncMachineList = resp;
      console.log("CNC Machines Names display", this.cncMachineList);


      this.cncMachineList.map(item => {
        // this.segments[item.id] = []

        this.final_actualPlan[item.machineName] = []

        this.machineDetails[item.id] = item.machineName;
      });

      this.machineViewService.getAllProductionSchedules().subscribe(prodPlan => {
        if (prodPlan instanceof Array) {

          prodPlan.map(ele => {
            //   this.dateAllMin.push(moment(element['startTime']).utc());
            //   this.dateAllMin.push(moment(element['actualStartTime']).utc());
            //   this.dateAllMAx.push(element['endTime']);
            //   this.dateAllMAx.push(element['actualEndTime']);
            if (ele['status'] == "RUNNING") {
              //for corresponding running schedule display a plan
              let startDatePlan = moment(ele['startTime']).utc();
              //2020-06-14T06:37:26Z
              let startHourPlan = startDatePlan.utc().hours();
              let endDatePlan = moment(ele['endTime']).utc();
              let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));

              let planHours = planDuration1.asHours();
              // console.log("!!!!!!!!!!!", planHours);
              let planColor;
              let planTask;
              let partName;
              let originalQuantity;
              ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
              ele['isTrial'] ? planTask = "TRIAL" : planTask = "PLANNED";
              ele['isTrial'] ? partName = "" : partName = ele['partName'];
              ele['isTrial'] ? originalQuantity = "" : originalQuantity = ele['originalQuantity'];

              let planData = {
                "planId": ele.id,
                "id": ele.mfgconnectEquipmentId,
                // "priority": ele['priority'],
                "start": startDatePlan,
                "duration": planHours,
                "color": planColor,
                "task": planTask,
                "partName": partName,
                "Quantity": originalQuantity,
                // "time": planMin
              }

              let planMin = planDuration1.asMinutes().toFixed(0) + " min " + planDuration1.seconds().toFixed(0).toString() + " sec";
              if (ele['isTrial'])
                planData["time"] = planMin

              // this.segments[ele.mfgconnectEquipmentId].push(planData);
              let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
              this.final_prodPlan[temp_machineName].push(planData)

              let categoryData = {
                //replace category value by machine name which is id now
                "category": temp_machineName + " Plannnn",
                "LineAlpha": 0.7,
                "expand": true,
                "position": "left",
                "tickLength": 125,

              };

              this.categoryGuide[temp_machineName] = categoryData;

              let actualDatePlan = moment(ele['actualStartTime']).utc();
              //2020-06-14T06:37:26Z
              let startHourActual = actualDatePlan.utc().hours();
              let endDateActual = moment.utc();
              let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

              let actualHours = actualDuration1.asHours();
              // console.log("!!!!!!!!!!!", planHours);
              let actualColor = "#63982d";
              let actualTask = "RUNNING";
              let actualName = ele['partName'];
              let actualQuantity = ele['quantity'];
              if (actualQuantity != null) {
                let actualData = {
                  "id": ele.mfgconnectEquipmentId,
                  // "priority": ele['priority'],
                  "start": actualDatePlan,
                  "duration": actualHours,
                  "color": actualColor,
                  "task": actualTask,
                  "partName": actualName,
                  "Quantity": actualQuantity,
                  // "time": planMin
                }
                let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                if (ele['isTrial'])
                  actualData["time"] = actualMin
                this.final_actualPlan[temp_machineName].push(actualData)
              }
              if (actualQuantity != null) {
                ele['actualStatus'] = "Running"
              }
              // this.summaryData.push(ele)
              // this.calculateSummary(this.summaryData)


              //this.segments[ele.mfgconnectEquipmentId].push(actualData);
              //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]


            }
          });
          for (var element of Object.keys(this.final_prodPlan)) {

            this.masterPlan[element] = this.final_prodPlan[element];
          }
          for (var element of Object.keys(this.final_actualPlan)) {

            this.masterActual[element] = this.final_actualPlan[element];
          }
          // this.calculateSummary(prodPlan)
        }
      });


    });

    // this.operatorData = {
    //   deviceId: id,
    //   startTimestamp: this.startTimeStamp,
    //   endTimestamp: this.endTimeStamp,
    //   parameter: null,
    //   resolution: "1"
    // }

    this.operatorList.push(this.operatorData)


    // this.opservice.getOperatorData(this.operatorList).subscribe(resp => {
    //   console.log("Operator data for display:", resp);
    //   this.data = resp;
    //   // console.log("", this.data.utilization);
    //   // console.log("", this.data.parts);
    //   this.utilization = this.data[0].readings[0].UTILIZATION;
    //   // this.utilization.forEach(element => {
    //   //   var time = element['time']
    //   //   time = time + "am";
    //   //   element['time'] = time;
    //   // });
    //   this.parts = this.data[0].readings[0].PARTS;
    //   // this.parts.forEach(element => {
    //   //   var time = element['time']
    //   //   time = time + "am";
    //   //   element['time'] = time;
    //   // })
    //   console.log("utilization", this.utilization)
    //   console.log("u", this.parts)
    //   this.progressbar = this.progressCal(this.data);
    //   this.circularProgress = this.circularProgressCal(this.data);
    // });
    // this.opservice.getOperatorData().subscribe(resp => {
    //   console.log("Operator data for display:", resp);
    //   // this.data = resp;
    //   // console.log("", this.data.utilization);
    //   // console.log("", this.data.parts);
    //   if (resp instanceof Object) {
    //     this.utilization = resp['utilization']
    //     this.parts = resp['parts']
    //     console.log("", this.utilization);
    //     console.log("", this.parts);
    //   }


    // });
    this.opservice.getCurrentJobList(equipmentId).subscribe(resp => {

      if (resp instanceof Array) {
        this.data = resp
        console.log("type of resp", this.data)
        this.job = this.data[0]['productName']
        this.jobStatus = this.data[0]['status']
        this.jobStartTime = this.data[0]['actualStartTime'];
        this.jobExpectedCycle = this.data[0]['cycleTime'];
        this.jobExpectedCycleMinutes = Math.floor(this.jobExpectedCycle / 60);
        this.jobExpectedCycleSeconds = (this.jobExpectedCycle - this.jobExpectedCycleMinutes * 60)
        this.jobActualCycle = this.data[0]['actualCycleTime']
        this.jobActualCycleMinutes = Math.floor(this.jobActualCycle / 60);
        this.jobActualCycleSeconds = (this.jobActualCycle - this.jobActualCycleMinutes * 60)
        var currentTime = moment().utc()
        this.startTimeStamp = moment(this.data[0]['actualStartTime']).utc();
        if (this.endTimeStamp instanceof moment && this.startTimeStamp instanceof moment) {
          var duration = moment.duration(currentTime.diff(this.startTimeStamp))
          var minutes = duration.asMinutes()
          this.jobStartSince = minutes
        }

        console.log("start time:{}", this.jobStartSince)
        this.circularProgressCal(this.data)
      }

    })

    this.opservice.getKpiData(equipmentId).subscribe(resp => {
      console.log("kpi data is:", resp)
      var oeeArray = [];
      var qualityArray = []
      var performanceArray = []
      var availabiltyArray = []
      if (resp instanceof Array) {
        resp.forEach(element => {
          var oeeString = element.hourlyKPI.hourlyOee
          var oee = parseInt(oeeString)
          oeeArray.push(oee)
          var qualityString = element.hourlyKPI.hourlyQuality
          var quality = parseInt(qualityString)
          qualityArray.push(quality)
          var performanceString = element.hourlyKPI.hourlyPerformance
          var performance = parseInt(performanceString)
          performanceArray.push(performance)
          var availabilityString = element.hourlyKPI.hourlyAvailability
          var availability = parseInt(availabilityString)
          availabiltyArray.push(availability)
        })
        console.log("oee array is", oeeArray)
      }
      var availLength = 1;
      //var finalOee = 0
      for (var i = 0; i < oeeArray.length; i++) {
        this.finalOee = this.finalOee + oeeArray[i];
      }
      for (var i = 0; i < qualityArray.length; i++) {
        this.finalQuality = this.finalQuality + qualityArray[i];
      }
      for (var i = 0; i < performanceArray.length; i++) {
        this.finalPerformance = this.finalPerformance + performanceArray[i];
      }
      for (var i = 0; i < availabiltyArray.length; i++) {
        if (availabiltyArray[i] != undefined) {
          this.finalAvailability = this.finalAvailability + availabiltyArray[i];
          availLength++;
        }


      }
      this.finalOee = this.finalOee / oeeArray.length
      this.finalQuality = this.finalQuality / qualityArray.length;
      this.finalPerformance = this.finalPerformance / performanceArray.length;
      this.finalAvailability = this.finalAvailability / availLength;
      console.log("final oee is", this.finalOee)
    })
    this.opservice.getHourSpecificData(equipmentId).subscribe(resp => {

      if (resp instanceof Array) {
        var tempParts = []
        var maxParts = [];
        var utilParts = []
        var length = resp.length;
        resp.forEach(element => {
          var stringParts = element.hourLevelAggregation.hourlyActualProduction
          var parts = parseInt(stringParts)
          maxParts.push(parts)
          //console.log("!!!!!!!", parts)
          var time = element.timestamp
          time = moment(time).utc().format("hh:mm a")
          var obj = {
            "parts": parts,
            "time": time
          }
          tempParts.push(obj)
        })

        // console.log("%%%%%%%%", obj)
        var max = maxParts[0]
        for (var i = 1; i < maxParts.length; i++) {

          if (maxParts[i] > max) {
            max = maxParts[i]
          }
        }
        console.log("type of:{}", typeof (max))
        // maxParts.forEach(item => {
        //   if (item == max) {
        //     var util = {
        //       "parts": 100,
        //       "time": time
        //     }
        //     utilParts.push(util)
        //   } else {
        //     var x = (100 * item) / max
        //     var util = {
        //       "parts": x,
        //       "time": time
        //     }
        //     utilParts.push(util)
        //   }
        // })

        for (var i = 0; i < tempParts.length; i++) {
          console.log("final max is:{}", max)
          var a = tempParts[i].parts
          var time = tempParts[i].time
          if (a == max) {
            console.log(" a is ", a)
            var util = {
              "parts": 100,
              "time": time
            }
            utilParts.push(util)

          }
          else {
            var x = (100 * a) / max
            var util = {
              "parts": x,
              "time": time
            }
            utilParts.push(util)

          }
        }
        console.log("max parts is:{}", max)


        this.utilization = utilParts
        console.log("utilization array is:{}", this.utilization)
        this.parts = tempParts
        // var stringParts = resp[length - 1].hourLevelAggregation.hourlyActualProduction
        // console.log("type of parts is", typeof (stringParts))

        // var parts = parseInt(stringParts)
        // console.log("type of parts is", typeof (parts))
        // var time = resp[length - 1].timestamp
        // time = moment(time).utc().format("hh:mm")
        // console.log("parts is:", parts, time)
        // var obj = {
        //   "parts": 24,
        //   "time": "10am"
        // }
        //this.parts.push(obj)
        //  console.log("final array is:", this.parts)
      }
    })
  }

  progressCal(data) {
    let produce = data[0].readings[0].PRODUCTION_PLAN['PRODUCED']
    console.log("produce", this.data[0].readings[0])
    let required = data[0].readings[0].PRODUCTION_PLAN['REQUIRED']
    this.progressbar = [(produce / required) * 100];
    return this.progressbar + "%";

  }
  circularProgressCal(data) {
    let actual = data[0]['quantity']
    let expected = data[0]['originalQuantity']
    this.circularProgress = [(actual / expected) * 100];
    console.log("circle data", this.circularProgress)
    return this.circularProgress;

  }

  getEvents() {
    const dialogRef = this.dialog.open(EventsComponent, {
      width: '450px'
    });
  }

  getDownTimeEntry() {
    const dialogRef = this.dialog.open(EnterDownTimeComponent, {
      width: '550px'
    });
  }

  getRejectionTimeEntry() {
    const dialogRef = this.dialog.open(EventsRejection, {
      width: '250px'
    });
  }

  showDashboard() {
    this.showDashaboard = !this.showDashaboard
  }

  machinUtilization() {
    let chart = am4core.create("chartdiv", am4charts.XYChart);
    chart.data = [{
      "time": "7am",
      "Part Utilization Percentage": 15
    }, {
      "time": "8am",
      "Part Utilization Percentage": 70
    }, {
      "time": "9am",
      "Part Utilization Percentage": 65
    }, {
      "time": "10am",
      "Part Utilization Percentage": 90
    }, {
      "time": "11am",
      "Part Utilization Percentage": 85
    }, {
      "time": "12pm",
      "Part Utilization Percentage": 66
    }, {
      "time": "1pm",
      "Part Utilization Percentage": 66
    }, {
      "time": "2pm",
      "Part Utilization Percentage": 78
    }, {
      "time": "3pm",
      "Part Utilization Percentage": 68
    }, {
      "time": "4pm",
      "Part Utilization Percentage": 55
    }, {
      "time": "5pm",
      "Part Utilization Percentage": 89
    }, {
      "time": "6pm",
      "Part Utilization Percentage": 60
    }, {
      "time": "7pm",
      "Part Utilization Percentage": 76
    }];

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.minX = 0;
    categoryAxis.dataFields.category = "time";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 5;
    // categoryAxis.renderer.grid.template.disabled = true;


    let valueyAxis = chart.yAxes.push(new am4charts.ValueAxis());
    let valuexAxis = chart.xAxes.push(new am4charts.ValueAxis());

    valueyAxis.title.text = "Part Utilization Percentage (%)";
    // categoryAxis.renderer.line.disabled = true
    // categoryAxis.renderer.grid.template.disabled = false;
    // categoryAxis.renderer.grid.template.strokeWidth = 0;    
    // categoryAxis.renderer.line.disabled = true;
    // categoryAxis.renderer.labels.template.disabled = false;
    // categoryAxis.renderer.grid.template.disabled = false;        

    valuexAxis.title.text = "Shifts";

    categoryAxis.marginTop = -55;
    // categoryAxis.renderer.cellEndLocation = 0.8;
    let series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = "Part Utilization Percentage";
    series.dataFields.categoryX = "time";
    series.name = "Part Utilization Percentage";
    series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
    series.fill = am4core.color("#3DB6FF");
    series.columns.template.fillOpacity = 1;
    series.columns.template.width = am4core.percent(70);
    let columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 0;
    columnTemplate.strokeOpacity = 0;
  }

  partsWidget() {
    let chartParts = am4core.create("partsDvi", am4charts.XYChart);

    chartParts.data = [{
      "timePart": "7am",
      "part": 5
    }, {
      "timePart": "8am",
      "part": 24
    }, {
      "timePart": "9am",
      "part": 33
    }, {
      "timePart": "10am",
      "part": 18
    }, {
      "timePart": "11am",
      "part": 60
    }, {
      "timePart": "12pm",
      "part": 26
    }, {
      "timePart": "1pm",
      "part": 18
    }, {
      "timePart": "2pm",
      "part": 30
    }, {
      "timePart": "3pm",
      "part": 18
    }, {
      "timePart": "4pm",
      "part": 19
    }, {
      "timePart": "5pm",
      "part": 34
    }, {
      "timePart": "6pm",
      "part": 33
    }, {
      "timePart": "7pm",
      "part": 26
    }];

    let categoryAxis = chartParts.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "timePart";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 5;
    // categoryAxis.renderer.grid.template.disabled = true;

    let valueyAxis = chartParts.yAxes.push(new am4charts.ValueAxis());
    let valuexAxis = chartParts.xAxes.push(new am4charts.ValueAxis());

    valueyAxis.title.text = "Number of Parts";
    // categoryAxis.renderer.grid.template.disabled = true;
    valuexAxis.title.text = "Shifts";
    categoryAxis.marginTop = -56;

    // categoryAxis.renderer.cellEndLocation = 0.8;
    let series = chartParts.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = "part";
    series.dataFields.categoryX = "timePart";
    series.name = "part";
    series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
    series.fill = am4core.color("#3DB6FF");
    series.columns.template.fillOpacity = 1;
    series.columns.template.width = am4core.percent(70);
    let columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 0;
    columnTemplate.strokeOpacity = 0;
  }

  machineAvailabilityStatus() {
    let chart = am4core.create("ganttChart", am4charts.XYChart);
    chart.hiddenState.properties.opacity = 0; 
    chart.paddingRight = 30;
    chart.dateFormatter.inputDateFormat = "yyyy-MM-dd HH:mm";

    let colorSet = new am4core.ColorSet();
    colorSet.saturation = 0.4;

    chart.data = [
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 07:00",
        toTime: "2018-01-01 08:00" ,
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 08:01",
        toTime: "2018-01-01 09:00",
        color: "#FA6D6D" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 09:01",
        toTime: "2018-01-01 10:00",
        color: "#41CF76" 
      },

      {
        date: "2018-01-01",
        fromTime: "2018-01-01 10:01",
        toTime: "2018-01-01 11:00",
        color: "#FFAC5B" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 11:01",
        toTime: "2018-01-01 12:00",
        color: "#FA6D6D" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 12:01",
        toTime: "2018-01-01 13:00",
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 13:01",
        toTime: "2018-01-01 14:00",
        color: "#FA6D6D" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 14:01",
        toTime: "2018-01-01 15:00",
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 15:01",
        toTime: "2018-01-01 16:00",
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 16:01",
        toTime: "2018-01-01 17:00",
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 17:01",
        toTime: "2018-01-01 18:00",
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 18:01",
        toTime: "2018-01-01 19:00",
        color: "#41CF76" 
      },
      {
        date: "2018-01-01",
        fromTime: "2018-01-01 19:01",
        toTime: "2018-01-01 20:00",
        color: "#41CF76" 
      }
    ];

    let categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "date";    
    categoryAxis.renderer.grid.template.location = 10;
    categoryAxis.renderer.inversed = true;
    categoryAxis.paddingLeft = 0;
    categoryAxis.paddingBottom = 0;
    categoryAxis.title.text = "Date";
    categoryAxis.layout = "absolute";
    categoryAxis.title.rotation = 0;
    categoryAxis.title.align = "center";
    categoryAxis.title.valign = "middle";
    categoryAxis.title.dy = -20;
    let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
    dateAxis.renderer.minGridDistance = 40;
    dateAxis.baseInterval = { count: 60, timeUnit: "minute" };
    dateAxis.renderer.tooltipLocation = 0;    

    let series1 = chart.series.push(new am4charts.ColumnSeries());
    series1.columns.template.width = am4core.percent(40);
    series1.columns.template.height = am4core.percent(30);
    series1.columns.template.tooltipText = "{fromTime} - {toTime}";

    series1.dataFields.openDateX = "fromTime";
    series1.dateFormatter.dateFormat = "HH-mm";
    series1.dataFields.dateX = "toTime";    
    series1.dataFields.categoryY = "date";
    
    series1.columns.template.propertyFields.fill = "color"; 
    series1.columns.template.propertyFields.stroke = "color";
    series1.columns.template.strokeOpacity = 1;

    chart.scrollbarX = new am4core.Scrollbar();
  }
}
