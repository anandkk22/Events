import { BrowserModule } from "@angular/platform-browser";
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { ApollowebHomeModule } from "./home/home.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MaterialModule } from "./material.module";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HeaderComponent } from "./header/header.component";
import { PlantsComponent } from "./plants/plants.component";
import { MatTooltipModule } from "@angular/material/tooltip";
import { CategoriesComponent } from "./categories/categories.component";
import { NgCircleProgressModule } from "ng-circle-progress";
import { UserProfile } from "./header/user-profile/user-profile";
import { PlantDetailsComponent } from "./plants/plant-details/plant-details.component";
import { AngularFontAwesomeModule } from "angular-font-awesome";
import { AgmCoreModule } from "@agm/core";
import { searchByPlantName, OrderByPipe, searchByEquipmentName } from "./plants/searchandFilter.pipe";
import { EquipmentComponent } from "./equipment/equipment.component";
import { IdeComponent } from "./equipment/ide/ide.component";
import { searchCatetories } from "./categories/searchbyCategories.pipe";
import { PlantConfigurationComponent } from "./plants/plant-configuration/plant-configuration.component";
import { UserPreferenceSetting } from "./header/user-preference-setting/user-preference-setting";
import { AddPlantComponent } from "./plants/add-plant/add-plant.component";
import { DeletePlant } from "./plants/delete-plant/delete-plant";
import { Select2Module } from "ng2-select2";
import { AreaComponent, searchAreaPlantName } from "./plants/plant-configuration/area/area.component";
import { ProcessCellComponent } from "./plants/plant-configuration/process-cell/process-cell.component";
import { RelationshipPlantComponent } from "./plants/relationship-plant/relationship-plant";
import { SidenavComponent } from './shared/sidenav/sidenav.component';
import { ProcessUnitComponent } from './plants/plant-configuration/process-unit/process-unit.component';
import { ReactorComponent } from './plants/plant-configuration/reactors/reactors.component';
import { PumpsComponent } from './plants/plant-configuration/pumps/pumps.component';
import { LibraryComponent } from './library/library.component';
import { searchPlantConfigName, OrderByPlantConfigPipe } from './plants/plant-configuration/searchandFilter.pipe';
import { EquipmentMeasurementDataComponent } from './library/parameter-tags/equipment-measurement-data/equipment-measurement-data';
import { EquipmentModule } from './library/equipment-module';
import { AuthInterceptor } from 'src/app/blocks/interceptor/auth.interceptor';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
import { CoreModule } from './core';
import { TranslateModule } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { ServiceWorkerModule } from '@angular/service-worker';
import { CookieService } from 'ngx-cookie-service';
import { FooterComponent } from './footer/footer.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AmChartsModule } from "@amcharts/amcharts3-angular";
import { ProductionLiveDashboardComponent } from './production-live-dashboard/production-live-dashboard.component';
import { PlanningDashboardComponent } from './planning-dashboard/planning-dashboard.component';
import { CncMachineComponent } from './plants/plant-configuration/cnc-machine/cnc-machine.component';
import { OperatorDashboardComponent } from './operator-dashboard/operator-dashboard.component';
import { MatInputModule } from '@angular/material';
import { CentrifugesComponent } from './plants/plant-configuration/centrifuges/centrifuges.component';
import { CompressorsComponent } from './plants/plant-configuration/compressors/compressors.component';
import { AgitatorsComponent } from './plants/plant-configuration/agitators/agitators.component';
import { OperatorModule } from './operator-dashboard/operator-dashboard.module';
import { searchByEquipmentMeasure, OrderEquipmentMeasure } from './library/parameter-tags/equipment-measurement-data/searchEquipment.pipe';
import { ReferenceKPIComponent } from './library/parameter-tags/reference_KPI_family/reference-kpi-family';
import { searchByKpiData, OrderKpiData } from './library/parameter-tags/reference_KPI_family/searchKPI.pipe';
import { RemoteMonitoringDashboardComponent } from './processapp/remote-monitoring-dashboard/remote-monitoring-dashboard.component';
import { BatchAnalysisDashboardComponent } from './processapp/batch-analysis-dashboard/batch-analysis-dashboard.component';
import { AreaRelationshipComponent } from './plants/plant-configuration/area/area-relationship';
import { ProcessCellRelationshipComponent } from './plants/plant-configuration/process-cell/processcell-relationship';
import { ProcessUnitRelationshipComponent } from './plants/plant-configuration/process-unit/processunit-relationship';
import { AgitatorRelationshipComponent } from './plants/plant-configuration/agitators/agitator-relationship';
import { CentrifugeRelationshipComponent } from './plants/plant-configuration/centrifuges/centrifuge-relationship';
import { CompressoreRelationshipComponent } from './plants/plant-configuration/compressors/compressor-relationship';
import { PumpRelationshipComponent } from './plants/plant-configuration/pumps/pump-relationship';
import { ReactorRelationshipComponent } from './plants/plant-configuration/reactors/reactor-relationship';
import { UserManagementComponent, } from './user-management/user-management.component';
import { RoleManagementComponent } from './user-management/role-managment/role-management.component';
import { PermissionManagementComponent, DeletePermisionItem, OrderByPipeId } from './user-management/permission-management/permission-management.component';
import { AdminPanelFrontPage } from './user-management/admin-panel-frontPage';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CreateUserManagementComponent } from './user-management/create/create-user-management';
import { EnergyDashboardComponent } from './processapp/energy-dashboard/energy-dashboard.component';
import { DialogEditPermissionComponent } from './user-management/role-managment/edit/dialog-edit-permission.component';
import { NgxMatDatetimePickerModule, NgxMatTimepickerModule, NgxMatNativeDateModule } from '@angular-material-components/datetime-picker';
import { CreatePermissionComponent } from './user-management/permission-management/create/create-permission-management';
import { ViewPermissionComponent } from './user-management/permission-management/view/view-permission-management';
import { EditPermissionComponent } from './user-management/permission-management/edit/edit-permission-management';
import { ProductConfigurationComponent } from './product-configurator/product-configurator.component';
import { OrderByProductFamilyPipe, productFamilyComponent, searchByProductFamilyName } from './product-configurator/product-family/product-family.component';
import { DeleteProduct } from './product-configurator/delete-plantconfigurator/delete-plantconfigurator';
import { ProductFamilyRelationshipComponent } from './product-configurator/product-family/product-family-relationship';
import { OrderByProductPipe, Product, searchByProductName, } from './product-configurator/product/product.component';
import { ProductRelationship } from './product-configurator/product/product-relationship';
import { ComponentProduct, OrderByComponentPipe, searchByComponent } from './product-configurator/component-product/component-product';
import { ComponentRelationship } from './product-configurator/component-product/component-relationship';
import { MoldMasterComponent, OrderByMoldMaster, searchByMoldName } from './product-configurator/mold-master/mold-master.component';
import { MoldMasterRelationshipComponent } from './product-configurator/mold-master/mold-master-relationship';
import { EventsComponent } from './operator-dashboard/events.component';
import { EnterDownTimeComponent } from './operator-dashboard/enterDownTime.component';
import { EventsRejection } from './operator-dashboard/enterRejction.component';
import { InjectionMoldComponent } from './plants/plant-configuration/injection-mold/injection-mold.component';
import { InjectionMoldingMachineComponent } from './plants/plant-configuration/injection-molding-machine/injection-molding-machine.component';
import { ProductionLineComponent } from './plants/plant-configuration/production-line/production-line.component';
import { Dashboard } from './dashboards/dashboard.component';
import { InjectionMoldRelationshipComponent } from './plants/plant-configuration/injection-mold/injection-mold-relationship';
import { InjectionMoldingMachineRelationshipComponent } from './plants/plant-configuration/injection-molding-machine/injection-molding-machine-relationship';
import { ProductionLineRelationshipComponent } from './plants/plant-configuration/production-line/production-line-relationship';
import { ManufacturingProcessComponent } from './library/parameter-tags/manufacturing-process/manufacturing-process.component';
import { CreateManufacturingProcessComponent } from './library/parameter-tags/manufacturing-process/create-manufacturing-process/create-manufacturing-process.component';
import { EditManufacturingProcessComponent } from './library/parameter-tags/manufacturing-process/edit-manufacturing-process/edit-manufacturing-process.component';
import { ViewManufacturingProcessComponent } from './library/parameter-tags/manufacturing-process/view-manufacturing-process/view-manufacturing-process.component';
import { AssemblyProcessComponent } from './library/parameter-tags/assembly-process/assembly-process.component';
import { CreateAssemblyProcessComponent } from './library/parameter-tags/assembly-process/create-assembly-process/create-assembly-process.component';
import { EditAssemblyProcessComponent } from './library/parameter-tags/assembly-process/edit-assembly-process/edit-assembly-process.component';
import { ViewAssemblyProcessComponent } from './library/parameter-tags/assembly-process/view-assembly-process/view-assembly-process.component';
import { PlanteventsComponent } from './plantevents/plantevents/plantevents.component';



@NgModule({
  declarations: [
    AppComponent,
    RemoteMonitoringDashboardComponent,
    HeaderComponent,
    PlantsComponent,
    CategoriesComponent,
    UserProfile,
    PlantDetailsComponent,
    searchByPlantName,
    OrderByPipe,
    EquipmentComponent,
    IdeComponent,
    searchCatetories,
    PlantConfigurationComponent,
    UserPreferenceSetting,
    AddPlantComponent,
    DeletePlant,
    AreaComponent,
    ProcessCellComponent,
    RelationshipPlantComponent,
    BatchAnalysisDashboardComponent,
    SidenavComponent,
    ProcessUnitComponent,
    ReactorComponent,
    PumpsComponent,
    LibraryComponent,
    EquipmentMeasurementDataComponent,
    searchPlantConfigName,
    OrderByPlantConfigPipe,
    FooterComponent,
    ProductionLiveDashboardComponent,
    PlanningDashboardComponent,
    CncMachineComponent,
    /// OperatorDashboardComponent,
    AgitatorsComponent,
    CompressorsComponent,
    CentrifugesComponent,
    searchByEquipmentMeasure,
    OrderEquipmentMeasure,
    ReferenceKPIComponent,
    searchByKpiData,
    OrderKpiData,
    AreaRelationshipComponent,
    ProcessCellRelationshipComponent,
    ProcessUnitRelationshipComponent,
    AgitatorRelationshipComponent,
    CentrifugeRelationshipComponent,
    CompressoreRelationshipComponent,
    PumpRelationshipComponent,
    ReactorRelationshipComponent,
    UserManagementComponent,
    RoleManagementComponent,
    DialogEditPermissionComponent,
    PermissionManagementComponent,
    CreatePermissionComponent,
    ViewPermissionComponent,
    EditPermissionComponent,
    DeletePermisionItem,
    AdminPanelFrontPage,
    CreateUserManagementComponent,
    EnergyDashboardComponent,
    searchByEquipmentName,
    OrderByPipeId,
    searchAreaPlantName,
    ProductConfigurationComponent,
    productFamilyComponent,
    DeleteProduct,
    ProductFamilyRelationshipComponent,
    Product,
    ProductRelationship,
    ComponentProduct,
    ComponentRelationship,
    MoldMasterComponent,
    MoldMasterRelationshipComponent,
    EventsComponent,
    EnterDownTimeComponent,
    searchByProductFamilyName,
    OrderByProductFamilyPipe,
    EventsRejection,
    InjectionMoldComponent,
    searchByProductName,
    OrderByProductPipe,
    searchByComponent,
    OrderByComponentPipe,
    searchByMoldName,
    OrderByMoldMaster,
    InjectionMoldingMachineComponent,
    ProductionLineComponent,
    Dashboard,
    InjectionMoldRelationshipComponent,
    InjectionMoldingMachineRelationshipComponent,
    ProductionLineRelationshipComponent,
    ManufacturingProcessComponent,
    CreateManufacturingProcessComponent,
    EditManufacturingProcessComponent,
    ViewManufacturingProcessComponent,
    AssemblyProcessComponent,
    CreateAssemblyProcessComponent,
    EditAssemblyProcessComponent,
    ViewAssemblyProcessComponent,
    PlanteventsComponent

  ],
  imports: [
    BrowserModule,
    NgbModule,
    ServiceWorkerModule.register('./ngsw-worker.js', { enabled: environment.production }),
    AppRoutingModule,
    ApollowebHomeModule,
    EquipmentModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    MatTooltipModule,
    FormsModule,
    MatInputModule,
    NgCircleProgressModule.forRoot({
      backgroundOpacity: 0,
      maxPercent: 100,
      outerStrokeWidth: 12,
      innerStrokeWidth: 6,
    }),
    AngularFontAwesomeModule,
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyAFNpZuyBiASCw2mbMNGnYA48ks2NdUIn8",
    }),
    Select2Module,
    CoreModule,
    TranslateModule.forRoot(),
    NgxSpinnerModule,
    AmChartsModule,
    OperatorModule,
    ReactiveFormsModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule
  ],
  providers: [CookieService, {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true,
    deps: [LocalStorageService, SessionStorageService]
  }],

  bootstrap: [AppComponent],
  entryComponents: [
    UserProfile,
    UserPreferenceSetting,
    DeletePlant,
    RelationshipPlantComponent,
    AreaRelationshipComponent,
    ProcessCellRelationshipComponent,
    ProcessUnitRelationshipComponent,
    AgitatorRelationshipComponent,
    CentrifugeRelationshipComponent,
    CompressoreRelationshipComponent,
    PumpRelationshipComponent,
    ReactorRelationshipComponent,
    DialogEditPermissionComponent,
    CreatePermissionComponent,
    DeletePermisionItem,
    CreateUserManagementComponent,
    DeleteProduct,
    ProductFamilyRelationshipComponent,
    ProductRelationship,
    ComponentRelationship,
    MoldMasterRelationshipComponent,
    EventsComponent,
    EnterDownTimeComponent,
    EventsRejection,
    InjectionMoldRelationshipComponent,
    InjectionMoldingMachineRelationshipComponent,
    ProductionLineRelationshipComponent,
    CreateManufacturingProcessComponent,
    ViewManufacturingProcessComponent,
    EditManufacturingProcessComponent,
    CreateAssemblyProcessComponent,
    EditAssemblyProcessComponent,
    ViewAssemblyProcessComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
