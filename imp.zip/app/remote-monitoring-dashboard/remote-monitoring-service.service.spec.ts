import { TestBed } from '@angular/core/testing';

import { RemoteMonitoringServiceService } from './remote-monitoring-service.service';

describe('RemoteMonitoringServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RemoteMonitoringServiceService = TestBed.get(RemoteMonitoringServiceService);
    expect(service).toBeTruthy();
  });
});
