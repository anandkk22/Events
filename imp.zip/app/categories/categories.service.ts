import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({ providedIn: 'root' })
export class CategoriesService {
    public url: string = "./assets/json/menu.json";
	
	public welcomeurl: string = "http://localhost:8080/services/mfgconnectprocessapp/api/welcome";
    constructor(private _http: HttpClient) { }


    getcategories(): Observable<any> {
        return this._http.get<any>(this.url)
    }


	welcome():Observable<any>{
			return this._http.get<any>(this.welcomeurl);
	}
}