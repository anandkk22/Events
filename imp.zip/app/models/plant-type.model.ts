export class PlantType {
    id: number;
    name: string;
}