export class OrgTypeModel {
    id: number;
    name: string;
    successful: boolean;
}