export class segmentModel {
    code: number;
    name: string;
    desc: string;
    successful: boolean;
}