import { Pipe, PipeTransform } from '@angular/core';
import { pidiliteMainModel } from '../models/pidilite-model';

@Pipe({ name: 'searchBy' })
export class searchByPlantName implements PipeTransform {
  transform(items: pidiliteMainModel[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}


@Pipe({ name: 'OrderBy' })
export class OrderByPipe implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}