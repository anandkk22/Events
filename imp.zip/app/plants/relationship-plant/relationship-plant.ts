import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
    selector: 'app-user-profile',
    templateUrl: './relationship-plant.html',
    styleUrls: ['./relationship-plant.scss']
})
export class RelationshipPlantComponent{

    constructor(private _mdr: MatDialogRef<RelationshipPlantComponent>) {

    }

    onNoClick(): void {
        this._mdr.close();
    }


}
