import { OnInit, Component, ViewChild } from '@angular/core';
import { AreaService } from './area.service';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from '../../../models/Pidilite-Plant.model';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AreaModel } from './area.model';

@Component({
    selector: 'area',
    templateUrl: './area.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class AreaComponent implements OnInit {
    plantConfigAreaDetails: AreaModel[];
    area: AreaModel;
    plantConfigAreaDetail = null;
    mountTechnologies = [{ id: 1, name: 'Hybrid' }, { id: 2, name: 'Fixed Tilt' }, { id: 3, name: 'Seasonal Tilt' }, { id: 4, name: 'Single Axis Tracker' }, { id: 5, name: 'Dual Asix Tracker' }];
    plantTypes = [{ id: 1, name: 'Grounded Moulded Utility' }, { id: 2, name: 'Rooftop Distributed' }];
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;

    constructor(private _areaService: AreaService, public dialog: MatDialog, private _route: ActivatedRoute) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');            
            this._areaService.getListofAreas(this.getPlantId).subscribe(
                area => {
                    this.plantConfigAreaDetails = area
                }
            )
        })
        this.plantConfigAreaDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._areaService.deleteAreaById(id).subscribe(
                    () => console.log(`Area deleted with id =  ${id} deleted`)
                )
            }
        })
    }

    showRelationship(id): void {
        const dialogRef = this.dialog.open(RelationshipPlantComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigAreaDetails.forEach(area => {
            if (area.id === id) {
                this.plantConfigAreaDetail = area;
            }
        });
    }

    addnew() {
        this.plantConfigAreaDetail = new AreaModel();
    }

    isActiveClass(area) {
        this._areaService.isActiveClass(this.plantConfigAreaDetails, area)
    }

    save() {
        if (this.plantConfigAreaDetail.id !== undefined) {
            this._areaService.createNewArea(this.area).subscribe(
                (data: AreaModel) => {
                    console.log(data);
                }
            )
        }
        else {
            this._areaService.updateArea(this.area).subscribe(
                () => {
                    console.log('updated area')
                }
            )
        }
    }

    cancel() {
        this.plantConfigAreaDetail = null;
        // this.getlistOfAreas();
    }
}