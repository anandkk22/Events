import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AreaModel } from './area.model';

@Injectable({ providedIn: 'root' })
export class AreaService {
    public listofArea: string = environment.PROCESS_API_URL + 'api/area/plant';
    public addUpdateArea: string = environment.PROCESS_API_URL + 'api/area';
    public getArea: string = environment.PROCESS_API_URL + 'api/area';
    public deleteArea: string = environment.PROCESS_API_URL + 'api/area';

    constructor(private _http: HttpClient) { }
    
    getListofAreas(id: number): Observable<AreaModel[]> {
        return this._http.get<AreaModel[]>(`${this.listofArea}/${id}`)
    }

    getAreaById(id: number): Observable<AreaModel> {
        return this._http.get<AreaModel>(`${this.getArea}/${id}`)

    }

    createNewArea(area: AreaModel): Observable<AreaModel> {
        return this._http.post<AreaModel>(`${this.addUpdateArea}`, area, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateArea(area: AreaModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateArea}`, area, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteAreaById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.deleteArea}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}