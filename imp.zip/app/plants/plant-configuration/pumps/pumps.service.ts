import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { PumpsModel } from './pumps.model';

@Injectable({ providedIn: 'root' })
export class PumpService {
    public listofPumps: string = environment.PROCESS_API_URL + 'api/pumps/plant';
    public getPump: string = environment.PROCESS_API_URL + 'api/pump';
    public addUpdatePump: string = environment.PROCESS_API_URL + 'api/pump';
    public deletePump: string = environment.PROCESS_API_URL + 'api/pump';
    public processCellByPlantId = environment.PROCESS_API_URL + "api/processcell/plant";
    public processUnitByPlantId = environment.PROCESS_API_URL + "api/processunit/plant"

    public pumpType = environment.PROCESS_API_URL + "api/getAllPumpTypes"
    constructor(private _http: HttpClient) { }

    getListofPumps(id: number): Observable<PumpsModel[]> {
        return this._http.get<PumpsModel[]>(`${this.listofPumps}/${id}`);
    }

    getPumpById(id: number): Observable<PumpsModel> {
        return this._http.get<PumpsModel>(`${this.getPump}/${id}`);
    }

    createNewPump(pump: PumpsModel): Observable<PumpsModel> {
        return this._http.post<PumpsModel>(`${this.addUpdatePump}`, pump, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updatePump(pump: PumpsModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdatePump}`, pump, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deletePumpById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.deletePump}/${id}`);
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }

    getProcessCellByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processCellByPlantId}/${id}`);
    }
    getProcessUnitByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processUnitByPlantId}/${id}`);
    }

    getPumpTypes() {
        return this._http.get<any>(`${this.pumpType}`);
    }
}