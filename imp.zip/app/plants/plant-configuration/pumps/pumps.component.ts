import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PumpService } from './pumps.service';
import { ActivatedRoute } from '@angular/router';
import { PumpsModel } from './pumps.model';


@Component({
    selector: 'app-pumps',
    templateUrl: './pumps.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class PumpsComponent implements OnInit {
    plantConfigPumpsDetails: PumpsModel[];
    pump: PumpsModel;
    plantConfigPumpsDetail: any = {};
    mountTechnologies = [{ id: 1, name: 'Hybrid' }, { id: 2, name: 'Fixed Tilt' }, { id: 3, name: 'Seasonal Tilt' }, { id: 4, name: 'Single Axis Tracker' }, { id: 5, name: 'Dual Asix Tracker' }];
    plantTypes = [{ id: 1, name: 'Grounded Moulded Utility' }, { id: 2, name: 'Rooftop Distributed' }];
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;
    processUnits: any = [];
    pumpTypes: any = [];
    constructor(private _pumpService: PumpService, public dialog: MatDialog, private _route: ActivatedRoute) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigPumpsDetail.mfgconnectSiteId = this.getPlantId;

        this._pumpService.getProcessUnitByPlantId(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("process unit", this.processUnits);
        });

        this._pumpService.getPumpTypes().subscribe((resp) => {
            this.pumpTypes = resp;
            console.log("pump", this.pumpTypes);
        });
        this.plantConfigPumpsDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';

        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._pumpService.getListofPumps(this.getPlantId).subscribe(
                pump => {
                    this.plantConfigPumpsDetails = pump
                }
            )
        })
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigPumpsDetails) {
            if (sortFilter === 'id') {
                this.plantConfigPumpsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigPumpsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._pumpService.deletePumpById(id).subscribe(
                    () => console.log(`Pump deleted with id =  ${id} deleted`)
                )
            }
        })
    }

    showRelationship(id): void {
        const dialogRef = this.dialog.open(RelationshipPlantComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigPumpsDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigPumpsDetail = proessCell;
            }
        });
    }

    addnew() {
        this.plantConfigPumpsDetail = new PidiliteUtilityPlant();
    }

    isActiveClass(processCell) {
        this._pumpService.isActiveClass(this.plantConfigPumpsDetails, processCell)
    }

    save() {
        console.log("pump save", this.plantConfigPumpsDetail);
        // if (this.plantConfigPumpsDetail.id == undefined) {
        this._pumpService.createNewPump(this.plantConfigPumpsDetail).subscribe(
            (data) => {
                console.log(data);
            }
        )
    }
    // else {
    //     this._pumpService.updatePump(this.pump).subscribe(
    //         () => {
    //             console.log('updated Pump')
    //         }
    //     )
    // }
    // }

    cancel() {
        this.plantConfigPumpsDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}