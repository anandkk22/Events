export class CncMachineModel {
  id?: number;
  machineName?: string;
  machineType?: string;
  serialNumber?: string;
  installationDate?: Date;
  manufacturingYear?: number;
  make?: string;
  model?: string;
}
