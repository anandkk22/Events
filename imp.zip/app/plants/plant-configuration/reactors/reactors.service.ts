import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ReactorModel } from './reactor.model';

@Injectable({ providedIn: 'root' })
export class ReactorsService {
    public listofReactors: string = environment.PROCESS_API_URL + 'api/reactor/plant';
    public getReactor: string = environment.PROCESS_API_URL + 'api/reactor';
    public addUpdateReactor: string = environment.PROCESS_API_URL + 'api/reactor';
    public deleteReactor: string = environment.PROCESS_API_URL + 'api/reactor';

    constructor(private _http: HttpClient) { }

    getlistofReactors(id: number): Observable<ReactorModel[]> {
        return this._http.get<ReactorModel[]>(`${this.listofReactors}/${id}`)
    }

    getReactorById(id: number): Observable<ReactorModel> {
        return this._http.get<ReactorModel>(`${this.getReactor}/${id}`)
    }

    createNewReactor(reactor: ReactorModel): Observable<ReactorModel> {
        return this._http.post<ReactorModel>(`${this.addUpdateReactor}`, reactor, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateReactor(reactor: ReactorModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateReactor}`, reactor, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteReactorById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.deleteReactor}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}