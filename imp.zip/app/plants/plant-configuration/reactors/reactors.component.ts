import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { ReactorsService } from './reactors.service';
import { ActivatedRoute } from '@angular/router';
import { ReactorModel } from './reactor.model';

@Component({
    selector: 'app-reactors',
    templateUrl: './reactors.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class ReactorComponent implements OnInit {
    plantConfigReactorDetails: ReactorModel[];
    reactor = null;
    plantConfigReactorDetail = null;
    mountTechnologies = [{ id: 1, name: 'Hybrid' }, { id: 2, name: 'Fixed Tilt' }, { id: 3, name: 'Seasonal Tilt' }, { id: 4, name: 'Single Axis Tracker' }, { id: 5, name: 'Dual Asix Tracker' }];
    plantTypes = [{ id: 1, name: 'Grounded Moulded Utility' }, { id: 2, name: 'Rooftop Distributed' }];
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;

    constructor(private _reactorsService: ReactorsService, public dialog: MatDialog,  private _route: ActivatedRoute) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigReactorDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';

        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');       
            this._reactorsService.getlistofReactors(this.getPlantId).subscribe(
                reactor => {                    
                    this.plantConfigReactorDetails = reactor
                }
            )
        })    
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigReactorDetails) {
            if (sortFilter === 'id') {
                this.plantConfigReactorDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigReactorDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }
       

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._reactorsService.deleteReactorById(id).subscribe(
                    () => console.log(`Reactor deleted with id =  ${id} deleted`)
                )
            }
        })
    }

    showRelationship(id): void {
        const dialogRef = this.dialog.open(RelationshipPlantComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigReactorDetails.forEach(reactor => {
            if (reactor.id === id) {
                this.plantConfigReactorDetail = reactor;
            }
        });
    }

    addnew() {
        this.plantConfigReactorDetail = new PidiliteUtilityPlant();        
    }

    isActiveClass(processCell) {
        this._reactorsService.isActiveClass(this.plantConfigReactorDetails, processCell)
    }

    save() {
        if (this.plantConfigReactorDetail.id !== undefined) {
            this._reactorsService.createNewReactor(this.reactor).subscribe(
                (data: ReactorModel) => {
                    console.log(data);
                }
            )
        }
        else {
            this._reactorsService.updateReactor(this.reactor).subscribe(
                () => {
                    console.log('updated Reactor')
                }
            )
        }
    }

    cancel() {
        this.plantConfigReactorDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}