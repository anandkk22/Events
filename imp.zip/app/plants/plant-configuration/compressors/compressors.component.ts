import { Component, OnInit } from '@angular/core';
import { CompressorsModel } from './compressors.model';
import { CompressorsService } from './compressors.service';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from '../../pidilite-utility-plant.model';

@Component({
  selector: 'app-compressors',
  templateUrl: './compressors.component.html',
  styleUrls: ['./compressors.component.scss']
})
export class CompressorsComponent implements OnInit {

  plantConfigCompressorsDetails: CompressorsModel[];
  compressor: CompressorsModel;
  plantConfigCompressorsDetail = null;
  maxDate: Date;
  orderbyKey: any;
  currentSearch: string;
  private _id: number;
  getPlantId: any;

  constructor(private compressorService: CompressorsService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {
      this.getPlantId = localStorage.getItem('plantId')
      this.plantConfigCompressorsDetail = null;
      this.maxDate = new Date();
      this.orderbyKey = 'id';

      this._route.paramMap.subscribe(params => {
          this._id = +params.get('id');
          this.compressorService.getListofCompressors(this.getPlantId).subscribe(
              agitator => {
                  this.plantConfigCompressorsDetails = agitator
              }
          )
      })
  }

  applySortFilter(sortFilter) {
      if (this.plantConfigCompressorsDetails) {
          if (sortFilter === 'id') {
              this.plantConfigCompressorsDetails.sort(function (a, b) {
                  if (a[sortFilter] && b[sortFilter]) {
                      const componentA = Number(a[sortFilter]);
                      const componentB = Number(b[sortFilter]);
                      return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                  }
              });
          } else {
              this.plantConfigCompressorsDetails.sort(function (a, b) {
                  if (a[sortFilter] && b[sortFilter]) {
                      const componentA = a[sortFilter].toUpperCase();
                      const componentB = b[sortFilter].toUpperCase();
                      return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                  }
              });
          }
      }
  }

  confirmDelete(id): void {
      const dialogRef = this.dialog.open(DeletePlant, {
          width: '250px'
      });
      dialogRef.afterClosed().subscribe(result => {
          if (result === 'delete') {
              this.compressorService.deleteCompressorById(id).subscribe(
                  () => console.log(`Pump deleted with id =  ${id} deleted`)
              )
          }
      })
  }

  showRelationship(id): void {
      const dialogRef = this.dialog.open(RelationshipPlantComponent, {
          width: '450px'
      });
  }

  details(id) {
      this.plantConfigCompressorsDetails.forEach(proessCell => {
          if (proessCell.id === id) {
              this.plantConfigCompressorsDetail = proessCell;
          }
      });
  }

  addnew() {
      this.plantConfigCompressorsDetail = new PidiliteUtilityPlant();
  }

  isActiveClass(processCell) {
      this.compressorService.isActiveClass(this.plantConfigCompressorsDetails, processCell)
  }

  save() {
    //   if (this.compressor.id !== undefined) {
          this.compressorService.createNewCompressor(this.plantConfigCompressorsDetail).subscribe(
              (data: CompressorsModel) => {
                  console.log(data);
              }
          )
    //   }
    //   else {
    //       this.compressorService.updateCompressor(this.compressor).subscribe(
    //           () => {
    //               console.log('updated Pump')
    //           }
    //       )
    //   }
  }

  cancel() {
      this.plantConfigCompressorsDetail = null;
      // this.getPlantConfigReactorDetails();
  }
}
