import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CompressorsModel } from './compressors.model';

@Injectable({ providedIn: 'root' })
export class CompressorsService {
    public listofCompressors: string = environment.PROCESS_API_URL + 'api/compressors/plant';
    public compressorApi: string = environment.PROCESS_API_URL + 'api/compressor';

    constructor(private _http: HttpClient) { }

    getListofCompressors(id: number): Observable<CompressorsModel[]> {
        return this._http.get<CompressorsModel[]>(`${this.listofCompressors}/${id}`)
    }

    getCompressorById(id: number): Observable<CompressorsModel> {
        return this._http.get<CompressorsModel>(`${this.compressorApi}/${id}`)
    }

    createNewCompressor(compressor: CompressorsModel): Observable<CompressorsModel> {
        return this._http.post<CompressorsModel>(`${this.compressorApi}`, compressor, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateCompressor(compressor: CompressorsModel): Observable<void> {
        return this._http.put<void>(`${this.compressorApi}`, compressor, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteCompressorById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.compressorApi}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}
