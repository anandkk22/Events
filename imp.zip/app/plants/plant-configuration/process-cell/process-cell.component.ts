import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { ProcesscellService } from './processCell.service';
import { ActivatedRoute } from '@angular/router';
import { ProcessCellModel } from './processCell.mode';


@Component({
    selector: 'process-cell',
    templateUrl: './process-cell.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class ProcessCellComponent implements OnInit {
    plantConfigProcessCellDetails: ProcessCellModel[];
    processCell: ProcessCellModel;
    plantConfigProcessCellDetail = null;
    mountTechnologies = [{ id: 1, name: 'Hybrid' }, { id: 2, name: 'Fixed Tilt' }, { id: 3, name: 'Seasonal Tilt' }, { id: 4, name: 'Single Axis Tracker' }, { id: 5, name: 'Dual Asix Tracker' }];
    plantTypes = [{ id: 1, name: 'Grounded Moulded Utility' }, { id: 2, name: 'Rooftop Distributed' }];
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    getPlantId: any;
    private _id: number;

    constructor(private _processcellService: ProcesscellService, public dialog: MatDialog, private _route: ActivatedRoute) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigProcessCellDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._processcellService.getListofProcessCell(this.getPlantId).subscribe(
                processCell => {
                    this.plantConfigProcessCellDetails = processCell
                }
            )
        })
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigProcessCellDetails) {
            if (sortFilter === 'id') {
                this.plantConfigProcessCellDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigProcessCellDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._processcellService.deleteProcessCellById(id).subscribe(
                    () => console.log(`Process cell deleted with id =  ${id} deleted`)
                )
            }
        })
    }

    showRelationship(id): void {
        const dialogRef = this.dialog.open(RelationshipPlantComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigProcessCellDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigProcessCellDetail = proessCell;
            }
        });
    }

    addnew() {
        this.plantConfigProcessCellDetail = new PidiliteUtilityPlant();
    }

    isActiveClass(processCell) {
        this._processcellService.isActiveClass(this.plantConfigProcessCellDetails, processCell)
    }

    cancel() {
        this.plantConfigProcessCellDetail = null;
        // this.getPlantConfigProcessCellDetails();
    }

    save() {
        if (this.plantConfigProcessCellDetail !== undefined) {
            this._processcellService.createNewProcessCell(this.processCell).subscribe(
                (data: ProcessCellModel) => {
                    console.log(data);
                }
            )
        }
        else {
            this._processcellService.updateProcessCell(this.processCell).subscribe(
                () => {
                    console.log('updated Procell Cell')
                }
            )
        }
    }
}