import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ProcessCellModel } from './processCell.mode';

@Injectable({ providedIn: 'root' })
export class ProcesscellService {
    public listofprocessCell: string = environment.PROCESS_API_URL + 'api/processcell/area'; 
    public getprocessCell: string = environment.PROCESS_API_URL + 'api/processcell'; 
    public addUpdateprocessCell: string = environment.PROCESS_API_URL + 'api/processcell'; 
    public deleteprocessCell: string = environment.PROCESS_API_URL + 'api/processcell'; 
    constructor(private _http: HttpClient) { }

    getListofProcessCell(id: number): Observable<ProcessCellModel[]> {
        return this._http.get<ProcessCellModel[]>(`${this.listofprocessCell}/${id}`)
    }

    getProcessCellById(id: number): Observable<ProcessCellModel> {
        return this._http.get<ProcessCellModel>(`${this.getprocessCell}/${id}`)
    }

    createNewProcessCell(processCell: ProcessCellModel): Observable<ProcessCellModel> {
        return this._http.post<ProcessCellModel>(`${this.addUpdateprocessCell}`, processCell, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateProcessCell(processCell: ProcessCellModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateprocessCell}`, processCell, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteProcessCellById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.deleteprocessCell}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}