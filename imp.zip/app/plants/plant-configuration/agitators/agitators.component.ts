import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { AgitatorService } from './agitators.service';
import { AgitatorsModel } from './agitators.model';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';

@Component({
    selector: 'app-agitators',
    templateUrl: './agitators.component.html',
    styleUrls: ['./agitators.component.scss']
})
export class AgitatorsComponent implements OnInit {

    plantConfigAgitatorsDetails: AgitatorsModel[];
    agitator: AgitatorsModel;
    plantConfigAgitatorsDetail:any;
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;

    constructor(private agitatorService: AgitatorService, public dialog: MatDialog, private _route: ActivatedRoute) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigAgitatorsDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';

        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this.agitatorService.getListofAgitators(this.getPlantId).subscribe(
                agitator => {
                    this.plantConfigAgitatorsDetails = agitator
                }
            )
        })
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigAgitatorsDetails) {
            if (sortFilter === 'id') {
                this.plantConfigAgitatorsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigAgitatorsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this.agitatorService.deleteAgitatorById(id).subscribe(
                    () => console.log(`Pump deleted with id =  ${id} deleted`)
                )
            }
        })
    }

    showRelationship(id): void {
        const dialogRef = this.dialog.open(RelationshipPlantComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigAgitatorsDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigAgitatorsDetail = proessCell;
            }
        });
    }

    addnew() {
        this.plantConfigAgitatorsDetail = new PidiliteUtilityPlant();
    }

    isActiveClass(processCell) {
        this.agitatorService.isActiveClass(this.plantConfigAgitatorsDetails, processCell)
    }

    save() {
       
            console.log("agitator", this.plantConfigAgitatorsDetail);
            this.agitatorService.createNewAgitator(this.plantConfigAgitatorsDetail).subscribe(
                (data: AgitatorsModel) => {
                    console.log(data);
                }
            )
        // }
        // else {
        //     this.agitatorService.updateAgitator(this.agitator).subscribe(
        //         () => {
        //             console.log('updated Pump')
        //         }
        //     )
        // }
    }

    cancel() {
        this.plantConfigAgitatorsDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}
