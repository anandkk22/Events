import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgitatorsComponent } from './agitators.component';

describe('AgitatorsComponent', () => {
  let component: AgitatorsComponent;
  let fixture: ComponentFixture<AgitatorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgitatorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgitatorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
