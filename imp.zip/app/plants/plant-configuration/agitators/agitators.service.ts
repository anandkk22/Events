import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AgitatorsModel } from './agitators.model';

@Injectable({ providedIn: 'root' })
export class AgitatorService {
    public listofAgitators: string = environment.PROCESS_API_URL + 'api/agitators/plant';
    public agitatorApi: string = environment.PROCESS_API_URL + 'api/agitator';

    constructor(private _http: HttpClient) { }

    getListofAgitators(id: number): Observable<AgitatorsModel[]> {
        return this._http.get<AgitatorsModel[]>(`${this.listofAgitators}/${id}`)
    }

    getAgitatorById(id: number): Observable<AgitatorsModel> {
        return this._http.get<AgitatorsModel>(`${this.agitatorApi}/${id}`)
    }

    createNewAgitator(agitator: AgitatorsModel): Observable<AgitatorsModel> {
        return this._http.post<AgitatorsModel>(`${this.agitatorApi}`, agitator, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateAgitator(agitator: AgitatorsModel): Observable<void> {
        return this._http.put<void>(`${this.agitatorApi}`, agitator, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteAgitatorById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.agitatorApi}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}
