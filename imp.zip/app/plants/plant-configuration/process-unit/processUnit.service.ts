import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ProcessUnitModel } from './processUnit.model';

@Injectable({ providedIn: 'root' })
export class ProcessUnitService {
    public listofProcessUnit: string = environment.PROCESS_API_URL + 'api/processunit/pc'; 
    public getprocessUnit: string = environment.PROCESS_API_URL + 'api/processunit';
    public addUpdateProcessUnit: string = environment.PROCESS_API_URL + 'api/processunit';
    public deleteProcessUnit: string = environment.PROCESS_API_URL + 'api/processunit';
   
    constructor(private _http: HttpClient) { }

    getListofProcessUnit(id: number): Observable<ProcessUnitModel[]> {
        return this._http.get<ProcessUnitModel[]>(`${this.listofProcessUnit}/${id}`)
    }

    getProcessUnitById(id: number): Observable<ProcessUnitModel> {
        return this._http.get<ProcessUnitModel>(`${this.getprocessUnit}/${id}`)
    }

    createNewProcessUnit(processUnit: ProcessUnitModel): Observable<ProcessUnitModel> {
        return this._http.post<ProcessUnitModel>(`${this.addUpdateProcessUnit}`, processUnit, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateProcessUnit(processUnit: ProcessUnitModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateProcessUnit}`, processUnit, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteProcessUnitById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.deleteProcessUnit}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}