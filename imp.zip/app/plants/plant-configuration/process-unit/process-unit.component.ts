import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { ProcessUnitService } from './processUnit.service';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { ActivatedRoute } from '@angular/router';
import { ProcessUnitModel } from './processUnit.model';

@Component({
    selector: 'process-unit',
    templateUrl: './process-unit.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class ProcessUnitComponent implements OnInit {
    plantConfigProcessUnitDetails: ProcessUnitModel[];
    processUnit: ProcessUnitModel;
    plantConfigProcessUnitDetail = null;
    mountTechnologies = [{ id: 1, name: 'Hybrid' }, { id: 2, name: 'Fixed Tilt' }, { id: 3, name: 'Seasonal Tilt' }, { id: 4, name: 'Single Axis Tracker' }, { id: 5, name: 'Dual Asix Tracker' }];
    plantTypes = [{ id: 1, name: 'Grounded Moulded Utility' }, { id: 2, name: 'Rooftop Distributed' }];
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;

    constructor(private _processUnitService: ProcessUnitService, public dialog: MatDialog, private _route: ActivatedRoute) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigProcessUnitDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';

        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');      
            this._processUnitService.getListofProcessUnit(this.getPlantId).subscribe(
                processUnit => {                    
                    this.plantConfigProcessUnitDetails = processUnit
                }
            )
        })     
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigProcessUnitDetails) {
            if (sortFilter === 'id') {
                this.plantConfigProcessUnitDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigProcessUnitDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }


    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._processUnitService.deleteProcessUnitById(id).subscribe(
                    () => console.log(`Process Unit deleted with id =  ${id} deleted`)
                )
            }
        })
    }

    showRelationship(id): void {
        const dialogRef = this.dialog.open(RelationshipPlantComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigProcessUnitDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigProcessUnitDetail = proessCell;
            }
        });
    }

    addnew() {
        this.plantConfigProcessUnitDetail = new PidiliteUtilityPlant();        
    }

    isActiveClass(processCell) {
        this._processUnitService.isActiveClass(this.plantConfigProcessUnitDetails, processCell)
    }

    save() {
        if (this.plantConfigProcessUnitDetail.id !== undefined) {
            this._processUnitService.createNewProcessUnit(this.processUnit).subscribe(
                (data: ProcessUnitModel) => {
                    console.log(data);
                }
            )
        }
        else {
            this._processUnitService.updateProcessUnit(this.processUnit).subscribe(
                () => {
                    console.log('updated area')
                }
            )
        }
    }

    cancel() {
        this.plantConfigProcessUnitDetail = null;
        // this.getPlantConfigProcessUnitDetails();
    }
}