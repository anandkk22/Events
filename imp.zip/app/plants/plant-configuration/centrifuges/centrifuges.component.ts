import { Component, OnInit } from '@angular/core';
import { CentrifugeService } from './centrifuges.service';
import { CentrifugesModel } from './centrifuges.model';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from '../../pidilite-utility-plant.model';

@Component({
  selector: 'app-centrifuges',
  templateUrl: './centrifuges.component.html',
  styleUrls: ['./centrifuges.component.scss']
})
export class CentrifugesComponent implements OnInit {

  plantConfigCentrifugesDetails: CentrifugesModel[];
  centrifuge: CentrifugesModel;
  plantConfigCentrifugesDetail = null;
  maxDate: Date;
  orderbyKey: any;
  currentSearch: string;
  private _id: number;
  getPlantId: any;

  constructor(private centrifugeService: CentrifugeService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {
      this.getPlantId = localStorage.getItem('plantId')
      this.plantConfigCentrifugesDetail = null;
      this.maxDate = new Date();
      this.orderbyKey = 'id';

      this._route.paramMap.subscribe(params => {
          this._id = +params.get('id');
          this.centrifugeService.getListofCentrifuges(this.getPlantId).subscribe(
              agitator => {
                  this.plantConfigCentrifugesDetails = agitator
              }
          )
      })
  }

  applySortFilter(sortFilter) {
      if (this.plantConfigCentrifugesDetails) {
          if (sortFilter === 'id') {
              this.plantConfigCentrifugesDetails.sort(function (a, b) {
                  if (a[sortFilter] && b[sortFilter]) {
                      const componentA = Number(a[sortFilter]);
                      const componentB = Number(b[sortFilter]);
                      return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                  }
              });
          } else {
              this.plantConfigCentrifugesDetails.sort(function (a, b) {
                  if (a[sortFilter] && b[sortFilter]) {
                      const componentA = a[sortFilter].toUpperCase();
                      const componentB = b[sortFilter].toUpperCase();
                      return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                  }
              });
          }
      }
  }

  confirmDelete(id): void {
      const dialogRef = this.dialog.open(DeletePlant, {
          width: '250px'
      });
      dialogRef.afterClosed().subscribe(result => {
          if (result === 'delete') {
              this.centrifugeService.deleteCentrifugeById(id).subscribe(
                  () => console.log(`Pump deleted with id =  ${id} deleted`)
              )
          }
      })
  }

  showRelationship(id): void {
      const dialogRef = this.dialog.open(RelationshipPlantComponent, {
          width: '450px'
      });
  }

  details(id) {
      this.plantConfigCentrifugesDetails.forEach(proessCell => {
          if (proessCell.id === id) {
              this.plantConfigCentrifugesDetail = proessCell;
          }
      });
  }

  addnew() {
      this.plantConfigCentrifugesDetail = new PidiliteUtilityPlant();
  }

  isActiveClass(processCell) {
      this.centrifugeService.isActiveClass(this.plantConfigCentrifugesDetails, processCell)
  }

  save() {
    //   if (this.centrifuge.id !== undefined) {
          this.centrifugeService.createNewCentrifuge(this.plantConfigCentrifugesDetail).subscribe(
              (data: CentrifugesModel) => {
                  console.log(data);
              }
          )
    //   }
    //   else {
    //       this.centrifugeService.updateCentrifuge(this.centrifuge).subscribe(
    //           () => {
    //               console.log('updated Pump')
    //           }
    //       )
    //   }
  }

  cancel() {
      this.plantConfigCentrifugesDetail = null;
      // this.getPlantConfigReactorDetails();
  }
}
