export class EquipmentDowntimeListModel {
    id?: number;
}
export class CentrifugesModel {
    id?: number;
    equipmentName?: string;
    equipmentMake?: string;
    equipmentModel?: any;
    equipmentType?: string;
    equipmentCapacity?: number;
    numberOfDowntimeReasons?: number;
    numberOfRejectionReasons?: number;
    standardRunningHoursForMaintenance?: string;
    unitCapacity?: number;
    equipmentDowntimeList?: EquipmentDowntimeListModel[];
    mfgconnectProductionUnitId?: number;
    mfgconnectProductionLineId?: number;
    mfgconnectWorkCellId?: number;
    mfgconnectProcessLineId?: number;
    mfgconnectProcessCellId?: number;
    productionUnitEquipmentId?: number;
    productionLineEquipmentId?: number;
    workcellEquipmentId?: number;
    shiftBreakEquipmentId?: number;
    outputEquipmentId?: number;
    measurementDataEquipmentId?: number;
    lastUpdated?: Date;
    isActive?: boolean;
    mfgconnectSiteId?: number;
}