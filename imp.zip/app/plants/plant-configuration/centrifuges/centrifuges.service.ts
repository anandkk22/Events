import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CentrifugesModel } from './centrifuges.model';

@Injectable({ providedIn: 'root' })
export class CentrifugeService {
    public listofCentrifuges: string = environment.PROCESS_API_URL + 'api/centrifuges/plant';
    public centrifugeApi: string = environment.PROCESS_API_URL + 'api/centrifuge';

    constructor(private _http: HttpClient) { }

    getListofCentrifuges(id: number): Observable<CentrifugesModel[]> {
        return this._http.get<CentrifugesModel[]>(`${this.listofCentrifuges}/${id}`)
    }

    getCentrifugeById(id: number): Observable<CentrifugesModel> {
        return this._http.get<CentrifugesModel>(`${this.centrifugeApi}/${id}`)
    }

    createNewCentrifuge(centrifuge: CentrifugesModel): Observable<CentrifugesModel> {
        return this._http.post<CentrifugesModel>(`${this.centrifugeApi}`, centrifuge, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateCentrifuge(centrifuge: CentrifugesModel): Observable<void> {
        return this._http.put<void>(`${this.centrifugeApi}`, centrifuge, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteCentrifugeById(id: number): Observable<void> {
        return this._http.delete<void>(`${this.centrifugeApi}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}
