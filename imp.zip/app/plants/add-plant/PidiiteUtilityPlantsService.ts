import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { PidiliteUtilityPlant } from '../pidilite-utility-plant.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
export type EntityResponseType = HttpResponse<PidiliteUtilityPlant>;

@Injectable({ providedIn: 'root' })
export class PidiliteUtilityPlantsService {
    constructor(private http: HttpClient) { }

    public url: string = "./assets/json/data.json";

    create(pidiliteUtilityPlant: PidiliteUtilityPlant): Observable<EntityResponseType> {
        return this.http
            .post<PidiliteUtilityPlant>(this.url, pidiliteUtilityPlant, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    update(apolloUtilityPlant: PidiliteUtilityPlant): Observable<EntityResponseType> {
        // const copy = this.convert(apolloUtilityPlant);
        return this.http
            .put<PidiliteUtilityPlant>(this.url, apolloUtilityPlant, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http
            .get<PidiliteUtilityPlant>(`${this.url}/${id}`, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertResponse(res)));
    }   


    private convertResponse(res: EntityResponseType): EntityResponseType {
        const body: PidiliteUtilityPlant = this.convertItemFromServer(res.body);
        return res.clone({ body });
    }

    private convertItemFromServer(apolloUtilityPlant: PidiliteUtilityPlant): PidiliteUtilityPlant {
        const copy: PidiliteUtilityPlant = Object.assign({}, apolloUtilityPlant);        
        return copy;
    }
}