import { Component, OnInit } from '@angular/core';
import { PidiliteUtilityPlant } from '../../models/Pidilite-Plant.model';
import { Router, ActivatedRoute } from '@angular/router';
import { RelatedOrganizationService } from './related-organizations/related-organization.service';
import { Organisations } from './related-organizations/organizations';
import { OrganisationIdandType } from './related-organizations/orgnisationIdandName';
import { PidilitePlantsService } from '../pidilite-plants.service';
import { PlantType } from 'src/app/models/plant-type.model';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';
import { AllCountriesService } from 'src/app/shared/allCountries.service';
import { AllTimezoneService } from 'src/app/shared/timezone.service';

@Component({
  selector: 'app-add-plant',
  templateUrl: './add-plant.component.html',
  styleUrls: ['./add-plant.component.scss']
})
export class AddPlantComponent implements OnInit {
  pidiliteUtilityPlant: PidiliteUtilityPlant;
  isSaving: boolean;
  pidiliteUtilityPlantOrgRel = [];
  plantPolicyList: any = [
    { id: 1, name: 'FDA' },
    { id: 2, name: 'DNCP' },
  ]
  segments: any;
  subSiteTypes: any;
  subsSegments: any;
  customerType: any;
  orgTypes: any;
  countries = [];
  states = [];
  timezones = [];
  currencies = [];
  org_type = '';
  org_id = '';
  orgList: any;
  maxDate: Date;
  isDevOrg: boolean;
  orgErr = '';
  saveSuccess = false;
  saveError = false;
  responseStatus: { error: boolean; message: any };
  title: String;
  selectedSegment: number;
  allCountries: any;
  allTimezone: any;
  allCurrency: any;
  plant: pidiliteMainModel;

  constructor(
    private _router: Router,
    private _relOrgServide: RelatedOrganizationService,
    private _route: ActivatedRoute,
    private _plantService: PidilitePlantsService,
    private _allCountries: AllCountriesService,
    private _allTimzone: AllTimezoneService) { }

  selectedorganizations: Organisations = new Organisations(null, '');
  organizations: Organisations[];
  organizationIdandName: OrganisationIdandType[];

  ngOnInit() {
    this.plant = new pidiliteMainModel;
    this.allCurrency = [{id: 1, currency:'INR'}, {id: 2, currency:'USD'}]
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
      this.getPlant(id);
    })
    this.maxDate = new Date();
    this.currencies = [
      { code: 'INR', icon: 'fa fa-rupee-sign', unicode: String.fromCharCode(0xf156) },
      { code: 'USD', icon: 'fa fa-dollar-sign', unicode: String.fromCharCode(0xf155) }
    ];
    this.organizations = this._relOrgServide.getOrganizations();
    this.getSegments();
    this.getSubSiteType();
    this.getSubSegments();
    this.getCustomerType();
    this.getOrgType();
    this.getAllCountries();
    this.getTimezoneCountries()
  }

  getAllCountries(){
    this._allCountries.getAllCountries().subscribe(
      country => this.allCountries = country
    )
  }

  getTimezoneCountries(){
    this._allTimzone.getTimezoneCountries().subscribe(
      tiemzone => this.allTimezone = tiemzone
    );
  }

  getSegments() {
    this._plantService.getSegments().subscribe(
      data => {       
        this.segments = data
      }
    )
  }

  getSubSegments() {
    this._plantService.getSubSegments().subscribe(
      data => this.subsSegments = data
    )
  }

  getSubSiteType() {
    this._plantService.getSubSiteType().subscribe(
      data => this.subSiteTypes = data
    )
  }

  getCustomerType() {
    this._plantService.getCustomerType().subscribe(
      data => this.customerType = data
    )
  }

  getOrgType() {
    this._plantService.getOrgType(this.plant.customer_site_type).subscribe(
      data => this.orgTypes = data
    )
  }

  saveRelArr() {
    const relOrgType = this.org_type;
    const relOrgId = this.org_id;
    let relOrgName = '';
    let relOrganizationType = '';
    this.orgErr = '';
    this.org_id = '';
    this.org_type = '';

    relOrgName = this.getOrgNameById(Number(relOrgId));
    relOrganizationType = this.getOrgTypeById(Number(relOrgType));

    if (relOrgId === '' || relOrgId === '0') {
      this.orgErr = 'Please Select Organization';
    } else if (relOrgType === '') {
      this.orgErr = 'Please Select Organization Type';
    } else {
      if (this.pidiliteUtilityPlantOrgRel.length > 0) {
        this.pidiliteUtilityPlantOrgRel.forEach(element => {
          if (element.orgTypeName === relOrganizationType) {
            if (element.orgName === relOrgName) {
              this.orgErr = 'Organization already added.';
              }
          }
        });
      }
    }
    if(this.orgErr === ''){
      this.pidiliteUtilityPlantOrgRel.push({ orgTypeId: relOrgType, orgTypeName: relOrganizationType, orgId: relOrgId, orgName: relOrgName })
    } else {
      // console.log('****')
    }
    console.log(this.pidiliteUtilityPlantOrgRel);
  }

  removeRelArr(index) {
    this.pidiliteUtilityPlantOrgRel.splice(index, 1);
  }

  getOrgNameById(org_id): string {
    let orgName = '';
    this.orgTypes.forEach(org => {
      if (org.id === org_id) {
        orgName = org.name;
      }
    });
    return orgName;
  }

  getOrgTypeById(orgCode): string {
    let orgType = '';
    this.customerType.forEach(org => {
      if (org.code === orgCode) {
        orgType = org.name;
      }
    });
    return orgType;
  }


  save() {
    this._router.navigate(['/plants']);
  }

  cancel() {
    this._router.navigate(['/plants'])
  }

  private getPlant(id: number) {
    if (id === 0) {
      this.plant = {
        responseMessage: null,
        orgId: 3,
      };
      this.title = "Add new";
    } else {
      this.title = "Edit";
      this._plantService.getPlantById(id).subscribe(
        (plant) => {
          this.plant = plant;
          this.plant.orgTypes.forEach(o => {
            this.pidiliteUtilityPlantOrgRel.push({ orgTypeId: o.orgTypeId, orgTypeName: o.orgTypeName, orgId: o.orgId, orgName: o.orgName })
          });
        },
        (err: any) => console.log(err)
      )
    }
  }
  public savePlant(): void {
    this.plant.orgTypes = this.pidiliteUtilityPlantOrgRel;
    console.log(this.plant);
    if (this.plant.id == null) {
      this.plant.orgId = 3;
      this._plantService.addPlant(this.plant).subscribe(
        (data: any) => {
          console.log(data);
          this._router.navigate(['/plants'])
        },
      )
    } else {
      console.log("plantid", this.plant.id)
      this._plantService.updatePlant(this.plant).subscribe(
        () => {
          this._router.navigate(['/plants'])
        }
      )
    }
  }

  onSegmentSelect(code: number) {
    this._plantService.getSubSegments().subscribe(data => {
      this.subsSegments = data.filter(subSegment => subSegment.code == code)
    })
  }


  onOrgTypeSelect(code: number) {
    this._plantService.getOrgType(code).subscribe(data => {
      this.orgTypes = data;
    })
  }

}

