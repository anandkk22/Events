export class Organisations {
    constructor(public org_id: number, public name: string) { }
}