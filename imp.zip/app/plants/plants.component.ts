import { Component, OnInit, OnDestroy } from '@angular/core';

import { PidilitePlantsService } from './pidilite-plants.service';
import { Router } from '@angular/router';
import { searchByPlantName } from './searchandFilter.pipe';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from './delete-plant/delete-plant';
import { pidiliteMainModel } from '../models/pidilite-model';

@Component({
  selector: 'app-plants',
  templateUrl: './plants.component.html',
  styleUrls: ['./plants.component.scss']
})
export class PlantsComponent implements OnInit, OnDestroy {
  searchText: string = null;
  listofAllPlants: pidiliteMainModel[];
  plant: pidiliteMainModel;
  matDialogRef: MatDialogRef<DeletePlant>;
  $localPlantId: any;
  

  constructor(private _plantService: PidilitePlantsService,
    private _router: Router,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.getListofPlant();    
  }

  getPlantDetails(plantId: number) {
    this.$localPlantId = localStorage.setItem('plantId',JSON.stringify(plantId));
    this._router.navigate(['/plant-details', plantId]);    
  }

  getListofPlant() {
    return this._plantService.getListofPlant().subscribe(
      res => this.listofAllPlants = res
    )
  }

  addNewPlant() {
    this._router.navigate(['/add-plant'])
  }

  confirmDelete(id) {
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._plantService.deletePlant(id).subscribe(      
          () => console.log(`Plant deleted with id =  ${id} deleted`)
        )
      }
    })    
  }

  ngOnDestroy(){
    this.$localPlantId = null;  
  }

}