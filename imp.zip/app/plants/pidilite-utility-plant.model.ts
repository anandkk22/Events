export class PidiliteUtilityPlant {
        plantId: number;
        plantName: string;
        plantType: string;
        ownerName: string;
        capacity: number;
        lastUpdated: string;
}