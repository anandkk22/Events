import { BrowserModule } from "@angular/platform-browser";
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { RemoteMonitoringDashboardComponent } from "./remote-monitoring-dashboard/remote-monitoring-dashboard.component";
import { ApollowebHomeModule } from "./home/home.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MaterialModule } from "./material.module";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { HeaderComponent } from "./header/header.component";
import { PlantsComponent } from "./plants/plants.component";
import { MatTooltipModule } from "@angular/material/tooltip";
import { CategoriesComponent } from "./categories/categories.component";
import { NgCircleProgressModule } from "ng-circle-progress";
import { UserProfile } from "./header/user-profile/user-profile";
import { PlantDetailsComponent } from "./plants/plant-details/plant-details.component";
import { AngularFontAwesomeModule } from "angular-font-awesome";
import { AgmCoreModule } from "@agm/core";
import { searchByPlantName, OrderByPipe } from "./plants/searchandFilter.pipe";
import { EquipmentComponent } from "./equipment/equipment.component";
import { IdeComponent } from "./equipment/ide/ide.component";
import { searchCatetories } from "./categories/searchbyCategories.pipe";
import { PlantConfigurationComponent } from "./plants/plant-configuration/plant-configuration.component";
import { UserPreferenceSetting } from "./header/user-preference-setting/user-preference-setting";
import { AddPlantComponent } from "./plants/add-plant/add-plant.component";
import { DeletePlant } from "./plants/delete-plant/delete-plant";
import { Select2Module } from "ng2-select2";
import { AreaComponent } from "./plants/plant-configuration/area/area.component";
import { ProcessCellComponent } from "./plants/plant-configuration/process-cell/process-cell.component";
import { RelationshipPlantComponent } from "./plants/relationship-plant/relationship-plant";
import { BatchAnalysisDashboardComponent } from './batch-analysis-dashboard/batch-analysis-dashboard.component';
import { SidenavComponent } from './shared/sidenav/sidenav.component';
import { ProcessUnitComponent } from './plants/plant-configuration/process-unit/process-unit.component';
import { ReactorComponent } from './plants/plant-configuration/reactors/reactors.component';
import { PumpsComponent } from './plants/plant-configuration/pumps/pumps.component';
import { LibraryComponent } from './library/library.component';
import { searchPlantConfigName, OrderByPlantConfigPipe } from './plants/plant-configuration/searchandFilter.pipe';
import { EquipmentMeasurementDataComponent } from './library/parameter-tags/equipment-measurement-data/equipment-measurement-data';
import { EquipmentModule } from './library/equipment-module';
import { AuthInterceptor } from 'src/app/blocks/interceptor/auth.interceptor';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
import { CoreModule } from './core';
import { TranslateModule } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { ServiceWorkerModule } from '@angular/service-worker';
import { CookieService } from 'ngx-cookie-service';
import { FooterComponent } from './footer/footer.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AmChartsModule } from "@amcharts/amcharts3-angular";
import { ProductionLiveDashboardComponent } from './production-live-dashboard/production-live-dashboard.component';
import { PlanningDashboardComponent } from './planning-dashboard/planning-dashboard.component';
import { CncMachineComponent } from './plants/plant-configuration/cnc-machine/cnc-machine.component';
import { OperatorDashboardComponent } from './operator-dashboard/operator-dashboard.component';
import { MatInputModule } from '@angular/material';
import { CentrifugesComponent } from './plants/plant-configuration/centrifuges/centrifuges.component';
import { CompressorsComponent } from './plants/plant-configuration/compressors/compressors.component';
import { AgitatorsComponent } from './plants/plant-configuration/agitators/agitators.component';
import { searchByEquipmentMeasure, OrderEquipmentMeasure } from './library/parameter-tags/equipment-measurement-data/searchEquipment.pipe';
import { ReferenceKPIComponent } from './library/parameter-tags/reference_KPI_family/reference-kpi-family';

@NgModule({
  declarations: [
    AppComponent,
    RemoteMonitoringDashboardComponent,
    HeaderComponent,
    PlantsComponent,
    CategoriesComponent,
    UserProfile,
    PlantDetailsComponent,
    searchByPlantName,
    OrderByPipe,
    EquipmentComponent,
    IdeComponent,
    searchCatetories,
    PlantConfigurationComponent,
    UserPreferenceSetting,
    AddPlantComponent,
    DeletePlant,
    AreaComponent,
    ProcessCellComponent,
    RelationshipPlantComponent,
    BatchAnalysisDashboardComponent,
    SidenavComponent,
    ProcessUnitComponent,
    ReactorComponent,
    PumpsComponent,
    LibraryComponent,
    EquipmentMeasurementDataComponent,
    searchPlantConfigName,
    OrderByPlantConfigPipe,
    FooterComponent,
    ProductionLiveDashboardComponent,
    PlanningDashboardComponent,
    CncMachineComponent,
    OperatorDashboardComponent,
    AgitatorsComponent,
    CompressorsComponent,
    CentrifugesComponent,
    searchByEquipmentMeasure,
    OrderEquipmentMeasure,
    ReferenceKPIComponent
  ],
  imports: [
    BrowserModule,
    ServiceWorkerModule.register('./ngsw-worker.js', { enabled: environment.production }),
    AppRoutingModule,
    ApollowebHomeModule,
    EquipmentModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    MatTooltipModule,
    FormsModule,
    MatInputModule,
    NgCircleProgressModule.forRoot({
      backgroundOpacity: 0,
      maxPercent: 100,
      outerStrokeWidth: 12,
      innerStrokeWidth: 6,
    }),
    AngularFontAwesomeModule,
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyCaCJe8c2rXffW1eGkts1xyvmSYa7lp3c4",
    }),
    Select2Module,
    CoreModule,
    TranslateModule.forRoot(),
    NgxSpinnerModule,
    AmChartsModule
  ],
  providers: [CookieService, {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true,
    deps: [LocalStorageService, SessionStorageService]
  }],

  bootstrap: [AppComponent],
  entryComponents: [
    UserProfile,
    UserPreferenceSetting,
    DeletePlant,
    RelationshipPlantComponent,
    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
