import { NbLayoutModule, NbCardModule } from '@nebular/theme';

import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmChartsModule } from "@amcharts/amcharts3-angular";


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PlanningDashboardComponent } from './planning-dashboard.component';
import { EditPlanComponent } from './edit-plan/edit-plan.component';
import { PlanningDashboardRoutingModule } from './planning-dashboard-routing.module';


@NgModule({
  declarations: [
    PlanningDashboardComponent,
    EditPlanComponent
  ],
  imports: [
    CommonModule,
    NbLayoutModule,
    NbCardModule,
    PlanningDashboardRoutingModule,
    AmChartsModule,
    FormsModule,
    ReactiveFormsModule

  ],
  schemas: [NO_ERRORS_SCHEMA],
  entryComponents: [EditPlanComponent],
  exports: [PlanningDashboardComponent,
    EditPlanComponent]
})
export class MachineviewModule { }
