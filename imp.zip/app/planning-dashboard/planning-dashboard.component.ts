//import { Color } from 'ng2-charts';
import { element } from 'protractor';
//import { MachineService } from './../machine/machine.service';
//import { MachineviewService } from './machineview.service';
// import { EditplanComponent } from './editplan/editplan.component';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatTable, MatDialogConfig, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { AmChartsService, AmChart } from "@amcharts/amcharts3-angular";
import * as moment from 'moment';
//import { EditplanComponent } from './editplan/editplan.component';
import * as _ from 'lodash';
import { MissingTranslationHandler } from '@ngx-translate/core';
import { sampleSize } from 'lodash';
import { getNextUnit } from '@amcharts/amcharts4/.internal/core/utils/Time';
import { length } from '@amcharts/amcharts4/.internal/core/utils/Iterator';
import { toInteger } from '@ng-bootstrap/ng-bootstrap/util/util';
import { EditPlanComponent } from './edit-plan/edit-plan.component';
import { PlanningDashboardService } from './planning-dashboard.service';
import { ProductionLiveService } from '../production-live-dashboard/production-live-dashboard-service.service';

@Component({
  selector: 'app-planning-dashboard',
  templateUrl: './planning-dashboard.component.html',
  styleUrls: ['./planning-dashboard.component.scss']
})
export class PlanningDashboardComponent implements OnInit {

  isScheduleActual: boolean = false;
  isPlan: boolean = false;
  isToolChange: boolean = false;
  isPlansAborted: boolean = false;
  isPlansEdited: boolean = false;
  endTimeStamp;
  startTimeStamp;
  summaryData: any = []
  axisRange: any = {}
  globalDataClick: any = {}
  deviceId: any = [];
  rawData: any = {};
  rawDataInfo: any = [];
  dataProvider: any = []
  private chart: AmChart;
  data: any = [];
  machineStatus = [
    {
      status: "Running",
      count: 0,
      Display: "Running"
    },
    {
      status: "Down",
      count: 0,
      Display: "M/c Down"
    },
    {
      status: "Tool_Change",
      count: 0,
      Display: "Tool Change"
    },
    {
      status: "No_plan",
      count: 0,
      Display: "No Plan"
    },
    {
      status: "Trial",
      count: 0,
      Display: "Trial"
    },
    {
      status: "Preventive",
      count: 0,
      Display: "Preventive Maintenance"
    },
    {
      status: "Planned",
      count: 0,
      Display: "Planned"
    },
    {
      status: "Completed",
      count: 0,
      Display: "Completed"
    }
  ]
  temp = new Map();
  runningCount = 0;
  planData: any = [];
  planMachineName: string[] = [];
  newPlanMachineName: any = [];
  newPlanMachineGuide: any = [];
  timeValue: any = [];
  masterPlan = {};
  masterActual = {};
  categoryGuide = {};
  machineDetails = new Map();
  segments = {};
  segments_maintainance = {};
  segments_tool = {};
  machine_id_to_names = {};
  final_prodPlan: any = {};
  final_actualPlan: any = {};
  final_maintainacePlan: any = {};
  final_toolPlan: any = {};
  final_maintainaceActual: any = {}
  final_toolActual: any = {}
  final_equipmentDowntime: any = {}
  minDate;
  maxDate;
  cncMachineList: any = [];
  category: any = [];
  dateAllMin: any = [];
  dateAllMAx: any = [];
  list1: any = []
  maxDateDuration;
  constructor(private route: Router,
    private AmCharts: AmChartsService,
    private machineViewService: PlanningDashboardService,
    private machineService: ProductionLiveService,
    private dialog: MatDialog) { }

  ngOnInit() {

    // this.machineService.getDeviceIdList().subscribe(resp => {
    //   this.deviceId = resp;
    //   console.log("aaa", this.deviceId)
    //   this.deviceId.forEach(element => {
    //     this.rawData = {
    //       deviceId: element,
    //       startTimestamp: this.startTimeStamp,
    //       endTimestamp: this.endTimeStamp,
    //       parameter: "MACHINE_STATUS",
    //       resolution: "1"
    //     }
    //     this.rawDataInfo.push(this.rawData)
    //   });
    //   this.machineService.getMachineData(this.rawDataInfo).subscribe(resp => {
    //     console.log("machine json data", resp);
    //     this.data = resp;
    //     this.calculateSummary();
    //   });
    // });


    this.machineViewService.getCNCMachines().subscribe(resp => {
      this.cncMachineList = resp;
      console.log("CNC Machines Names display", this.cncMachineList);


      this.cncMachineList.map(item => {
        // this.segments[item.id] = []
        this.final_maintainacePlan[item.machineName] = []
        this.final_toolPlan[item.machineName] = []
        this.final_prodPlan[item.machineName] = []
        this.final_actualPlan[item.machineName] = []
        this.final_maintainaceActual[item.machineName] = []
        this.final_toolActual[item.machineName] = []
        this.final_equipmentDowntime[item.machineName] = []
        this.machineDetails[item.id] = item.machineName;
      });



      //this.machineViewService.getProdutionSchedulesPlan().subscribe(prodPlan => {
      this.machineViewService.getAllProductionSchedules().subscribe(prodPlan => {

        this.machineViewService.getAllMaintenanceSchedules().subscribe(maintainenceSchedule => {
          console.log("disp maintenance schedule pan data", maintainenceSchedule);



          this.machineViewService.getAllToolSchedules().subscribe(toolSchedule => {
            ///

            //api to get production schedule data with status running:
            this.machineViewService.getProdutionSchedules().subscribe(actualProductionSchedule => {
              // console.log("!!!????@@@",actualProductionSchedule);
              //if (actualProductionSchedule instanceof Array) {
              //this.calculateSummary(actualProductionSchedule);
              // actualProductionSchedule.map(ele => {
              //   if(ele.status == "RUNNING"){
              //     let startDatePlan = moment(ele['startTime']).utc();
              //     let startHourPlan = startDatePlan.utc().hours();
              //     let endDatePlan = moment().utc();                              // check logic for get current date and time
              //     let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));
              //     let planHours = planDuration1.asHours();
              //     // let planColor;
              //     // let planTask;
              //     // ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
              //     // ele['isTrial'] ? planTask = "RUNNING " : planTask = "PLANNED";
              //     let actualProdutionData = {
              //       "id": ele.mfgconnectEquipmentId,
              //       "priority": ele['priority'],
              //       "start": startDatePlan,
              //       "duration": planHours,
              //       "color": "#63982D",
              //       "task": "RUNNING" ,
              //       // "partName": ele['partName'],
              //       // "Quantity": ele['quantity']
              //     }
              //   }
              //   //2020-06-14T06:37:26Z
              //   // console.log("!!!!!!!!!!!", planHours);
              //   // this.segments[ele.mfgconnectEquipmentId].push(planData);
              //   let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
              //   this.final_prodPlan[temp_machineName].push(planData)
              //   let categoryData = {
              //     //replace category value by machine name which is id now
              //     "category": temp_machineName + " Plannnn",
              //     "LineAlpha": 0.7,
              //     "expand": true,
              //     "position": "left",
              //     "tickLength": 125,

              //   };

              //   this.categoryGuide[temp_machineName] = categoryData;
              // }); // end of inner loop prodPlan
              //}
              //Apply else if condition to call if first service fails
              this.machineViewService.getMaintenanceSchedule().subscribe(actualMaintenanceSchedule => {

                //console.log("!!!????@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@}}}}}}}}}}}}}}}}}}}}}}", actualMaintenanceSchedule);
                //if (actualMaintenanceSchedule instanceof Array) {
                // this.calculateSummary(actualMaintenanceSchedule);
                //   actualMaintenanceSchedule.map(ele => {
                //     if(ele.status == "RUNNING"){
                //       let startDatePlan = moment(ele['startTime']).utc();
                //       let startHourPlan = startDatePlan.utc().hours();
                //       let endDatePlan = moment().utc();                              // check logic for get current date and time
                //       let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));
                //       let planHours = planDuration1.asHours();
                //       // let planColor;
                //       // let planTask;
                //       // ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
                //       // ele['isTrial'] ? planTask = "RUNNING " : planTask = "PLANNED";
                //       let actualProdutionData = {
                //         "id": ele.mfgconnectEquipmentId,
                //         "priority": ele['priority'],
                //         "start": startDatePlan,
                //         "duration": planHours,
                //         "color": "#987438",
                //         "task": "RUNNING" ,
                //         // "partName": ele['partName'],
                //         // "Quantity": ele['quantity']
                //       }
                //     }
                //     //2020-06-14T06:37:26Z
                //     // console.log("!!!!!!!!!!!", planHours);
                //     // this.segments[ele.mfgconnectEquipmentId].push(planData);
                //     let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                //     this.final_prodPlan[temp_machineName].push(planData)
                //     let categoryData = {
                //       //replace category value by machine name which is id now
                //       "category": temp_machineName + " Plannnn",
                //       "LineAlpha": 0.7,
                //       "expand": true,
                //       "position": "left",
                //       "tickLength": 125,

                //     };

                //     this.categoryGuide[temp_machineName] = categoryData;
                //   }); // end of inner loop prodPlan
                // }

                this.machineViewService.getToolSchedule().subscribe(actualToolSchedule => {
                  // console.log("!!!????@@@",actualToolSchedule);
                  // if (actualToolSchedule instanceof Array) {
                  // this.calculateSummary(actualToolSchedule);
                  //   actualToolSchedule.map(ele => {
                  //     if(ele.status == "RUNNING"){
                  //       let startDatePlan = moment(ele['startTime']).utc();
                  //       let startHourPlan = startDatePlan.utc().hours();
                  //       let endDatePlan = moment().utc();                              // check logic for get current date and time
                  //       let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));
                  //       let planHours = planDuration1.asHours();
                  //       // let planColor;
                  //       // let planTask;
                  //       // ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
                  //       // ele['isTrial'] ? planTask = "RUNNING " : planTask = "PLANNED";
                  //       let actualProdutionData = {
                  //         "id": ele.mfgconnectEquipmentId,
                  //         "priority": ele['priority'],
                  //         "start": startDatePlan,
                  //         "duration": planHours,
                  //         "color": "#E67118",
                  //         "task": "RUNNING" ,
                  //         // "partName": ele['partName'],
                  //         // "Quantity": ele['quantity']
                  //       }
                  //     }
                  //     //2020-06-14T06:37:26Z
                  //     // console.log("!!!!!!!!!!!", planHours);
                  //     // this.segments[ele.mfgconnectEquipmentId].push(planData);
                  //     let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                  //     this.final_prodPlan[temp_machineName].push(planData)
                  //     let categoryData = {
                  //       //replace category value by machine name which is id now
                  //       "category": temp_machineName + " Plannnn",
                  //       "LineAlpha": 0.7,
                  //       "expand": true,
                  //       "position": "left",
                  //       "tickLength": 125,

                  //     };

                  //     this.categoryGuide[temp_machineName] = categoryData;
                  //   }); // end of inner loop prodPlan
                  // }

                  this.machineViewService.getAllEquipmentDowntime().subscribe(actualEquipmentDowntimeOver => {
                    console.log("!!!????@@@!!!!!!!!!!!????????????@@@@@@@@@@@@@@@@@@@@@@@@", actualEquipmentDowntimeOver);
                    //this.calculateSummary(actualEquipmentDowntimeOver);
                    //   actualEquipmentDowntimeOver.map(ele => {
                    //     if(ele.status == "OVER"){
                    //       let startDatePlan = moment(ele['startTime']).utc();
                    //       let startHourPlan = startDatePlan.utc().hours();
                    //       let endDatePlan = moment().utc();                              // check logic for get current date and time
                    //       let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));
                    //       let planHours = planDuration1.asHours();
                    //       // let planColor;
                    //       // let planTask;
                    //       // ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
                    //       // ele['isTrial'] ? planTask = "RUNNING " : planTask = "PLANNED";
                    //       let actualProdutionData = {
                    //         "id": ele.mfgconnectEquipmentId,
                    //         // "priority": ele['priority'],
                    //         "start": startDatePlan,
                    //         "duration": planHours,
                    //         "color": "#54A746",
                    //         "task": "COMPLETED" ,
                    //         "partName": ele['partName'],
                    //         "Quantity": ele['quantity']
                    //       }
                    //     }
                    //     //2020-06-14T06:37:26Z
                    //     // console.log("!!!!!!!!!!!", planHours);
                    //     // this.segments[ele.mfgconnectEquipmentId].push(planData);
                    //     let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                    //     this.final_prodPlan[temp_machineName].push(planData)
                    //     let categoryData = {
                    //       //replace category value by machine name which is id now
                    //       "category": temp_machineName + " Plannnn",
                    //       "LineAlpha": 0.7,
                    //       "expand": true,
                    //       "position": "left",
                    //       "tickLength": 125,

                    //     };

                    //     this.categoryGuide[temp_machineName] = categoryData;
                    //   }); // end of inner loop prodPlan



                    if (prodPlan instanceof Array) {
                      prodPlan.map(element => {
                        this.dateAllMin.push(moment(element['startTime']).utc());
                        this.dateAllMin.push(moment(element['actualStartTime']).utc());
                        this.dateAllMAx.push(element['endTime']);
                        this.dateAllMAx.push(element['actualEndTime']);

                      });
                      this.calculateSummary(prodPlan)
                    }



                    if (maintainenceSchedule instanceof Array) {
                      maintainenceSchedule.map(element => {
                        this.dateAllMin.push(moment(element['startTime']).utc());
                        this.dateAllMAx.push(element['endTime']);
                      });
                    }

                    if (toolSchedule instanceof Array) {
                      toolSchedule.map(element => {
                        this.dateAllMin.push(moment(element['toolChangeStartTime']).utc());
                        this.dateAllMAx.push(element['toolChangeEndTime']);
                      });
                    }



                    console.log("disp production schedule pan data", prodPlan);
                    console.log("disp maintainence schedule pan data", maintainenceSchedule);
                    console.log("disp tool schedule pan data", toolSchedule);



                    ///// all inside
                    console.log("disp maintenance schedule pan data", prodPlan);
                    //prodPlan array start loop
                    if (prodPlan instanceof Array) {

                      prodPlan.map(ele => {
                        //if prod schedule is planned(will contain future plans)
                        if (ele['status'] == "PLANNED") {
                          let startDatePlan = moment(ele['startTime']).utc();
                          //console.log("start date plan :", startDatePlan)
                          //2020-06-14T06:37:26Z
                          let startHourPlan = startDatePlan.utc().hours();
                          let endDatePlan = moment(ele['endTime']).utc();
                          let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));

                          let planHours = planDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let planColor;
                          let planTask;
                          let partName;
                          let originalQuantity;
                          ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
                          ele['isTrial'] ? planTask = "TRIAL" : planTask = "PLANNED";
                          ele['isTrial'] ? partName = "" : partName = ele['partName'];
                          ele['isTrial'] ? originalQuantity = "" : originalQuantity = ele['originalQuantity'];

                          let planData = {
                            "planId": ele.id,
                            "id": ele.mfgconnectEquipmentId,
                            // "priority": ele['priority'],
                            "start": startDatePlan,
                            "duration": planHours,
                            "color": planColor,
                            "task": planTask,
                            "partName": partName,
                            "Quantity": originalQuantity,
                            // "time": planMin
                          }

                          let planMin = planDuration1.asMinutes().toFixed(0) + " min " + planDuration1.seconds().toFixed(0).toString() + " sec";
                          if (ele['isTrial'])
                            planData["time"] = planMin

                          // this.segments[ele.mfgconnectEquipmentId].push(planData);
                          let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_prodPlan[temp_machineName].push(planData)

                          let categoryData = {
                            //replace category value by machine name which is id now
                            "category": temp_machineName + " Plannnn",
                            "LineAlpha": 0.7,
                            "expand": true,
                            "position": "left",
                            "tickLength": 125,

                          };

                          this.categoryGuide[temp_machineName] = categoryData;
                        }
                        //if prod schedule is running (will contain currently running schedules)
                        if (ele['status'] == "RUNNING") {
                          //for corresponding running schedule display a plan
                          let startDatePlan = moment(ele['startTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourPlan = startDatePlan.utc().hours();
                          let endDatePlan = moment(ele['endTime']).utc();
                          let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));

                          let planHours = planDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let planColor;
                          let planTask;
                          let partName;
                          let originalQuantity;
                          ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
                          ele['isTrial'] ? planTask = "TRIAL" : planTask = "PLANNED";
                          ele['isTrial'] ? partName = "" : partName = ele['partName'];
                          ele['isTrial'] ? originalQuantity = "" : originalQuantity = ele['originalQuantity'];

                          let planData = {
                            "planId": ele.id,
                            "id": ele.mfgconnectEquipmentId,
                            // "priority": ele['priority'],
                            "start": startDatePlan,
                            "duration": planHours,
                            "color": planColor,
                            "task": planTask,
                            "partName": partName,
                            "Quantity": originalQuantity,
                            // "time": planMin
                          }

                          let planMin = planDuration1.asMinutes().toFixed(0) + " min " + planDuration1.seconds().toFixed(0).toString() + " sec";
                          if (ele['isTrial'])
                            planData["time"] = planMin

                          // this.segments[ele.mfgconnectEquipmentId].push(planData);
                          let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_prodPlan[temp_machineName].push(planData)

                          let categoryData = {
                            //replace category value by machine name which is id now
                            "category": temp_machineName + " Plannnn",
                            "LineAlpha": 0.7,
                            "expand": true,
                            "position": "left",
                            "tickLength": 125,

                          };

                          this.categoryGuide[temp_machineName] = categoryData;

                          let actualDatePlan = moment(ele['actualStartTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourActual = actualDatePlan.utc().hours();
                          let endDateActual = moment.utc();
                          let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

                          let actualHours = actualDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let actualColor = "#63982d";
                          let actualTask = "RUNNING";
                          let actualName = ele['partName'];
                          let actualQuantity = ele['quantity'];
                          if (actualQuantity != null) {
                            let actualData = {
                              "id": ele.mfgconnectEquipmentId,
                              // "priority": ele['priority'],
                              "start": actualDatePlan,
                              "duration": actualHours,
                              "color": actualColor,
                              "task": actualTask,
                              "partName": actualName,
                              "Quantity": actualQuantity,
                              // "time": planMin
                            }
                            let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                            if (ele['isTrial'])
                              actualData["time"] = actualMin
                            this.final_actualPlan[temp_machineName].push(actualData)
                          }
                          if (actualQuantity != null) {
                            ele['actualStatus'] = "Running"
                          }
                          this.summaryData.push(ele)
                          this.calculateSummary(this.summaryData)


                          //this.segments[ele.mfgconnectEquipmentId].push(actualData);
                          //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]


                        }
                        if (ele['status'] == "COMPLETED") {
                          let startDatePlan = moment(ele['startTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourPlan = startDatePlan.utc().hours();
                          let endDatePlan = moment(ele['endTime']).utc();
                          let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));

                          let planHours = planDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let planColor;
                          let planTask;
                          let partName;
                          let originalQuantity;
                          ele['isTrial'] ? planColor = "#919294" : planColor = "#FACE13";
                          ele['isTrial'] ? planTask = "TRIAL" : planTask = "PLANNED";
                          ele['isTrial'] ? partName = "" : partName = ele['partName'];
                          ele['isTrial'] ? originalQuantity = "" : originalQuantity = ele['originalQuantity'];

                          let planData = {
                            "id": ele.mfgconnectEquipmentId,
                            // "priority": ele['priority'],
                            "start": startDatePlan,
                            "duration": planHours,
                            "color": planColor,
                            "task": planTask,
                            "partName": partName,
                            "Quantity": originalQuantity,
                            // "time": planMin
                          }

                          let planMin = planDuration1.asMinutes().toFixed(0) + " min " + planDuration1.seconds().toFixed(0).toString() + " sec";
                          if (ele['isTrial'])
                            planData["time"] = planMin

                          // this.segments[ele.mfgconnectEquipmentId].push(planData);
                          let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_prodPlan[temp_machineName].push(planData)

                          // let categoryData = {
                          //   //replace category value by machine name which is id now
                          //   "category": temp_machineName + " Plannnn",
                          //   "LineAlpha": 0.7,
                          //   "expand": true,
                          //   "position": "left",
                          //   "tickLength": 125,

                          // };

                          // this.categoryGuide[temp_machineName] = categoryData;

                          let actualDatePlan = moment(ele['actualStartTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourActual = actualDatePlan.utc().hours();
                          let endDateActual = moment(ele['actualEndTime']).utc();
                          let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

                          let actualHours = actualDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let actualColor = "#54a746";
                          let actualTask = "COMPLETED";
                          let actualName = ele['partName'];
                          let actualQuantity = ele['quantity'];

                          let actualData = {
                            "id": ele.mfgconnectEquipmentId,
                            // "priority": ele['priority'],
                            "start": actualDatePlan,
                            "duration": actualHours,
                            "color": actualColor,
                            "task": actualTask,
                            "partName": actualName,
                            "Quantity": actualQuantity,
                            // "time": planMin
                          }

                          let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                          if (ele['isTrial'])
                            actualData["time"] = actualMin

                          //this.segments[ele.mfgconnectEquipmentId].push(actualData);
                          //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_actualPlan[temp_machineName].push(actualData)

                          // let categoryData = {
                          //   //replace category value by machine name which is id now
                          //   "category": temp_machineName + " Plannnn",
                          //   "LineAlpha": 0.7,
                          //   "expand": true,
                          //   "position": "left",
                          //   "tickLength": 125,

                          // };

                          // this.categoryGuide[temp_machineName] = categoryData;

                        }
                      }); // end of inner loop prodPlan
                    } //end of if prodPlan Array

                    // console.log("xxxxxxxxxxxxxx === ", this.final_prodPlan)
                    // console.log("yyyyyyyy=", this.final_actualPlan)
                    // make productionPlan (dataProvider in JSON)
                    for (var element of Object.keys(this.final_prodPlan)) {

                      this.masterPlan[element] = this.final_prodPlan[element];
                    }
                    for (var element of Object.keys(this.final_actualPlan)) {

                      this.masterActual[element] = this.final_actualPlan[element];
                    }

                    //finished making productionPlan == masterPlan

                    // console.log("!!!", this.masterPlan);



                    //maintainSchedule loop start
                    if (maintainenceSchedule instanceof Array) {

                      maintainenceSchedule.map(ele => {


                        let startDatePlan = moment(ele['startTime']).utc();
                        //2020-06-14T06:37:26Z
                        let startHourPlan = startDatePlan.utc().hours();
                        let endDatePlan = moment(ele['endTime']).utc();
                        let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));
                        let planHours = planDuration1.asHours();
                        // console.log("!!!!!!!!!!!", planHours);
                        let planColor;
                        let planTask;
                        // ele['isTrial'] ? planColor = "#987438" : planColor = "#FACE13";
                        // ele['isTrial'] ? planTask = "Trial" : planTask = "Planned";
                        let planData = {
                          "id": ele.equipmentMaintenanceScheduleId,
                          // "priority": ele['priority'],
                          "start": startDatePlan,
                          "duration": planHours,
                          "color": "#987438",
                          "task": "PREVENTIVE MAINTENANCE",
                          // "partName": ele['partName'],
                          // "Quantity": ele['originalQuantity']
                        }


                        let planMin = planDuration1.asMinutes().toFixed(0) + " min " + planDuration1.seconds().toFixed(0).toString() + " sec";
                        planData["time"] = planMin

                        // this.segments_maintainance[ele.mfgconnectEquipmentId].push(planData)
                        // console.log("kk = ", ele.mfgconnectEquipmentId)
                        let temp_machineName = this.machineDetails[ele.equipmentMaintenanceScheduleId]

                        this.final_maintainacePlan[temp_machineName].push(planData)

                        let categoryData = {
                          //replace category value by machine name which is id now
                          "category": temp_machineName + " Plannnn",
                          "LineAlpha": 0.7,
                          "expand": true,
                          "position": "left",
                          "tickLength": 125,

                        };
                        if (this.categoryGuide[temp_machineName] == undefined) {
                          this.categoryGuide[temp_machineName] = categoryData;
                        }
                        if (ele['status'] == "COMPLETED") {
                          let actualDatePlan = moment(ele['actualStartTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourActual = actualDatePlan.utc().hours();
                          let endDateActual = moment(ele['actualEndTime']).utc();
                          let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

                          let actualHours = actualDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let actualColor = "#f53a00";
                          let actualTask = "MAINTENANCE DOWN";


                          let actualData = {
                            "id": ele.equipmentMaintenanceScheduleId,
                            // "priority": ele['priority'],
                            "start": actualDatePlan,
                            "duration": actualHours,
                            "color": actualColor,
                            "task": actualTask
                            // "time": planMin
                          }

                          let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                          actualData["time"] = actualMin

                          //this.segments[ele.mfgconnectEquipmentId].push(actualData);
                          //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_maintainaceActual[temp_machineName].push(actualData)
                        }




                      }); // end of inner loop maintainance Schedule
                    } //end of if maintainanceSchedule Array
                    //maintainance end
                    //console.log("xxxxxxxxxxxxxx === ", this.final_maintainacePlan)
                    //  console.log("mmmmmmmmmmmmmmmmmmmm ====", this.final_maintainaceActual)
                    //transfer maintainnace plan to Master plan
                    for (var element of Object.keys(this.final_maintainacePlan)) {

                      if (this.masterPlan[element] == undefined) {
                        this.masterPlan[element] = this.final_maintainacePlan[element]
                      }
                      else {
                        for (var maintainance_key of this.final_maintainacePlan[element]) {
                          this.masterPlan[element].push(maintainance_key);
                        }
                      }

                    }

                    for (var element of Object.keys(this.final_maintainaceActual)) {

                      if (this.masterActual[element] == undefined) {
                        this.masterActual[element] = this.final_maintainaceActual[element]
                      }
                      else {
                        for (var maintainance_key of this.final_maintainaceActual[element]) {
                          this.masterActual[element].push(maintainance_key);
                        }
                      }

                    }
                    // transfer end



                    // tool schedule start


                    //toolSchedule loop start
                    if (toolSchedule instanceof Array) {

                      toolSchedule.map(ele => {
                        console.log(ele);
                        let startDatePlan = moment(ele['toolChangeStartTime']).utc()
                        //2020-06-14T06:37:26Z
                        let startHourPlan = startDatePlan.utc().hours();
                        let endDatePlan = moment(ele['toolChangeEndTime']).utc();
                        let planDuration1 = moment.duration(moment(endDatePlan).diff(startDatePlan));
                        let planHours = planDuration1.asHours();
                        // console.log("!!!!!!!!!!!", planHours);
                        let planColor;
                        let planTask;
                        // ele['isTrial'] ? planColor = "#987438" : planColor = "#FACE13";
                        // ele['isTrial'] ? planTask = "Trial" : planTask = "Planned";
                        let planData = {
                          "id": ele.equipmentToolScheduleId,
                          // "priority": ele['priority'],
                          "start": startDatePlan,
                          "duration": planHours,
                          "color": "#E67118",
                          "task": "TOOL CHANGE",
                          // "partName": ele['partName'],
                          // "Quantity": ele['originalQuantity']
                        }
                        let planMin = planDuration1.asMinutes().toFixed(0) + " min " + planDuration1.seconds().toFixed(0).toString() + " sec";
                        planData["time"] = planMin

                        // this.segments_tool[ele.mfgconnectEquipmentId].push(planData);
                        let temp_machineName = this.machineDetails[ele.equipmentToolScheduleId]
                        this.final_toolPlan[temp_machineName].push(planData)

                        let categoryData = {
                          //replace category value by machine name which is id now
                          "category": temp_machineName + " Plannnn",
                          "LineAlpha": 0.7,
                          "expand": true,
                          "position": "left",
                          "tickLength": 125,

                        };
                        if (this.categoryGuide[temp_machineName] == undefined) {
                          this.categoryGuide[temp_machineName] = categoryData;
                        }

                        if (ele['status'] == "COMPLETED") {
                          let actualDatePlan = moment(ele['equipmentActualStartTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourActual = actualDatePlan.utc().hours();
                          let endDateActual = moment(ele['equipmentActualEndTime']).utc();
                          let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

                          let actualHours = actualDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let actualColor = "#f53a00";
                          let actualTask = "TOOL DOWN";


                          let actualData = {
                            "id": ele.equipmentToolScheduleId,
                            // "priority": ele['priority'],
                            "start": actualDatePlan,
                            "duration": actualHours,
                            "color": actualColor,
                            "task": actualTask
                            // "time": planMin
                          }

                          let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                          actualData["time"] = actualMin

                          //this.segments[ele.mfgconnectEquipmentId].push(actualData);
                          //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_toolActual[temp_machineName].push(actualData)
                        }


                      }); // end of inner loop tool Schedule
                    } //end of if toolSchedule Array
                    //tool schedule end
                    console.log("xxxxxxxxxxxxxx === ", this.final_toolPlan)
                    //transfer maintainnace plan to Master plan
                    for (var element of Object.keys(this.final_toolPlan)) {

                      if (this.masterPlan[element] == undefined) {
                        this.masterPlan[element] = this.final_toolPlan[element];
                      }
                      else {

                        for (var tool_key of this.final_toolPlan[element]) {
                          this.masterPlan[element].push(tool_key);
                        }
                      }


                    }

                    for (var element of Object.keys(this.final_toolActual)) {

                      if (this.masterActual[element] == undefined) {
                        this.masterActual[element] = this.final_toolActual[element];
                      }
                      else {

                        for (var tool_key of this.final_toolActual[element]) {
                          this.masterActual[element].push(tool_key);
                        }
                      }


                    }

                    if (actualEquipmentDowntimeOver instanceof Array) {
                      actualEquipmentDowntimeOver.map(ele => {
                        if (ele['status'] == "STARTED") {
                          let actualDatePlan = moment(ele['startTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourActual = actualDatePlan.utc().hours();
                          let endDateActual = moment.utc();
                          let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

                          let actualHours = actualDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let actualColor = "#f53a00";
                          let actualTask = "EQUIPMENT DOWN";


                          let actualData = {
                            "id": ele.equipmentActualDowntimeId,
                            // "priority": ele['priority'],
                            "start": actualDatePlan,
                            "duration": actualHours,
                            "color": actualColor,
                            "task": actualTask
                            // "time": planMin
                          }

                          let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                          actualData["time"] = actualMin
                          let temp_machineName = this.machineDetails[ele.equipmentActualDowntimeId]


                          //this.segments[ele.mfgconnectEquipmentId].push(actualData);
                          //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_equipmentDowntime[temp_machineName].push(actualData)
                        } else {
                          let actualDatePlan = moment(ele['startTime']).utc();
                          //2020-06-14T06:37:26Z
                          let startHourActual = actualDatePlan.utc().hours();
                          let endDateActual = moment(ele['endTime']).utc();
                          let actualDuration1 = moment.duration(moment(endDateActual).diff(actualDatePlan));

                          let actualHours = actualDuration1.asHours();
                          // console.log("!!!!!!!!!!!", planHours);
                          let actualColor = "#f53a00";
                          let actualTask = "EQUIPMENT DOWN";


                          let actualData = {
                            "id": ele.equipmentActualDowntimeId,
                            // "priority": ele['priority'],
                            "start": actualDatePlan,
                            "duration": actualHours,
                            "color": actualColor,
                            "task": actualTask
                            // "time": planMin
                          }

                          let actualMin = actualDuration1.asMinutes().toFixed(0) + " min " + actualDuration1.seconds().toFixed(0).toString() + " sec";
                          actualData["time"] = actualMin
                          let temp_machineName = this.machineDetails[ele.equipmentActualDowntimeId]


                          //this.segments[ele.mfgconnectEquipmentId].push(actualData);
                          //let temp_machineName = this.machineDetails[ele.mfgconnectEquipmentId]
                          this.final_equipmentDowntime[temp_machineName].push(actualData)
                        }
                      })
                    }

                    for (var element of Object.keys(this.final_equipmentDowntime)) {

                      if (this.masterActual[element] == undefined) {
                        this.masterActual[element] = this.final_equipmentDowntime[element];
                      }
                      else {

                        for (var tool_key of this.final_equipmentDowntime[element]) {
                          this.masterActual[element].push(tool_key);
                        }
                      }


                    }

                    this.minDate = this.min_date(this.dateAllMin);
                    this.maxDate = this.max_date(this.dateAllMAx);
                    console.log("minDate: = ", this.minDate, "maxDate: = ", this.maxDate);


                    console.log("|||||||||++  ", this.masterPlan, " ++||||||||||")
                    // transfer end
                    // tool schedule end
                    ////all inside (end)//////

                    // console.log("ooo == ", this.masterPlan)
                    for (var element of Object.keys(this.masterPlan)) {
                      let sortedObjs = _.sortBy(this.masterPlan[element], "start");
                      let noPlan_start = {
                        "id": sortedObjs[0]["id"],
                        "start": moment(this.minDate).utc().hours(),
                        "duration": moment.duration(moment(sortedObjs[0]["start"]).diff(this.minDate)).asHours(),
                        "color": "#759CE7",
                        "task": "No Plan",

                      }
                      let sortedObjs_second = []
                      if (noPlan_start['duration'] != 0)
                        sortedObjs_second.push(noPlan_start)
                      for (let i = 0; i < sortedObjs.length - 1; i++) {
                        sortedObjs_second.push(sortedObjs[i])
                        let sob = sortedObjs[i];
                        let sob_next = sortedObjs[i + 1];


                        let start = moment.duration(moment(sob["start"]).diff(this.minDate)).asHours()
                        let duration = parseFloat(sob["duration"].toString())

                        let span = start + duration;


                        // console.log(sob["id"], typeof (sob["id"]), "kjkjkjkjkkjkjkjkjkj")
                        //console.log("spannnnnnnnnnnn ===== ", start, typeof (start), span, typeof (span), duration, typeof (duration))
                        //
                        let start_of_next = moment.duration(moment(sob_next["start"]).diff(this.minDate)).asHours()
                        console.log(sortedObjs[i]["id"], start, typeof (start), duration, typeof (duration), span, typeof (span), start_of_next, typeof (start_of_next))
                        if (span < start_of_next) {
                          // let noPlan =
                          //console.log("span", span, typeof (span), start_of_next, typeof (start_of_next))
                          console.log("inside if", sortedObjs[i]["id"], start, typeof (start), duration, typeof (duration), span, typeof (span), start_of_next, typeof (start_of_next))

                          let noPlan = {
                            "id": sortedObjs[0]["id"],
                            "start": span,
                            "duration": start_of_next - span,
                            "color": "#759CE7",
                            "task": "No Plan",

                          }
                          sortedObjs_second.push(noPlan)
                          //console.log("spannnnnnnnnnnn ===== ", sortedObjs_second)
                        }




                      }
                      sortedObjs_second.push(sortedObjs[sortedObjs.length - 1])
                      this.masterPlan[element] = sortedObjs_second
                    }

                    //let dataProvider = []
                    for (var element of Object.keys(this.masterPlan)) {

                      let machinePlan_plan = {
                        "category": element + " Plan",
                        "segments": this.masterPlan[element],
                        "LineAlpha": 0.7,
                        "expand": true,
                        "position": "left",
                        "tickLength": 125
                      }

                      let machinePlan_actual = {
                        "category": element + " Actual",
                        "segments": this.masterActual[element],
                        "LineAlpha": 0.7,
                        "expand": true,
                        "position": "left",
                        "tickLength": 125
                      }

                      this.dataProvider.push(machinePlan_plan)
                      this.dataProvider.push(machinePlan_actual)
                    }
                    console.log("final op = ", this.dataProvider)


                    // let dataProvider_actual = []
                    // for (var element of Object.keys(this.masterActual)) {

                    //   let machinePlan = {
                    //     "toCategory": element + " Actual",
                    //     "segments": this.masterActual[element]
                    //   }

                    //   dataProvider_actual.push(machinePlan)
                    // }
                    // console.log("final op = ", dataProvider_actual)



                    // let masterDataProvider = [];
                    // masterDataProvider.length = dataProvider_actual.length + dataProvider_plan.length;
                    // for (var i = 0; i < masterDataProvider.length; i++) {
                    //   masterDataProvider[i++] = dataProvider_plan[i];
                    //   masterDataProvider[i++ + 1] = dataProvider_actual[i];
                    // }
                    // console.log("master data is:", masterDataProvider)

                    // this.maxDateDuration = this.diffrence();

                    // console.log("!!!!!!!!!!!!!!!!!!!!", this.categoryGuide);

                    for (var mp of this.dataProvider) {
                      console.log("mp", mp)
                      let segment_array = mp["segments"];
                      if (segment_array != undefined) {
                        for (var seg of segment_array) {
                          let machine_date = seg["start"];
                          if (machine_date instanceof moment) {
                            let diff = moment.duration(moment(machine_date).diff(this.minDate));
                            // console.log(machine_date, " ", this.minDate, "  ", diff.asHours());
                            seg["start"] = diff.asHours()
                          }

                        }
                      }



                    }

                    this.newPlanMachineName = this.dataProvider;
                    this.newPlanMachineGuide = this.categoryGuide;
                    // this.calculateSummary(this.dataProvider)
                    this.checkAmchart();

                    this.list1.push({ color: 45, size: 'XXL' })
                    this.list1.push({ color: 1, size: 'XL' })
                    this.list1.push({ color: 44, size: 'M' })



                    var sortedObjs = _.sortBy(this.list1, 'color');
                    console.log("{{{{{{{{{{{{{  ", sortedObjs, " }}}}}}}}}}}}}}}}}}}}}}}}")


                  });


                });


              });
            });

          });//end of tool schedule
        });//end of maitenance schedule



      });// end of ProdPlan Schedule (prodPlan)
    });//end of service (resp)







  }     //end of ngOnInit method





  min_date(all_dates) {
    let min_dt = all_dates[0]
    for (var i = 1; i < all_dates.length; i++) {
      if (all_dates[i] < min_dt)
        min_dt = all_dates[i]
    }
    return min_dt
  }


  // var min_dt = all_dates[0],
  //   min_dtObj = new Date(all_dates[0]);
  // all_dates.forEach(function (object, index) {
  //   if (new Date(object) < min_dtObj) {
  //     min_dt = object;
  //     min_dtObj = new Date(object);
  //   }
  //   });
  //   return min_dt;
  // }
  max_date(all_dates) {
    var max_dt = all_dates[0],
      max_dtObj = new Date(all_dates[0]);
    all_dates.forEach(function (object, index) {
      if (new Date(object) > max_dtObj) {
        max_dt = object;
        max_dtObj = new Date(object);
      }
    });
    return max_dt;
  }

  diffrence() {
    var a = moment(this.minDate);
    var b = moment(this.maxDate);

    return b.diff(a, 'days');
  }

  passData(event) {
    console.log(event.graph.customData)
    var data = event.graph.customData
    console.log(data)
    //this.editPlan()
  }

  checkAmchart() {
    // var date1 = new Date();
    // var hours = date1.getHours();
    // console.log("inside after ngINit", hours);

    //
    this.AmCharts.useUTC = true;
    var chart = this.AmCharts.makeChart("chartdiv", {
      "type": "gantt",
      "theme": "light",
      "autoResize": true,
      "creditsPosition": "bottom-right",
      "zoomOutText": '',


      // "period": "ss",
      // "dataDateFormat": "YYYY-MM-DD",
      // "balloonDateFormat": "JJ:NN",
      "period": "hh",
      "dataDateFormat": "YYYY-MM-DD",
      "balloonDateFormat": "JJ:NN",
      "columnWidth": 0.35,
      "categoryAxis": {
        "guides": this.newPlanMachineGuide,
        // "parseDates": true
      },
      "valueAxis": {
        "type": "date",
        // "autoRotateCount": 5,
        "minimumDate": this.minDate,
        "maximumDate": this.maxDate,
        // "labelsEnabled": true,
        // "minimum": this.minDate,
        // "maximum": this.maxDateDuration,
        "balloon": {
          "enabled": true,
        },
        // "guides": [{
        //   "type": "date",
        //   "value": this.maxDate,
        //   "lineThickness": 2,
        //   "lineAlpha": 1,
        //   "lineColor": "#cc0000"
        // }]


      },
      "brightnessStep": 0.3,
      "graph": {
        "fillAlphas": 1,
        // "labelPosition": 'inside',
        // "fillColor": "#54A746",
        "balloonText": "<b>[[task]]</b>:[[time]] [[priority]] [[partName]]  [[Quantity]]"
      },
      "balloon": {
        "adjustBorderColor": false,
        "borderColor": "#5A88E9",
        "color": "#000000",
        // "cornerRadius": 3,
        "fillColor": "#5A88E9",
        "drop": false,
        "pointerWidth": 4,
        "verticalPadding": 10,
        "horizontalPadding": 10
      },
      "rotate": true,
      "zoomControl": {
        "zoomControlEnabled": true
      },
      "categoryField": "category",
      "segmentsField": "segments",
      "colorField": "color",
      "startDate": moment(this.minDate).format("YYYY-MM-DD"),
      // "endDate": moment(this.maxDate).format("YYYY-MM-DD"),
      "startField": "start",
      "endField": "end",
      "durationField": "duration",
      "dataProvider": this.newPlanMachineName,
      "valueScrollbar": {
        "autoGridCount": true
      },
      // "range": {
      //   "date": moment(this.minDate).format("YYYY-MM-DD"),
      //   "grid": {
      //     "strokeWidth": 2,
      //     "strokeOpacity": 1
      //   }
      // },

      "chartCursor": {
        // "cursorPosition": "start",
        "cursorColor": "#55bb76",
        "valueBalloonsEnabled": false,
        "cursorAlpha": 0,
        "valueLineAlpha": 0.5,
        "valueLineBalloonEnabled": true,
        "valueLineEnabled": true,
        "zoomable": false,
        "valueZoomable": true,
        // "cursorPosition": "middle"

        // chart.cursor.lineY.disabled = true;
      },
      "listeners": [{
        "event": "clickGraphItem",
        "method": this.editPlan
      }]


    });
    // let dateAxis = chart.categoryAxis.push(new am4charts.DateAxis());
    // let series = chart.series.push(new am4charts.LineSeries());
    // let seriesRange = dateAxis.createSeriesRange(series);
    // let range = dateAxis.axisRanges.push(new am4charts.DateAxisDataItem());
    // range.grid.stroke = chart.colors.getIndex(0);
    // range.grid.strokeOpacity = 1;
  }


  calculateSummary(data) {
    this.temp = new Map();
    data.map((ele) => {
      if (this.temp.has(ele['actualStatus'])) {
        let count = this.temp.get(ele['actualStatus'])
        count++;
        this.temp.set(ele['actualStatus'], count);
        this.temp.set("Planned", count)
      } else {
        this.temp.set(ele['actualStatus'], 1);
      }
    });

    this.machineStatus.map((stat) => {
      stat.count = this.temp.get(stat.status) === undefined ? 0 : this.temp.get(stat.status);
    });

    console.log(moment().toDate().toISOString())
  }
  enableScheduleActual() {
    this.isScheduleActual = !this.isScheduleActual;
  }
  enablePlan() {
    this.isPlan = !this.isPlan;
  }
  enableToolChange() {
    this.isToolChange = !this.isToolChange;
  }

  enablePlansAborted() {
    this.isPlansAborted = !this.isPlansAborted;
  }

  enablePlansEdited() {
    this.isPlansEdited = !this.isPlansEdited;
  }

  editPlan = (event) => {
    console.log(event.graph.customData)
    var editData = {
      "planId": event.graph.customData.planId,
      "id": event.graph.customData.id
    }
    const dialogRef = this.dialog.open(EditPlanComponent, {
      width: '40%',
      data: editData
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log("result", result);
    });
  }

  myFunction() {
    var info = document.getElementById("info")
    console.log(info.innerText)
  }

  ngOnDestroy() {
    if (this.chart) {
      this.AmCharts.destroyChart(this.chart);
    }
  }

}
