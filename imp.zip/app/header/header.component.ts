import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserProfile } from './user-profile/user-profile';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { Router } from '@angular/router';
import { UserPreferenceSetting } from './user-preference-setting/user-preference-setting';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  middleHeaderText: string = '';
  plantTitle: string = '';
  equipmentTitle: string = '';
  productionLiveTitle: string = '';
  planningTitle: string = '';
  dashboradTitle: string = '';
  batchanalysisTitle: string = '';
  libraryTitle: string = '';
  getDateandTime: Date;
  todaysdate = new Date();
  dateFormat = 'dd.MMM.yyyy HH:mm'
  matDialogRef: MatDialogRef<UserProfile>;
  matDialogRefuserSettings: MatDialogRef<UserPreferenceSetting>;

  constructor(private matDialog: MatDialog, private router: Router, public dialog: MatDialog) { }

  openUserProfile(): void {
    this.matDialogRef = this.matDialog.open(UserProfile, {
      panelClass: ['dark-theme-dialog-container-large-dialog-left'],
    });
  }

  openUserProfileSetting(): void {
    this.matDialogRefuserSettings = this.matDialog.open(UserPreferenceSetting, {
      panelClass: ['dark-theme-dialog-container-large-dialog-left'],
    });
  }


  ngOnInit() {
    this.getWishes();
    this.plantTitle = 'Plant Configuration';
    this.equipmentTitle = 'Condition Monotoring';
    this.dashboradTitle = 'Digital Command Center';
    this.batchanalysisTitle = 'Batch Analysis';
    this.libraryTitle = 'Library Configuration';
    this.productionLiveTitle = 'Production Live Dashboard';
    this.planningTitle = 'Planning Dashboard';
  }

  home() {
    this.router.navigate(['category']);
  }
  dashboard() {
    this.router.navigate(['dashboard']);
  }
  batchAnalysis() {
    this.router.navigate(['batch-analysis']);
  }

  productionLive() {
    this.router.navigate(['discrete-app'])
  }

  planningDashboard() {
    this.router.navigate(['planning-dashboard'])
  }
  getWishes() {
    let today = new Date()
    let curHr = today.getHours()

    if (curHr < 12) {
      this.middleHeaderText = 'Good Morning';
    } else if (curHr < 18) {
      this.middleHeaderText = 'Good Afternoon';
    } else {
      this.middleHeaderText = 'Good Evening';
    }
  }
}
