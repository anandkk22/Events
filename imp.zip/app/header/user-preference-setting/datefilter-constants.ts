export const dateFilterConst = {
    PERFORMANCE: {
        PORTFOLIO: {
            SUMMARY: {
                isSingleDate: false,
                fromDate: 0,
                toDate: ''
            },
            MAP: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            },
            PERFORMANCE_COMPARISON: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            PERFORMANCE_TABLE: {
                isSingleDate: false,
                fromDate: '',
                toDate: ''
            }
        },
        PLANT: {
            SUMMARY: {
                isSingleDate: false,
                fromDate: 0,
                toDate: ''
            },
            FINANCIAL: {
                isSingleDate: false,
                fromDate: 0,
                toDate: ''
            },
            ASSET_OVERVIEW: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            PERFORMANCE_INSIGHTS: {
                isSingleDate: true,
                fromDate: 0,
                toDate: ''
            },
            BENCHMARK: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            CUSTOM_CHART: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            },
            PLANT_PERFORMANCE: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            GRID_PERFORMANCE: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            WEATHER_PERFORMANCE: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            ASSET_PERFORMANCE: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            }
        }
    },
    HEALTH: {
        PORTFOLIO: {
            SUMMARY: {
                isSingleDate: true,
                fromDate: '6',
                toDate: ''
            },
            MAP: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            },
            COMPARISON: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            }
        },
        PLANT: {
            SUMMARY: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            },
            MAP: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            },
            COMPARISON: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            },
            INSIGHT_DETAILS: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            },
            KHI_TRENDS: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            }
        }
    },
    EVENTS: {
        PORTFOLIO: {
            SUMMARY: {
                isSingleDate: true,
                fromDate: 0,
                toDate: ''
            }
        },
        PLANT: {
            SUMMARY: {
                isSingleDate: true,
                fromDate: 0,
                toDate: ''
            },
            HISTORICAL_EVENTS: {
                isSingleDate: true,
                fromDate: 0,
                toDate: ''
            }
        }
    },
    ROC: {
        PLANT: {
            ENVIRONMENTAL: {
                isSingleDate: true,
                fromDate: 0,
                toDate: ''
            }
        },
        ASSET: {
            KPI_VALUE: {
                isSingleDate: true,
                fromDate: 0,
                toDate: ''
            },
            CUMULATIVE_CHART: {
                isSingleDate: true,
                fromDate: 6,
                toDate: ''
            }
        }
    },
    ENERGY: {
        PLANT: {
            EL_ANALYSIS: {
                isSingleDate: true,
                fromDate: '',
                toDate: ''
            }
        }
    },
    ACTION_ITEMS: {
        PLANT: {
            FILTER: {
                isSingleDate: false,
                fromDate: 6,
                toDate: ''
            }
        }
    }
};
