// import { BaseEntity } from 'app/shared';
// import * as preferencesConstants from './user-preferences.constants';

export interface IUserPreferences {
    id?: any;
    login?: string;
    preferences?: {
        theme: string[];
        landing: string[];
        dateFormat: string[];
        timeFormat: string[];
        language: string[];
        notification: string[];
        notifMessage: string[];
        notifSound: string[];
        indicator: string[];
    };
}

export class UserPreferences implements IUserPreferences {
    constructor(
        public id?: string,
        public login?: string,
        public preferences?: {
            theme: string[];
            landing: string[];
            dateFormat: string[];
            timeFormat: string[];
            language: string[];
            notification: string[];
            notifMessage: string[];
            notifSound: string[];
            indicator: string[];
        }
    ) {}
}
