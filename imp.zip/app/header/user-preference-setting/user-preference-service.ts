import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserPreferences } from './user-preferences.model';
import * as userPreferencesConstant from './user-preferences.constants';

@Injectable({providedIn: 'root' })
export class UserPreferenceService {
    constructor() { }

    setDefaultUserPreferences() {
        const userpref: UserPreferences = {} as any;
        // userpref.login = login;
        userpref.preferences = {} as any;        
        userpref.preferences.landing = [userPreferencesConstant.landing[0]];
        userpref.preferences.dateFormat = [userPreferencesConstant.dateFormat[0]];
        userpref.preferences.timeFormat = [userPreferencesConstant.timeFormat[0]];
        userpref.preferences.language = [userPreferencesConstant.language[0]];
        userpref.preferences.notification = [userPreferencesConstant.notification[0]];
        userpref.preferences.notifMessage = [userPreferencesConstant.notifMessage[0]];
        userpref.preferences.notifSound = [userPreferencesConstant.notifSound[0]];

        return userpref;
    }

    getDefaultUserPreferences() {
        const defaultPref = this.setDefaultUserPreferences();
        return defaultPref;
    }

}