import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home.component';
import { HOME_ROUTE } from './home.route';
import { BrowserModule } from '@angular/platform-browser';
import { MatTooltipModule, MatIconModule } from '@angular/material';
import { CoreModule } from '../core';


@NgModule({
    imports: [RouterModule.forChild([HOME_ROUTE]), FormsModule,ReactiveFormsModule,CoreModule, BrowserModule,MatTooltipModule, MatIconModule],
    declarations: [HomeComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ApollowebHomeModule {}
