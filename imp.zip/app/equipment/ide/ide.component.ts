import { Component, OnInit } from "@angular/core";
import { MachineIdesService } from "./machine-ides.service";
import { Router } from "@angular/router";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import * as am4maps from "@amcharts/amcharts4/maps";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { matMenuAnimations } from "@angular/material";
import { CodeNode } from "source-list-map";

@Component({
  selector: "app-ide",
  templateUrl: "./ide.component.html",
  styleUrls: ["./ide.component.scss"],
})
export class IdeComponent implements OnInit {
  constructor(private service: MachineIdesService, private _router: Router) {}

  public donutChart: any = [];
  public donutChartOperation: any = [];
  public rwPumpPressureClr = "#ff6699";

  public SolutionUtilityPlants: any = {
    name: "",
    number: "",
    plantStatus: "",
    status: "",
    idle: "",
    operational: "",
    caution: "",
    warning: "",
    disconnected: "",
    totalAccelaration: "",
    velocityX: "",
    velocityY: "",
    velocityZ: "",
    tempearture: "",
    audiodB: "",
    alarm_Status: "",
    alarm_Number: "",
  };
  public SolutionIdes: any = {
    name: "",
    number: "",
    machineStatus: "",
    status: "",
    idle: "",
    operational: "",
    caution: "",
    warning: "",
    disconnected: "",
    totalAccelaration: "",
    velocityX: "",
    velocityY: "",
    velocityZ: "",
    tempearture: "",
    audiodB: "",
    alarm_Status: "",
    alarm_Number: "",
  };
  public userFilter: any = { displayName: "" };
  public plantNames: any = { displayName: "" };

  ngOnInit() {
    this.getAllData();
  }

  getAllData() {
    this.service.getelementsDetails().subscribe((resp) => {
      this.SolutionUtilityPlants = resp;
      this.plantNames = this.SolutionUtilityPlants[0].Plant[0];
      console.log(this.plantNames);
      this.donutChart = this.SolutionUtilityPlants[0].Plant[1].plantStatus;
      if (this.donutChart != null) {
        this.constructDonutChart("chartdiv1", this.donutChart);
      }
    });

    this.service.getidesDetails().subscribe((resp) => {
      this.SolutionIdes = resp;
      this.donutChart = this.SolutionIdes[0].Machine[2].machineStatus;
      this.donutChartOperation = this.SolutionIdes[0].Machine[3].totalOperation;
      console.log(this.donutChart);
      if (this.donutChart != null) {
        this.constructDonutChart("chartdiv1", this.donutChart);
        this.constructDonutChart("chartdiv2", this.donutChartOperation);
      }
    });
  }
  navigatemachines() {
    this._router.navigate(["/equipment"]);
  }
  // navigateides() {
  //   this._router.navigate(["/ide"]);
  // }
  minus_plus_icon_toggle_CBM_h1() {
    const element = document.getElementById("minus-image-h1");
    element.classList.toggle("d-none");
    const element2 = document.getElementById("plus-image-h1");
    element2.classList.toggle("d-none");
  }
  minus_plus_icon_toggle_CBM_h2() {
    const element = document.getElementById("minus-image-h2");
    element.classList.toggle("d-none");
    const element2 = document.getElementById("plus-image-h2");
    element2.classList.toggle("d-none");
  }

  constructDonutChart(id, chartData) {
    am4core.useTheme(am4themes_animated);
    const chart = am4core.create(id, am4charts.PieChart);
    chart.data = chartData;

    chart.innerRadius = am4core.percent(38);
    chart.fontSize = 11;

    const pieSeries = chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = "count";
    pieSeries.dataFields.category = "status";
    pieSeries.slices.template.stroke = am4core.color("#fff");
    pieSeries.slices.template.propertyFields.fill = "statusColor";

    pieSeries.slices.template.strokeWidth = 0;
    pieSeries.slices.template.strokeOpacity = 0;
    pieSeries.slices.template.tooltipHTML = `<span>{category}: <strong>{count} </strong></span>`;
    pieSeries.alignLabels = false;
    pieSeries.labels.template.fontSize = 11;

    pieSeries.labels.template.text =
      "{value.percent.formatNumber('#.0')}% {count}";
    pieSeries.labels.template.radius = am4core.percent(-23);
    pieSeries.labels.template.fill = am4core.color("#000");

    pieSeries.labels.template.adapter.add("radius", function (radius, target) {
      if (target.dataItem && target.dataItem.values.value.percent < 10) {
        return 0;
      }
      return radius;
    });
    pieSeries.labels.template.adapter.add("fill", function (color, target) {
      if (target.dataItem && target.dataItem.values.value.percent < 10) {
        return am4core.color("#FFF");
      }
      return color;
    });

    pieSeries.hiddenState.properties.opacity = 1;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;
  }
}
