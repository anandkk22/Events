import { of } from 'rxjs';
import { OperatorDashboardComponent } from './operator-dashboard.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartsModule } from 'ng2-charts';
import { OperatorRoutingModule } from './operator-dashboard-routing.module';
//import { BarChartComponent } from './bar-chart/bar-chart.component';
import { ProgressBarModule } from "angular-progress-bar";
import { NbProgressBarModule } from '@nebular/theme';
import { BarChartComponent } from './bar-chart/bar-chart.component';


@NgModule({
  declarations: [OperatorDashboardComponent, BarChartComponent
    //, BarChartComponent
  ],
  imports: [
    CommonModule,
    OperatorRoutingModule,
    ChartsModule,
    ProgressBarModule,
    NbProgressBarModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      "radius": 80,
      "space": -10,
      "outerStrokeLinecap": "square",
      "outerStrokeGradient": true,
      "innerStrokeWidth": 10,
      "title": '',
      "titleFontSize": '15',
      "titleFontWeight": 'bold',
      "titleColor": '#ffffff',
      "units": '',
      "unitsFontSize": '30',
      "unitsFontWeight": 'normal',
      "unitsColor": '#ffffff',
      "subtitle": '',
      "subtitleColor": '#ffffff',
      "subtitleFontSize": '15',
      "subtitleFontWeight": 'normal',
      "showBackground": true,
      "clockwise": true,
      "startFromZero": false,
      "responsive": true,
      "outerStrokeColor": "#63982d",
      "outerStrokeGradientStopColor": "#63982d",
      "renderOnClick": false
    })
  ],
  exports: [OperatorDashboardComponent]
})
export class OperatorModule { }
