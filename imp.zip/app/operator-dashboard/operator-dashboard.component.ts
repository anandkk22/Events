import { Component, OnInit, Input } from '@angular/core';

import { Observable } from 'rxjs';

import * as moment from 'moment';
//import { OperatorService } from './operator.service';
import { ActivatedRoute, Params } from '@angular/router';
import { element } from 'protractor';
import { number } from '@amcharts/amcharts4/core';
import { OperatorService } from './operator-dashboard.service';

@Component({
  selector: 'app-operator-dashboard',
  templateUrl: './operator-dashboard.component.html',
  styleUrls: ['./operator-dashboard.component.scss']
})
export class OperatorDashboardComponent implements OnInit {

  progressbar;
  circularProgress;
  // data: any;
  utilization: any = [];
  parts: any = [];
  operatorData: any;
  operatorList: any = [];
  startTimeStamp: any;
  endTimeStamp: any;
  clock;
  data: any;
  finalOee = 0;
  finalAvailability = 0;
  finalQuality = 0;
  finalPerformance = 0;
  constructor(private opservice: OperatorService, private route: ActivatedRoute) { }

  ngOnInit() {

    const equipmentId: any = this.route.snapshot.params.id;
    console.log(equipmentId)

    this.endTimeStamp = moment().utc().format();

    this.startTimeStamp = moment().subtract('minutes', 5).utc().format();
    console.log("cccccc")
    console.log(this.data)

    // this.operatorData = {
    //   deviceId: id,
    //   startTimestamp: this.startTimeStamp,
    //   endTimestamp: this.endTimeStamp,
    //   parameter: null,
    //   resolution: "1"
    // }

    this.operatorList.push(this.operatorData)


    // this.opservice.getOperatorData(this.operatorList).subscribe(resp => {
    //   console.log("Operator data for display:", resp);
    //   this.data = resp;
    //   // console.log("", this.data.utilization);
    //   // console.log("", this.data.parts);
    //   this.utilization = this.data[0].readings[0].UTILIZATION;
    //   // this.utilization.forEach(element => {
    //   //   var time = element['time']
    //   //   time = time + "am";
    //   //   element['time'] = time;
    //   // });
    //   this.parts = this.data[0].readings[0].PARTS;
    //   // this.parts.forEach(element => {
    //   //   var time = element['time']
    //   //   time = time + "am";
    //   //   element['time'] = time;
    //   // })
    //   console.log("utilization", this.utilization)
    //   console.log("u", this.parts)
    //   this.progressbar = this.progressCal(this.data);
    //   this.circularProgress = this.circularProgressCal(this.data);
    // });
    // this.opservice.getOperatorData().subscribe(resp => {
    //   console.log("Operator data for display:", resp);
    //   // this.data = resp;
    //   // console.log("", this.data.utilization);
    //   // console.log("", this.data.parts);
    //   if (resp instanceof Object) {
    //     this.utilization = resp['utilization']
    //     this.parts = resp['parts']
    //     console.log("", this.utilization);
    //     console.log("", this.parts);
    //   }


    // });
    this.opservice.getCurrentJobList(equipmentId).subscribe(resp => {
      this.data = resp
      console.log("type of resp", typeof (this.data), this.data)
      var Job = this.data[0]['productName']
      this.circularProgressCal(this.data)
    })

    this.opservice.getKpiData(equipmentId).subscribe(resp => {
      console.log("kpi data is:", resp)
      var oeeArray = [];
      var qualityArray = []
      var performanceArray = []
      var availabiltyArray = []
      if (resp instanceof Array) {
        resp.forEach(element => {
          var oeeString = element.hourlyKPI.oee
          var oee = parseInt(oeeString)
          oeeArray.push(oee)
          var qualityString = element.hourlyKPI.quality
          var quality = parseInt(qualityString)
          qualityArray.push(quality)
          var performanceString = element.hourlyKPI.performance
          var performance = parseInt(performanceString)
          performanceArray.push(performance)
          var availabilityString = element.hourlyKPI.availability
          var availability = parseInt(availabilityString)
          availabiltyArray.push(availability)
        })
        console.log("oee array is", oeeArray)
      }
      var availLength = 1;
      //var finalOee = 0
      for (var i = 0; i < oeeArray.length; i++) {
        this.finalOee = this.finalOee + oeeArray[i];
      }
      for (var i = 0; i < qualityArray.length; i++) {
        this.finalQuality = this.finalQuality + qualityArray[i];
      }
      for (var i = 0; i < performanceArray.length; i++) {
        this.finalPerformance = this.finalPerformance + performanceArray[i];
      }
      for (var i = 0; i < availabiltyArray.length; i++) {
        if (availabiltyArray[i] != undefined) {
          this.finalAvailability = this.finalAvailability + availabiltyArray[i];
          availLength++;
        }


      }
      this.finalOee = this.finalOee / oeeArray.length
      this.finalQuality = this.finalQuality / qualityArray.length;
      this.finalPerformance = this.finalPerformance / performanceArray.length;
      this.finalAvailability = this.finalAvailability / availLength;
      console.log("final oee is", this.finalOee)
    })
    this.opservice.getHourSpecificData(equipmentId).subscribe(resp => {

      if (resp instanceof Array) {
        var tempParts = []
        var maxParts = [];
        var utilParts = []
        var length = resp.length;
        resp.forEach(element => {
          var stringParts = element.hourLevelAggregation.hourlyActualProduction
          var parts = parseInt(stringParts)
          maxParts.push(parts)
          //console.log("!!!!!!!", parts)
          var time = element.timestamp
          time = moment(time).utc().format("hh:mm a")
          var obj = {
            "parts": parts,
            "time": time
          }
          tempParts.push(obj)
        })

        // console.log("%%%%%%%%", obj)
        var max = maxParts[0]
        for (var i = 1; i < maxParts.length; i++) {

          if (maxParts[i] > max) {
            max = maxParts[i]
          }
        }
        console.log("type of:{}", typeof (max))
        // maxParts.forEach(item => {
        //   if (item == max) {
        //     var util = {
        //       "parts": 100,
        //       "time": time
        //     }
        //     utilParts.push(util)
        //   } else {
        //     var x = (100 * item) / max
        //     var util = {
        //       "parts": x,
        //       "time": time
        //     }
        //     utilParts.push(util)
        //   }
        // })

        for (var i = 0; i < tempParts.length; i++) {
          console.log("final max is:{}", max)
          var a = tempParts[i].parts
          var time = tempParts[i].time
          if (a == max) {
            console.log(" a is ", a)
            var util = {
              "parts": 100,
              "time": time
            }
            utilParts.push(util)

          }
          else {
            var x = (100 * a) / max
            var util = {
              "parts": x,
              "time": time
            }
            utilParts.push(util)

          }
        }
        console.log("max parts is:{}", max)


        this.utilization = utilParts
        console.log("utilization array is:{}", this.utilization)
        this.parts = tempParts
        // var stringParts = resp[length - 1].hourLevelAggregation.hourlyActualProduction
        // console.log("type of parts is", typeof (stringParts))

        // var parts = parseInt(stringParts)
        // console.log("type of parts is", typeof (parts))
        // var time = resp[length - 1].timestamp
        // time = moment(time).utc().format("hh:mm")
        // console.log("parts is:", parts, time)
        // var obj = {
        //   "parts": 24,
        //   "time": "10am"
        // }
        //this.parts.push(obj)
        //  console.log("final array is:", this.parts)
      }
    })
  }

  progressCal(data) {
    let produce = data[0].readings[0].PRODUCTION_PLAN['PRODUCED']
    console.log("produce", this.data[0].readings[0])
    let required = data[0].readings[0].PRODUCTION_PLAN['REQUIRED']
    this.progressbar = [(produce / required) * 100];
    return this.progressbar + "%";

  }
  circularProgressCal(data) {
    let actual = data[0]['quantity']
    let expected = data[0]['originalQuantity']
    this.circularProgress = [(actual / expected) * 100];
    return this.circularProgress;

  }


}
