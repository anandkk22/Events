import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {

  @Input() barchartData: any = [];
  data: any = [];
  dataChartLabel: any = [];

  constructor() { }

  public barChartOptions = {

    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
        font: {
          size: 20,
        }
      }
    },
    data: {
      datasets: [{
        // Change options only for labels of THIS DATASET
        datalabels: {
          color: 'red'
        }
      }]
    },
    tooltips: {
      enabled: false,
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          fontColor: '#72bb53',

        },
        gridLines: { color: '#DEDEDE' }
      }],
      xAxes: [{
        ticks: {
          // stepSize: 100,
          display: true,
          fontColor: '#72bb53',
          autoSkip: true,
          autoSkipPadding: 5,
          mirror: false,
        },
        gridLines: {
          display: false,
          tickMarkLength: 10,

        }
      }]
    },
    scaleShowVerticalLines: true,
    responsive: true
  };

  public barChartLabels = this.dataChartLabel;
  public barChartType = 'bar';
  public barChartLegend = false;
  public barChartDataUtilization = [
    {
      data: this.data,
      backgroundColor: '#DEDEDE',
      hoverBackgroundColor: '#DEDEDE',
      // dataLabels: {
      //   align: 'start',
      //   anchor: 'end'
      // }
    },
  ];

  ngOnInit() {
    this.barchartData.map(ele => {
      this.data.push(ele.parts);
      this.dataChartLabel.push(ele.time);
    });

    // this.barchartData.forEach(element => {
    //   this.data.push(element.parts);
    //   this.dataChartLabel.push(element.time);
    // })

    console.log("Input data for chart", this.data);
    console.log("Input time for chart", this.dataChartLabel);
  }
}
