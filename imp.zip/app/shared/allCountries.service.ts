import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AllCountriesService {

    public url: string = '../assets/json/all-countries.json';
    constructor(private _http: HttpClient){}

    getAllCountries():Observable<any> {
        return this._http.get<any>(this.url)
    }
}