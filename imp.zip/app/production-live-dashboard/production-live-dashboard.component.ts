import { Component, OnInit } from '@angular/core';
import { ProductionLiveService } from './production-live-dashboard-service.service';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { PlanningDashboardService } from '../planning-dashboard/planning-dashboard.service';

@Component({
  selector: 'app-production-live-dashboard',
  templateUrl: './production-live-dashboard.component.html',
  styleUrls: ['./production-live-dashboard.component.scss']
})
export class ProductionLiveDashboardComponent implements OnInit {

  //, OnDestroy
  data: any = [];
  finalOee = 0;
  machineStatus = [
    {
      status: "Running",
      count: 0,
      Display: "Running"
    },
    {
      status: "Down",
      count: 0,
      Display: "M/c Down"
    },
    {
      status: "Tool_change",
      count: 0,
      Display: "Tool Change"
    },
    // {
    //   status: "Color_change",
    //   count: 0,
    //   Display: "Color Change"
    // },
    {
      status: "No_plan",
      count: 0,
      Display: "No Plan"
    },
    {
      status: "Trial",
      count: 0,
      Display: "Trial"
    },
    {
      status: "Preventive",
      count: 0,
      Display: "Preventive"
    }
  ]
  temp = new Map();
  runningCount = 0;

  // machineStatSubscription: Subscription;
  // oeeStatusSubscription: Subscription;
  // productStatusSubscription: Subscription;
  machineStat: any;
  oeeStatus: any;
  productStatus: any = [];
  tempData: any = [];
  updatedMachineStat: any = [];
  updatedOEEStat: any = [];
  updatedProductStat: any = [];
  sub: Subscription;
  deviceId: any = [];
  rawDataInfo: any = [];
  oeeList: any = [];
  machineStatusList: any = [];
  productStatusList: any = [];
  date = new Date();
  endTimeStamp: any;
  startTimeStamp: any;
  rawData: any;
  oeeStatusSubscription: any;
  productStatusSubscription: any;
  machineStatSubscription: any;
  machineDetails: any = [];
  currentTime: any;

  constructor(private machineService: ProductionLiveService, private router: Router, private machineViewService: PlanningDashboardService
    //, private opservice: OperatorService
  ) { }

  ngOnInit() {

    this.endTimeStamp = moment().utc().format();
    console.log(this.endTimeStamp)
    this.startTimeStamp = moment().subtract('minutes', 5).utc().format();
    console.log(this.startTimeStamp);
    this.currentTime = new Date();
    this.machineViewService.getCNCMachines().subscribe(resp => {
      this.machineDetails = resp
      // this.machineDetails.forEach(element => {
      //   element['actualState'] = "No_plan";
      //   element['actualStartTime'] = this.currentTime;
      // });
      // var machineData = {
      //   "id": 1109,
      //   "machineName": "Device_CNC9"
      // }
      // this.machineDetails.push(machineData)
      this.data = this.machineDetails
      this.data.forEach(item => {
        var assetId = item['id']
        // this.opservice.getKpiData(assetId).subscribe(resp => {
        //   console.log("kpi data is:", resp)
        //   item['oee'] = resp
        //   console.log("oee added data is", this.data)
        //   var tempOee = item.oee
        //   console.log(" temp oee Array is", tempOee)
        //   var oeeArray = [];
        //   var performanceArray = [];
        //   var finalOee = 0
        //   var finalPerformance = 0
        //   if (tempOee instanceof Array) {
        //     tempOee.forEach(element => {

        //       var oeeString = element.hourlyKPI.oee
        //       var oee = parseInt(oeeString)
        //       oeeArray.push(oee)
        //       var performanceString = element.hourlyKPI.performance
        //       var performance = parseInt(performanceString)
        //       performanceArray.push(performance);
        //     })
        //   }
        //   for (var i = 0; i < oeeArray.length; i++) {
        //     finalOee = finalOee + oeeArray[i];
        //   }
        //   finalOee = finalOee / oeeArray.length
        //   item['finalOee'] = finalOee

        //   for (var i = 0; i < performanceArray.length; i++) {
        //     finalPerformance = finalPerformance + performanceArray[i];
        //   }
        //   finalPerformance = finalPerformance / performanceArray.length
        //   item['finalPerformance'] = finalPerformance
        //   console.log("oee is", item['finalOee'])
        // })
      })


    });
    this.machineStatSubscription = setInterval(() => {

      console.log("machine details:", this.machineDetails.length)
      this.machineService.getMachineData().subscribe(resp => {
        console.log("machine json data", resp);
        if (resp instanceof Array) {
          resp.forEach(element => {
            // element['actualState'] = "Running";
            // element['planSet'] = true;
            // this.data.push(element);
            this.data.forEach(item => {
              if (item['id'] == element['mfgconnectEquipmentId']) {
                //item['machineName'] = element['machineName'];
                item['actualState'] = "Running";
                item['partNumber'] = element['productNumber'];
                item['originalQuantity'] = element['originalQuantity']
                item['actualStartTime'] = element['actualStartTime']
                item['quantity'] = element['quantity'];
                item['efficiency'] = element['efficiency'];
              }
            })
            this.data.forEach(item => {
              if (item['actualStartTime'] instanceof Date) {
                var utcDate = new Date(item['actualStartTime']);
                var utcDateString = utcDate.toISOString();
                item['actualStartTime'] = utcDateString
              }
            })
          })
        }
        this.calculateSummary();
      });
      this.machineService.getMaintenanceData().subscribe(resp => {
        console.log("machine undergoing data", resp);
        if (resp instanceof Array) {
          resp.forEach(element => {
            this.data.forEach(item => {
              if (item['id'] == element['equipmentMaintenanceScheduleId']) {
                //item['machineName'] = element['machineName'];
                item['actualState'] = "Preventive";
                // item['partNumber'] = element['partNumber'];
                // item['originalQuantity'] = element['originalQuantity']
                item['actualStartTime'] = element['actualStartTime']
                //  item['quantity'] = element['quantity'];
                // item['efficiency'] = element['efficiency'];
              }
            })
          })
        }
        console.log("modified result is", this.data)
        this.calculateSummary();
      })
      this.machineService.getToolScheduleData().subscribe(resp => {
        console.log("tool change", resp)
        if (resp instanceof Array) {
          resp.forEach(element => {
            this.data.forEach(item => {
              if (item['id'] == element['equipmentToolScheduleId']) {
                //item['machineName'] = element['machineName'];
                item['actualState'] = "Tool_change";
                // item['partNumber'] = element['partNumber'];
                // item['originalQuantity'] = element['originalQuantity']
                item['actualStartTime'] = moment(element['equipmentActualStartTime']).toISOString()
                console.log("date is", item['actualStartTime'])
                //  item['quantity'] = element['quantity'];
                // item['efficiency'] = element['efficiency'];
              }
            })
          })
          // this.data.forEach(item => {
          //   if (item['actualStartTime'] instanceof Date) {
          //     var utcDate = item['actualStartTime'];
          //     var utcDateString = utcDate.toISOString();
          //     item['actualStartTime'] = utcDateString
          //   }
          // })
        }

        this.calculateSummary();
      })
      this.machineService.getEquipmentDowntime().subscribe(resp => {
        if (resp instanceof Array) {
          resp.forEach(element => {
            this.data.forEach(item => {
              if (item['id'] == element['equipmentActualDowntimeId']) {
                item['actualState'] = "Down";
                item['actualStartTime'] = element['startTime']
              }
            })
          })
        }
      })
      console.log("final output without no plan", this.data)
      this.findNoPlanData();
      // this.fetchOee();
      this.calculateSummary();
    }, 3000);






    // this.deviceId.forEach(element => {
    //   this.rawData = {
    //     deviceId: element,
    //     startTimestamp: this.startTimeStamp,
    //     endTimestamp: this.endTimeStamp,
    //     parameter: "MACHINE_STATUS",
    //     resolution: "1"
    //   }
    //   this.machineStatusList.push(this.rawData)
    // });

    // this.machineService.getMachineStatus(this.machineStatusList)
    //   .subscribe((result) => {
    //     this.updatedMachineStat = result;
    //     this.updatedMachineStat.map((ele) => {
    //       this.data.map(data => {
    //         if (ele.name == data.name) {
    //           data.MachineStatus = ele.MachineStatus;
    //         }
    //       });
    //     });
    //     this.calculateSummary();
    //     console.log("Machine status:", this.data);
    //   });
    // this.oeeStatusSubscription = setInterval(() => {
    //   this.endTimeStamp = moment().utc().format();
    //   this.startTimeStamp = moment().subtract('minutes', 15.5).utc().format();
    //   this.deviceId.forEach(element => {
    //     this.rawData = {
    //       deviceId: element,
    //       startTimestamp: this.startTimeStamp,
    //       endTimestamp: this.endTimeStamp,
    //       parameter: "OEE",
    //       resolution: "1"
    //     }
    //     this.oeeList.push(this.rawData)
    //   });
    //   this.machineService.getOEE(this.oeeList).subscribe((result) => {
    //     this.updatedOEEStat = result;
    //     this.updatedOEEStat.map((ele) => {
    //       this.data.map(data => {
    //         if (ele.deviceId == data.deviceId) {
    //           data.readings[0]['OEE'] = ele.readings[0]['OEE'];
    //         }
    //       });
    //     });
    //     this.calculateSummary();
    //     // this.calculateTimestamp();
    //     console.log("OEE status:", this.data);
    //   })
    // }, 10000)



    // this.machineStatSubscription = setInterval(() => {
    //   this.endTimeStamp = moment().utc().format();
    //   this.startTimeStamp = moment().subtract('minutes', 15.5).utc().format();
    //   this.deviceId.forEach(element => {
    //     this.rawData = {
    //       deviceId: element,
    //       startTimestamp: this.startTimeStamp,
    //       endTimestamp: this.endTimeStamp,
    //       parameter: "MACHINE_STATUS",
    //       resolution: "1"
    //     }
    //     this.machineStatusList.push(this.rawData)
    //   });

    //   this.machineService.getMachineStatus(this.machineStatusList)
    //     .subscribe((result) => {
    //       this.updatedMachineStat = result;
    //       this.updatedMachineStat.map((ele) => {
    //         this.data.map(data => {
    //           if (ele.deviceId == data.deviceId) {
    //             data.readings[0]['MACHINE_STATUS'] = ele.readings[0]['MACHINE_STATUS'];
    //           }
    //         });
    //       });
    //       this.calculateSummary();
    //       console.log("Machine status:", this.data);
    //     });
    // }, 3000)

    // this.productStatusSubscription = setInterval(() => {
    //   this.endTimeStamp = moment().utc().format();
    //   this.startTimeStamp = moment().subtract('minutes', 15.5).utc().format();
    //   this.deviceId.forEach(element => {
    //     this.rawData = {
    //       deviceId: element,
    //       startTimestamp: this.startTimeStamp,
    //       endTimestamp: this.endTimeStamp,
    //       parameter: "PRODUCT_STATUS",
    //       resolution: "1"
    //     }
    //     this.productStatusList.push(this.rawData)
    //   });
    //   this.machineService.getProduct(this.productStatusList)
    //     .subscribe((result) => {
    //       this.updatedProductStat = result;
    //       this.updatedProductStat.map((ele) => {
    //         this.data.map(data => {
    //           if (ele.deviceId == data.deviceId) {
    //             data.readings[0]['PRODUCT_STATUS'] = ele.readings[0]['PRODUCT_STATUS'];
    //           }
    //         });
    //       });
    //       this.calculateSummary();
    //       // this.calculateTimestamp();
    //       console.log("Product status:", this.data);
    //     });
    // }, 10000)



    // this.productStatusSubscription = interval(2000)
    //   .pipe(
    //     switchMap(() => this.machineService.getProduct(this.productStatusList))
    //   )
    //   .subscribe((result) => {
    //     this.updatedProductStat = result;
    //     this.updatedProductStat.map((ele) => {
    //       this.data.map(data => {
    //         if (ele.deviceId == data.deviceId) {
    //           data.readings[0]['PRODUCT_STATUS'] = ele.readings[0]['PRODUCT_STATUS'];
    //         }
    //       });
    //     });
    //     this.calculateSummary();
    //     this.calculateTimestamp();
    //     console.log("Product status:", this.data);
    //   });






    // this.rawData.push({
    //   "deviceId": "DEVICE_CNC1",
    //   "startTimestamp": "2020-06-04T03:00:00Z",
    //   "endTimestamp": "2020-06-04T03:55:00Z",
    //   "parameter": null,
    //   "resolution": "5"
    // })


    this.data.forEach(element => {
      element.readings[0].PRODUCT_STATUS['REJECT_PARTS_COUNT'] = (element.readings[0].PRODUCT_STATUS['GOOD_PARTS_COUNT']) / (element.readings[0].PRODUCT_STATUS['PARTS_COUNT']) * 100;
      // if (element.readings[0].MACHINE_STATUS['MACHINE_STATUS'] == 'Down' && element.readings[0]['MACHINE_DOWNTIME_REASON'] != null) {
      //   element.rawData.measurements['MACHINE_DOWNTIME_START_TIME'] = element.rawData.measurements['MACHINE_DOWNTIME_START_TIME'];
      // } else {
      //   element.rawData.measurements['MACHINE_DOWNTIME_START_TIME'] = element.rawData['timestamp']
      // }
      // if (element.rawData.measurements['MACHINE_DOWNTIME_REASON'] == null) {
      //   element.rawData.measurements['MACHINE_DOWNTIME_REASON'] = "N/A"
      // }
    });


    // this.data.map((element) => {
    //   let productStatusObject = {
    //     'id': '',
    //     'partsCount': '',
    //     'goodParts': '',
    //     'rejectParts': ''
    //   }
    //   productStatusObject = {
    //     id: element.rawData['hardwareId'],
    //     partsCount: element.rawData.measurements['PARTS_COUNT'],
    //     goodParts: element.rawData.measurements['GOOD_PARTS_COUNT'],
    //     rejectParts: element.rawData.measurements['REJECT_PARTS_COUNT']
    //   };
    //   this.productStatus.push(productStatusObject);
    // })
    // console.log(this.productStatus)
    // this.calculateSummary();
    // console.log("stat as", this.machineStatus);







  }

  findNoPlanData() {
    for (var i = 0; i < this.data.length; i++) {
      if (this.data[i].actualState) {
        continue;
      } else {
        this.data[i].actualState = "No_plan"
        this.data[i].actualStartTime = this.currentTime
      }
    }
  }

  // if (resp instanceof Array) {
  //   resp.forEach(element => {
  //     var oeeArray = [];
  //     var qualityArray = []
  //     var performanceArray = []
  //     var availabiltyArray = []
  //     var oeeString = element.hourlyKPI.oee
  //     var oee = parseInt(oeeString)
  //     oeeArray.push(oee)
  //     var qualityString = element.hourlyKPI.quality
  //     var quality = parseInt(qualityString)
  //     qualityArray.push(quality)
  //     var performanceString = element.hourlyKPI.performance
  //     var performance = parseInt(performanceString)
  //     performanceArray.push(performance)
  //     var availabilityString = element.hourlyKPI.availability
  //     var availability = parseInt(availabilityString)
  //     availabiltyArray.push(availability)
  //     for (var i = 0; i < oeeArray.length; i++) {
  //       this.finalOee = this.finalOee + oeeArray[i];
  //     }
  //     this.finalOee = this.finalOee / oeeArray.length

  //   })

  // }
  //var finalOee = 0

  // for (var i = 0; i < qualityArray.length; i++) {
  //   this.finalQuality = this.finalQuality + qualityArray[i];
  // }
  // for (var i = 0; i < performanceArray.length; i++) {
  //   this.finalPerformance = this.finalPerformance + performanceArray[i];
  // }
  // for (var i = 0; i < availabiltyArray.length; i++) {
  //   this.finalAvailability = this.finalAvailability + availabiltyArray[i];
  // }

  // this.finalQuality = this.finalQuality / qualityArray.length;
  // this.finalPerformance = this.finalPerformance / performanceArray.length;
  // this.finalAvailability = this.finalAvailability / availabiltyArray.length;

  calculateTimestamp() {

  }

  changeColor(data) {
    // console.log(data.readings[0].MACHINE_STATUS['MACHINE_STATUS'])
    if (data['actualState'] === "Running") {
      return '#77AB4B';
    }
    else
      if (data['actualState'] === "No_plan") {
        return '#88ADEE';
      }
      else
        if (data['actualState'] === "Down") {
          return '#F55522';
        }
        else
          if (data['actualState'] === "Tool_change") {
            return '#E87F2F';
          }
          // else
          //   if (data['actualState'] === "Color_change") {
          //     return '#D69595';
          //   }
          else
            if (data['actualState'] === "Trial") {
              return '#A0A0A0';
            }
            else
              if (data['actualState'] === "Preventive") {
                return '#A2814B';
              }

  }

  calculateSummary() {
    this.temp = new Map();
    this.data.map((ele) => {
      if (this.temp.has(ele['actualState'])) {
        let count = this.temp.get(ele['actualState'])
        count++;
        this.temp.set(ele['actualState'], count);
      } else {
        this.temp.set(ele['actualState'], 1);
      }
    });

    this.machineStatus.map((stat) => {
      stat.count = this.temp.get(stat.status) === undefined ? 0 : this.temp.get(stat.status);
    })
  }

  navigateToOperator(data) {
    let id = data.id
    console.log("data is:", id)
    //this.router.navigate([`cadminhome/machine/cncoperator/`]);
    this.router.navigate([`operator-dashboard/${id}`]);
  }

  ngOnDestroy() {
    //   this.machineStatSubscription.unsubscribe();
    //   this.oeeStatusSubscription.unsubscribe();
    //   this.productStatusSubscription.unsubscribe();
    if (this.productStatusSubscription) {
      clearInterval(this.productStatusSubscription);
    }
    if (this.machineStatSubscription) {
      clearInterval(this.machineStatSubscription)
    }
    if (this.oeeStatusSubscription) {
      clearInterval(this.oeeStatusSubscription)
    }
  }
}


