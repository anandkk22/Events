import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ProductionLiveService {

  constructor(private _http: HttpClient) { }


  public getDeviceIdList() {
    return this._http.get(environment.CNC_API_URL + "api/praedge/device-list");
  }
  public getMachineData() {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-production-schedule/current-time/running-status');
  }

  public getMaintenanceData() {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-maintainence-schedule/current-time/undergoing-status');
  }

  public getToolScheduleData() {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-tool-schedule/current-time/running-status');
  }

  public getEquipmentDowntime() {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-equipment-downtime/current-time/started-status');
  }
  // public getMachineStatus(data: any) {
  //   console.log("machine statuses")
  //   console.log(data)
  //   //return this._http.get("assets/json/machineStatus-data.json");
  //   //return this._http.get(environment.CNC_API_URL + 'api/praedge/data-acquisition/machine-status', data);
  //   return this._http.post(environment.CNC_API_URL + 'api/praedge/data-acquisition', data);

  // }
  // public getOEE(data: any) {
  //   //return this._http.get("assets/json/OEEStatus-data.json");
  //   return this._http.post(environment.CNC_API_URL + 'api/praedge/data-acquisition', data);

  // }
  // public getProduct(data: any) {
  //   //return this._http.get("assets/json/productStatus-data.json");
  //   return this._http.post(environment.CNC_API_URL + 'api/praedge/data-acquisition', data);
  // }

}
