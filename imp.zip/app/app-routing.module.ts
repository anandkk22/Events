import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { PlantsComponent } from "./plants/plants.component";
import { CategoriesComponent } from "./categories/categories.component";
import { RemoteMonitoringDashboardComponent } from "./remote-monitoring-dashboard/remote-monitoring-dashboard.component";
import { PlantDetailsComponent } from "./plants/plant-details/plant-details.component";
import { EquipmentComponent } from "./equipment/equipment.component";
import { IdeComponent } from "./equipment/ide/ide.component";
import { AddPlantComponent } from "./plants/add-plant/add-plant.component";
import { PlantConfigurationComponent } from "./plants/plant-configuration/plant-configuration.component";
import { AreaComponent } from "./plants/plant-configuration/area/area.component";
import { ProcessCellComponent } from "./plants/plant-configuration/process-cell/process-cell.component";
import { BatchAnalysisDashboardComponent } from './batch-analysis-dashboard/batch-analysis-dashboard.component';
import { SidenavComponent } from './shared/sidenav/sidenav.component';
import { ProcessUnitComponent } from './plants/plant-configuration/process-unit/process-unit.component';
import { ReactorComponent } from './plants/plant-configuration/reactors/reactors.component';
import { PumpsComponent } from './plants/plant-configuration/pumps/pumps.component';
import { LibraryComponent } from './library/library.component';
import { EquipmentMeasurementDataComponent } from './library/parameter-tags/equipment-measurement-data/equipment-measurement-data';

import { ProductionLiveDashboardComponent } from './production-live-dashboard/production-live-dashboard.component';
import { PlanningDashboardComponent } from './planning-dashboard/planning-dashboard.component';
import { CncMachineComponent } from './plants/plant-configuration/cnc-machine/cnc-machine.component';
import { OperatorDashboardComponent } from './operator-dashboard/operator-dashboard.component';
import { AgitatorsComponent } from './plants/plant-configuration/agitators/agitators.component';
import { CentrifugesComponent } from './plants/plant-configuration/centrifuges/centrifuges.component';
import { CompressorsComponent } from './plants/plant-configuration/compressors/compressors.component';
import { ReferenceKPIComponent } from './library/parameter-tags/reference_KPI_family/reference-kpi-family';


const routes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  {
    path: "plants",
    component: PlantsComponent,
  },
  {
    path: "edit-plant/:id",
    component: AddPlantComponent,
  },
  {
    path: "category",
    component: CategoriesComponent,
  },

  {
    path: "dashboard",
    component: RemoteMonitoringDashboardComponent,
  },
  {
    path: "batch-analysis",
    component: BatchAnalysisDashboardComponent
  },
  {
    path: "discrete-app",
    component: ProductionLiveDashboardComponent
  },
  {
    path: "operator-dashboard/:id",
    component: OperatorDashboardComponent
  },
  {
    path: "planning-dashboard",
    component: PlanningDashboardComponent
  },
  {
    path: "plant-details/:id",
    component: PlantDetailsComponent,
  },
  {
    path: "equipment",
    component: EquipmentComponent,
  },
  {
    path: "ide",
    component: IdeComponent,
  },
  {
    path: "plantConfig/:id",
    component: PlantConfigurationComponent,
    children: [
      {
        path: "area",
        component: AreaComponent,
      },
      {
        path: "processcell",
        component: ProcessCellComponent,
      },
      {
        path: "processunit",
        component: ProcessUnitComponent,
      },
      {
        path: "reactor",
        component: ReactorComponent,
      },
      {
        path: "pump",
        component: PumpsComponent,
      },
      {
        path: "agitator",
        component: AgitatorsComponent,
      },
      {
        path: "compressor",
        component: CompressorsComponent,
      },
      {
        path: "centrifuge",
        component: CentrifugesComponent,
      },
      {
        path: "cnc-machine",
        component: CncMachineComponent
      }
    ],
  },
  {
    path: "library",
    component: LibraryComponent
  },
  {
    path: "equipment-measurement-data",
    component: EquipmentMeasurementDataComponent
  },
  {
    path: 'kpi-performance-indicator',
    component: ReferenceKPIComponent
  }

];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
