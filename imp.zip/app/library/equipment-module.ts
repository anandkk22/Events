import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CreateEquipmentMeasurementDataDetailComponent } from './parameter-tags/equipment-measurement-data/create-equipment-measurement-data-detail.component';
import { MatDialogModule, MatInputModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule,  } from '@angular/forms';
import { AngularFontAwesomeModule } from "angular-font-awesome";

import { EditEquipmentMeasurementDataComponent } from './parameter-tags/equipment-measurement-data/edit-equipment-measurement-data';
import { DeleteItem } from './parameter-tags/equipment-measurement-data/delete/delete';
import { ViewEquipmentMeasurementDataComponent } from './parameter-tags/equipment-measurement-data/view-equipment-measure-data.component';
import { CreateReferenceKpiFamilyComponent } from './parameter-tags/reference_KPI_family/create/create-reference-kpi-family.component';
import { EditReferenceKpiFamilyComponent } from './parameter-tags/reference_KPI_family/edit/edit-reference-kpi-family.component';



@NgModule({
    imports: [
        RouterModule, 
        MatDialogModule, 
        BrowserModule, 
        FormsModule, 
        AngularFontAwesomeModule, 
        MatInputModule, 
        ReactiveFormsModule
    ],
    declarations: [
        CreateEquipmentMeasurementDataDetailComponent,  
        EditEquipmentMeasurementDataComponent, 
        DeleteItem, 
        ViewEquipmentMeasurementDataComponent,
        CreateReferenceKpiFamilyComponent,
        EditReferenceKpiFamilyComponent
        
    ],
    entryComponents: [
        CreateEquipmentMeasurementDataDetailComponent, 
        EditEquipmentMeasurementDataComponent, 
        DeleteItem, 
        ViewEquipmentMeasurementDataComponent,
        CreateReferenceKpiFamilyComponent,
        EditReferenceKpiFamilyComponent
    ]
})


export class EquipmentModule {

}

