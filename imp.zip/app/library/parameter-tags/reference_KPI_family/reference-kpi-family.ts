import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { ReferenceKPIFamilyService } from './reference-kpi-family.service';
import { referenceFamilyModel } from './referenceFamily.Model';
import { CreateReferenceKpiFamilyComponent } from './create/create-reference-kpi-family.component';
import { EditReferenceKpiFamilyComponent } from './edit/edit-reference-kpi-family.component';

@Component({
    selector: 'reference-kpi',
    templateUrl: './reference-kpi-family.html',
    styleUrls: ['../../library.component.scss', './reference-kpi-family.scss']
})
export class ReferenceKPIComponent implements OnInit {
    referenceKPIFamilyList: referenceFamilyModel[];
    refKpiFamily: referenceFamilyModel;

    constructor(
        private _referenceKPIFamilyService: ReferenceKPIFamilyService,
        private _router: Router,
        private matDialog: MatDialog,
        private _route: ActivatedRoute,

    ) { }

    ngOnInit() {
        this.getReferenceKPIFamilyList();
        this._route.paramMap.subscribe(parameterMap => {
            const id = +parameterMap.get('id');
            // this.getId(id);
        })
    }

    back() {
        this._router.navigate(['/library'])
    }

    getReferenceKPIFamilyList() {
        this._referenceKPIFamilyService.getReferencceKPIFamilyList().subscribe(
            data => this.referenceKPIFamilyList = data
        )
    }

    createNewRefKPIFamily() {
        const matDialog = this.matDialog.open(CreateReferenceKpiFamilyComponent, {
            width: '700px',
            height: '700px',
        });

        matDialog.afterClosed().subscribe(res => {
            this.getReferenceKPIFamilyList();
        })
    }

    edit(id: number, code: string, name: string, levelId: number, natureId: number, categoryId: number) {
        const dialogRef = this.matDialog.open(EditReferenceKpiFamilyComponent, {
            width: '700px',
            height: '700px',
            data: { id: id, code: code, name: name, levelId: levelId, natureId: natureId, categoryId: categoryId}
        });
        dialogRef.afterClosed().subscribe(res => {
            this.getReferenceKPIFamilyList();
        })
    }
}