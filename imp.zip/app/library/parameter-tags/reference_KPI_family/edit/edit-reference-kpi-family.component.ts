import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { referenceFamilyModel, NatureModel, LevelModel, CategoryModel } from '../referenceFamily.Model';
import { ReferenceKPIFamilyService } from '../reference-kpi-family.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'edit-reference-kpi-family.component',
    templateUrl: './edit-reference-kpi-family.component.html'
})

export class EditReferenceKpiFamilyComponent implements OnInit {
    refkpiTypes: referenceFamilyModel[];
    refkpiType: referenceFamilyModel;
    levels: LevelModel[];
    natures: NatureModel[];
    categories: CategoryModel[];
    isActive: boolean = false;

    constructor(private _mdr: MatDialogRef<EditReferenceKpiFamilyComponent>,
        private _referenceKPIFamilyService: ReferenceKPIFamilyService,
        private matDialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any) {
    }

    CloseDialog() {
        this._mdr.close(false)
    }

    ngOnInit() {
        this.levels = [{ code: 1, name: 'Plant' }];
        this.natures = [{ code: 1, name: 'Predicted' }];
        this.categories = [{ code: 1, name: 'Performance' }];
    }

    getReferencceKPIFamilyList() {
        this._referenceKPIFamilyService.getReferencceKPIFamilyList().subscribe(
            data => this.refkpiTypes = data
        )
    }

    formControl = new FormControl('', [
        Validators.required
    ]);

    update() {
        this._referenceKPIFamilyService.updateRefKpiFamily(this.data).subscribe(
            () => {
                console.log('updated')
            }
        )
        this._mdr.close(false);
    }
}