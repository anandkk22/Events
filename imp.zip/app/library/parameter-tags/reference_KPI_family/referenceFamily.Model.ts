export class referenceFamilyModel {
    id: number;
    code: string;
    name: string;
    levelId: number;
    level: string;
    nature: string;
    natureId: number;
    category: string;
    categoryId: number;
    isActive: boolean;
}

export class LevelModel {
    code: number;
    name: string;
}

export class NatureModel {
    code: number;
    name: string;
}

export class CategoryModel {
    code: number;
    name: string;
}