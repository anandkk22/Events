import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { EquipmentMesurementDataService } from './equipment-measurement-data.service';
import { EquipmentTypeModel, DataTypeModel, BaseUnitModel, NatureEnumModel, EquipmentMeasureModel } from './library.model';

@Component({
    selector: 'create-equipment-measurement-data-detail.component',
    templateUrl: './create-equipment-measurement-data-detail.component.html'
})

export class CreateEquipmentMeasurementDataDetailComponent implements OnInit {

    equipmentType: EquipmentTypeModel[] = [];
    dataTypes: DataTypeModel[] = [];
    baseUnits: BaseUnitModel[] = [];
    natureEnums: NatureEnumModel[] = [];
    equipmentMesureData: EquipmentMeasureModel;
    constructor(private _mdr: MatDialogRef<CreateEquipmentMeasurementDataDetailComponent>,
        private _equipmentMesurementDataService: EquipmentMesurementDataService, 
        private matDialog: MatDialog) {
    }

    CloseDialog() {
        this._mdr.close(false)
    }

    ngOnInit() {
        this.getEquipmentType();
        this.getDataType();
        this.getBaseUnit();
        this.getNatureEnums();
    }

    getEquipmentType() {
        this._equipmentMesurementDataService.getEquipmentType().subscribe(
            data => this.equipmentType = data
        )
    }

    getDataType() {
        this._equipmentMesurementDataService.getDataType().subscribe(
            data => this.dataTypes = data
        )
    }

    getBaseUnit() {
        this._equipmentMesurementDataService.getBaseUnit().subscribe(
            data => this.baseUnits = data,
        )
    }

    getNatureEnums() {
        this._equipmentMesurementDataService.getNatureEnum().subscribe(
            data => this.natureEnums = data,
        )
    }

    save(formData) {
        this._equipmentMesurementDataService.createNewEquiMeasureData(formData.value).subscribe(
            (data: EquipmentMeasureModel) => {
                console.log(data)
            },
            (error: any) => console.log(error)
        )
        this._mdr.close(false);    
    }
}