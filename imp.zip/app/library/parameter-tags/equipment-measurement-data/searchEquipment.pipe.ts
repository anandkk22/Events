import { Pipe, PipeTransform } from '@angular/core';
import { EquipmentMeasureModel } from './library.model';


@Pipe({ name: 'searchByMeasureParam' })
export class searchByEquipmentMeasure implements PipeTransform {
  transform(items: EquipmentMeasureModel[], searchTerm: string): EquipmentMeasureModel[] {
 
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.measureParam.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}


@Pipe({ name: 'OrderEquipmentMeasure' })
export class OrderEquipmentMeasure implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}
