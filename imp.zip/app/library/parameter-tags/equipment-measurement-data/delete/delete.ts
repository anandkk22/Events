import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { Component } from '@angular/core';

@Component({
    selector: 'app-delete-item',
    templateUrl: './delete.html',
    styleUrls: ['./delete.scss']
    
})
export class DeleteItem {
    constructor(public dialogRef: MatDialogRef<DeleteItem>) { }

    onNoClick(): void {
        this.dialogRef.close();
    }
}