import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { EquipmentMesurementDataService } from './equipment-measurement-data.service';
import { EquipmentMeasureModel, EquipmentTypeModel, DataTypeModel, BaseUnitModel, NatureEnumModel } from './library.model';
import { FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'edit-equipment-measurement',
    templateUrl: './edit-equipment-measurement-data.html',
    styleUrls: ['../../library.component.scss', './equipment-measurement-data.scss']
})
export class EditEquipmentMeasurementDataComponent implements OnInit {
    equipmentType: EquipmentTypeModel[] = [];
    equipmentMeasData: EquipmentMeasureModel;
    dataTypes: DataTypeModel[] = [];
    baseUnits: BaseUnitModel[] = [];
    natureEnums: NatureEnumModel[] = [];
    equipmentTypes: string;
    
    constructor(private _mdr: MatDialogRef<EditEquipmentMeasurementDataComponent>,
        private _equipmentMesurementDataService: EquipmentMesurementDataService,
        private matDialog: MatDialog, 
        @Inject(MAT_DIALOG_DATA) public data: any) { 
            this.equipmentTypes = data.equipmentTypes
        }

    ngOnInit() {
        this.getEquipmentType();
        this.getDataType();
        this.getBaseUnit();
        this.getNatureEnums();
    }

    CloseDialog() {
        this._mdr.close(false)
    }


    getEquipmentType() {
        this._equipmentMesurementDataService.getEquipmentType().subscribe(
            data => this.equipmentType = data
        )
    }

    getDataType() {
        this._equipmentMesurementDataService.getDataType().subscribe(
            data => this.dataTypes = data
        )
    }

    getBaseUnit() {
        this._equipmentMesurementDataService.getBaseUnit().subscribe(
            data => this.baseUnits = data,
        )
    }

    getNatureEnums() {
        this._equipmentMesurementDataService.getNatureEnum().subscribe(
            data => this.natureEnums = data,
        )
    }

    formControl = new FormControl('', [
        Validators.required        
      ]);    

    update(){
        this._equipmentMesurementDataService.updateNewEquiMeasureData(this.data).subscribe(
            () => {
                console.log('updated')
            }
        )
        this._mdr.close(false); 
    }   
}