import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { EquipmentMesurementDataService } from './equipment-measurement-data.service';
import { EquipmentMeasureModel, EquipmentTypeModel, DataTypeModel, BaseUnitModel, NatureEnumModel } from './library.model';
import { FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'view-equipment-measurement',
    templateUrl: './view-equipment-measurement-data.html',
    styleUrls: ['../../library.component.scss', './equipment-measurement-data.scss']
})
export class ViewEquipmentMeasurementDataComponent implements OnInit {

    equipmentType: EquipmentTypeModel[] = [];
    equipmentMeasData: EquipmentMeasureModel;
    dataTypes: DataTypeModel[] = [];
    baseUnits: BaseUnitModel[] = [];
    natureEnums: NatureEnumModel[] = [];
    private _id: number;   
    equipmentTypes: string;
    
    constructor(private _mdr: MatDialogRef<ViewEquipmentMeasurementDataComponent>,
        private _router: Router,       
        private _equipmentMesurementDataService: EquipmentMesurementDataService,
        private matDialog: MatDialog, private _route: ActivatedRoute,
        @Inject(MAT_DIALOG_DATA) public data: any) { 
            this.equipmentTypes = data.equipmentTypes
        }


    ngOnInit() {
        this.getEquipmentType();
        this.getDataType();
        this.getBaseUnit();
        this.getNatureEnums();
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._equipmentMesurementDataService.getEquipmentMeasureById(this._id).subscribe(
                data => {
                    this.equipmentMeasData = data
                }
            )
        })
    }

    CloseDialog() {
        this._mdr.close(false)
    }

    getEquipmentType() {
        this._equipmentMesurementDataService.getEquipmentType().subscribe(
            data => this.equipmentType = data
        )
    }

    getDataType() {
        this._equipmentMesurementDataService.getDataType().subscribe(
            data => this.dataTypes = data
        )
    }

    getBaseUnit() {
        this._equipmentMesurementDataService.getBaseUnit().subscribe(
            data => this.baseUnits = data,
        )
    }

    getNatureEnums() {
        this._equipmentMesurementDataService.getNatureEnum().subscribe(
            data => this.natureEnums = data,
        )
    }

    formControl = new FormControl('', [
        Validators.required        
      ]);    

   
}