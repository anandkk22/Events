export class IndustryType {
    code: number;
    name: string;   
}

export class IndustrySegment {
    code: number;
    name: string;
    industryTypeCode: number;
}