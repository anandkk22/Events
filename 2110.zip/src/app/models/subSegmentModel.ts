export class subSegmentModel {
    code: number;
    name: string;
    desc: string;
    successful: boolean;
}