export class customerType {
    code: number;
    name: string;
    desc: string;
    successful: boolean;
}