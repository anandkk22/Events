export interface BaseEntity {
    // using type any to avoid methods complaining of invalid type
    id?: any;
}

export const enum PlantTypeEnum {
    'UTILITY',
    'DISTRIBUTED'
}

export const enum MountTechnologyEnum {
    'FIXED_TILT',
    'SEASONAL_TILT',
    'SINGLE_AXIS_TRACKER',
    'DUAL_AXIS_TRACKER',
    'HYBRID'
}

export class PidiliteUtilityPlant implements BaseEntity {
    constructor(
        public id?: number,
        public externalId?: string,
        public displayName?: any,
        public ownerName?: string,
        public type?: string,
        public localScadaMake?: string,
        public localScadaModel?: string,
        public cloudScadaMake?: string,
        public cloudScadaModel?: string,
        public latitude?: number,
        public latitudeUnit?: string,
        public longitude?: number,
        public longitudeUnit?: string,
        public altitude?: number,
        public altitudeUnit?: string,
        public dcCapacityNamePlate?: number,
        public dcCapacityNamePlateUnit?: string,
        public acCapacityNamePlate?: number,
        public acCapacityNamePlateUnit?: string,
        public dcCapacityActual?: number,
        public dcCapacityActualUnit?: string,
        public acCapacityActual?: number,
        public acCapacityActualUnit?: string,
        public dcCapacityDesign?: number,
        public dcCapacityDesignUnit?: string,
        public acCapacityDesign?: number,
        public acCapacityDesignUnit?: string,
        public commissionDate?: any,
        public scadaCommissionDate?: any,
        public locality?: string,
        public village?: string,
        public city?: string,
        public state?: string,
        public country?: string,
        public pincode?: string,
        public timeZoneWrtUtc?: string,
        public activeInd?: boolean,
        public currency?: string,
        public policy?: string,
        public assets?: any,
        public selectedInstanceType?: string,
        public plantKpiValue?: string,

    ) {
        this.activeInd = false;
    }
}