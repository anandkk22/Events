export class subSiteTypeModel {
    code: number;
    name: string;
    desc: string;
    successful: boolean;
}