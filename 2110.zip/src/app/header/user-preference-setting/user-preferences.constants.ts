export const landing = [
    'Home',
    'Remote Mornitoring Dashboard',
    'Plant',
    'CBM'
];


export const dateIndicators = [
    // 1 is difference of days between today and yesterday
    {
        label: 'Today',
        code: '0'
    },
    {
        label: 'Yesterday',
        code: '1'
    }
];


export const dateFormat = ['YYYY-MM-DD', 'DD/MM/YYYY', 'YYYY/MM/DD', 'MM/DD/YYYY'];

export const timeFormat = ['HH24', 'AM-PM'];

export const language = ['English'];

export const notification = ['true', 'false'];

export const notifMessage = ['true', 'false'];

export const notifSound = ['true', 'false'];

export const landingPageNavigationsList = [
    {
        page: 'Home',
        url: '',
        permissionCode: ''
    },
    {
        page: 'Remote Operations Center',
        url: 'portfolio-base/roc-base/remote-monitoring',
        permissionCode: 'ROC_R'
    },
    {
        page: 'Event Management',
        url: 'portfolio-base/events',
        permissionCode: 'EVENT_MGMT_R'
    },
    {
        page: 'Performance Management',
        url: 'portfolio-base/performance',
        permissionCode: 'PERFORMANCE_MGMT_R'
    },
    {
        page: 'Health Management',
        url: 'portfolio-base/health',
        permissionCode: 'HEALTH_MGMT_R'
    },
    {
        page: 'Action Items',
        url: 'portfolio-base/action-items',
        permissionCode: ['ACTION_ITEMS_R', 'ACTION_ITEMS_W']
    }
];
