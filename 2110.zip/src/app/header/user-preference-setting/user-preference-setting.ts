import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { Router } from '@angular/router';
import * as preferencesConstants from './user-preferences.constants';
import * as dateFilterConst from './datefilter-constants';
import { UserPreferences } from './user-preferences.model';
import { UserPreferenceService } from './user-preference-service';

@Component({
  selector: 'app-header-user-setting-component',
  templateUrl: './user-preference-setting.html',
  styleUrls: ['./user-preference-setting.scss']
})
export class UserPreferenceSetting implements OnInit {
  userPreferences: UserPreferences;
  landingPageList: any;
  dateFormat: any;
  timeFormat: any;
  dateIndicators: any;
  language: any;
  notification: any;
  notifmsg: any;
  notifsound: any;
  account: Account;
  dateFilterConst = dateFilterConst;

  constructor(private _mdr: MatDialogRef<UserPreferenceSetting>, private router: Router, private _userPreferenceService: UserPreferenceService) {
    (this.landingPageList = preferencesConstants.landing),
      (this.dateFormat = preferencesConstants.dateFormat),
      (this.language = preferencesConstants.language),
      (this.timeFormat = preferencesConstants.timeFormat),
      (this.dateIndicators = preferencesConstants.dateIndicators);

  }
  ngOnInit() {
    this.userPreferences = this._userPreferenceService.getDefaultUserPreferences();
    this.getNotificationsValues();
  }
  CloseDialog() {
    this._mdr.close(false)
  }

  logout() {
    this.CloseDialog();
    this.router.navigate(['login']);
  }


  getNotificationsValues() {
    if (this.userPreferences.preferences.notification[0] === 'false') {
      this.notification = false;
      this.notifsound = false;
      this.notifmsg = false;
    } else if (
      this.userPreferences.preferences.notifSound[0] === 'true' &&
      this.userPreferences.preferences.notifMessage[0] === 'true'
    ) {
      this.notification = true;
      this.notifsound = true;
      this.notifmsg = true;
    } else if (
      this.userPreferences.preferences.notifSound[0] === 'true' &&
      this.userPreferences.preferences.notifMessage[0] === 'false'
    ) {
      this.notification = true;
      this.notifsound = true;
      this.notifmsg = false;
    } else if (
      this.userPreferences.preferences.notifSound[0] === 'false' &&
      this.userPreferences.preferences.notifMessage[0] === 'true'
    ) {
      this.notification = true;
      this.notifsound = false;
      this.notifmsg = true;
    } else {
      this.notification = false;
      this.notifsound = false;
      this.notifmsg = false;
    }
  }

  setNotificationsValues() {
    if (!this.notification) {
      this.userPreferences.preferences.notification[0] = 'false';
      this.userPreferences.preferences.notifSound[0] = 'false';
      this.userPreferences.preferences.notifMessage[0] = 'false';
    } else if (this.notifmsg && this.notifsound) {
      this.userPreferences.preferences.notification[0] = 'true';
      this.userPreferences.preferences.notifMessage[0] = 'true';
      this.userPreferences.preferences.notifSound[0] = 'true';
    } else if (this.notifsound && !this.notifmsg) {
      this.userPreferences.preferences.notification[0] = 'true';
      this.userPreferences.preferences.notifSound[0] = 'true';
      this.userPreferences.preferences.notifMessage[0] = 'false';
    } else if (!this.notifsound && this.notifmsg) {
      this.userPreferences.preferences.notification[0] = 'true';
      this.userPreferences.preferences.notifSound[0] = 'false';
      this.userPreferences.preferences.notifMessage[0] = 'true';
    } else {
      this.userPreferences.preferences.notifSound[0] = 'false';
      this.userPreferences.preferences.notification[0] = 'false';
      this.userPreferences.preferences.notifMessage[0] = 'false';
    }
  }

  onClickSave(): void {
    this.setNotificationsValues();
  }
}
