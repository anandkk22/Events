
import { Component, OnInit, ElementRef, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { Router } from '@angular/router';
import { LoginService } from 'src/app/core/login/login.service';

@Component({
    selector: 'reset-password',
    templateUrl: 'reset-password.html',
    styleUrls: ['reset-password.scss']
})
export class ResetPasswordComponent implements OnDestroy {
    oldPassword = '';
    newPassword = '';
    rNewPassword = '';
    passChangeSuccess = false;
    changePasswordSuccess = false;
    changePasswordError = false;

    constructor(
        public dialog: MatDialog,
        public dialogRef: MatDialogRef<ResetPasswordComponent>,
        private router: Router,
        private service: LoginService
    ) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

    changePassword(): void {
        this.service
            .changePassword({
                currentPassword: this.oldPassword,
                newPassword: this.newPassword
            })
            .subscribe(
                success => {
                    this.changePasswordSuccess = true;
                    this.changePasswordError = false;
                    this.oldPassword = '';
                    this.newPassword = '';
                    this.rNewPassword = '';
                },
                error => {
                    this.changePasswordSuccess = false;
                    this.changePasswordError = true;
                    this.oldPassword = '';
                    this.newPassword = '';
                    this.rNewPassword = '';
                }
            );
    }

    ngOnDestroy() {
        this.dialogRef.close();
    }
}