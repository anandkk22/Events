import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserProfile } from './user-profile/user-profile';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { Router } from '@angular/router';
import { UserPreferenceSetting } from './user-preference-setting/user-preference-setting';
import { UserManagementService } from '../user-management/user-management.service';
import { LoginService } from '../core/login/login.service';
import { OrganizationManagementService } from '../user-management/organization-management/organization-management.service';
import { ResetPasswordComponent } from './reset-password/reset-password';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  middleHeaderText: string = '';
  plantTitle: string = '';
  equipmentTitle: string = '';
  productionLiveTitle: string = '';
  planningTitle: string = '';
  operatorTitle: string = ''
  dashboradTitle: string = '';
  batchanalysisTitle: string = '';
  libraryTitle: string = '';
  plantEventTitle: string = '';
  getDateandTime: Date;
  todaysdate = new Date();
  dateFormat = 'dd.MMM.yyyy HH:mm'
  matDialogRef: MatDialogRef<UserProfile>;
  matDialogRefuserSettings: MatDialogRef<UserPreferenceSetting>;
  accessMenus: any[] = [];
  isNavbarCollapsed: boolean = false;
  energyTitle: String = '';
  user: any;
  login: any;
  imageNotFound: boolean = true;
  userProfile: any;
  userId: any;
  organization: any = {};

  constructor(private matDialog: MatDialog, private router: Router, public dialog: MatDialog,
    private userService: UserManagementService,
    private service: LoginService,
    private orgService: OrganizationManagementService

  ) { }

  openUserProfile(): void {
    this.matDialogRef = this.matDialog.open(UserProfile, {
      panelClass: ['dark-theme-dialog-container-large-dialog-left'],
    });
  }

  openUserProfileSetting(): void {
    this.matDialogRefuserSettings = this.matDialog.open(UserPreferenceSetting, {
      panelClass: ['dark-theme-dialog-container-large-dialog-left'],
    });
  }


  ngOnInit() {
    this.organization = {};
    this.getWishes();
    this.plantTitle = 'Plant Configuration';
    this.equipmentTitle = 'Condition Monotoring';
    this.dashboradTitle = 'Digital Command Center';
    this.batchanalysisTitle = 'Batch Analysis';
    this.libraryTitle = 'Library Configuration';
    this.productionLiveTitle = 'Production Live Dashboard';
    this.planningTitle = 'Planning Dashboard';
    this.operatorTitle = 'Operator Dashboard';
    this.energyTitle = 'Energy Dashboard';
    this.plantEventTitle = 'Events';
    this.accessMenus = [
      { iconText: 'User Management', link: 'user-management' },
      { iconText: 'Role Management', link: 'role-management' },
      { iconText: 'Permission Management', link: 'permission-management' }
    ]

    this.login = localStorage.getItem('login');

    this.userService.getUserById(this.login).subscribe((resp) => {
      this.user = resp;
      console.log("useeee", this.user);

    });
    this.userId = localStorage.getItem('userId');
    this.service.getUserProfileByUserId(this.userId).subscribe((resp) => {
      this.userProfile = resp;
      console.log("profillee", this.userProfile);
      if (this.userProfile != null) {
        this.orgService.getOrganizationById(this.userProfile.organisationId).subscribe((resp) => {
          this.organization = resp;
          console.log("profillee22", this.organization);

          if (this.organization.organizationImageContentType != null) {
            console.log("logooo", this.organization.organizationImageContentType);
          }
        },
          (error) => {
            console.log("eroor", error);

          });
      }
    },
      (error) => {
        console.log("error", error);
      });


  }

  home() {
    this.router.navigate(['category']);
  }
  dashboard() {
    this.router.navigate(['dashboard']);
  }
  batchAnalysis() {
    this.router.navigate(['batch-analysis']);
  }

  productionLive() {
    this.router.navigate(['discrete-app']);
  }

  energy() {
    this.router.navigate(['energy']);
  }

  planningDashboard() {
    this.router.navigate(['planning-dashboard']);
  }

  events() {
    this.router.navigate(['plant-events']);
  }
  getWishes() {
    let today = new Date()
    let curHr = today.getHours()

    if (curHr < 12) {
      this.middleHeaderText = 'Good Morning';
    } else if (curHr < 18) {
      this.middleHeaderText = 'Good Afternoon';
    } else {
      this.middleHeaderText = 'Good Evening';
    }
  }

  menuClick(link) {
    this.router.navigate([link]);
  }

  collapseNavbar() {
    this.isNavbarCollapsed = !this.isNavbarCollapsed;
    console.log(this.isNavbarCollapsed)
  }
}
