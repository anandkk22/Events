import { Component, OnInit, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { Router } from '@angular/router';
import { AuthenticationService, JhiDataUtils } from 'src/app/core';
import { LocalStorageService } from 'ngx-webstorage';
import { LoginService } from 'src/app/core/login/login.service';
import { UserManagementService } from 'src/app/user-management/user-management.service';
import { UserPreferenceService } from '../user-preference-setting/user-preference-service';
import { UserProfileService } from 'src/app/user-management/user-profile/user-profile.service';
import { ResetPasswordComponent } from '../reset-password/reset-password';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.html',
  styleUrls: ['./user-profile.scss']
})
export class UserProfile implements OnInit {

  profilePhoto: any;
  userProfile: any;
  userId: any;
  user: any = {};
  login: any;
  imageNotFound: boolean = true;
  isEdit: boolean = false;
  matDialogRefRzesetPassword: MatDialogRef<ResetPasswordComponent>;

  constructor(private _mdr: MatDialogRef<UserProfile>, private router: Router,
    private authenticationService: AuthenticationService,
    private localStorageService: LocalStorageService,
    private service: LoginService,
    private userService: UserManagementService,
    protected dataUtils: JhiDataUtils,
    protected elementRef: ElementRef,
    private profileService: UserProfileService,
    public dialog: MatDialog
  ) {

  }
  ngOnInit() {
    this.userId = localStorage.getItem('userId');
    this.service.getUserProfileByUserId(this.userId).subscribe((resp) => {
      this.userProfile = resp;
      console.log("profillee", this.userProfile);
    });

    this.login = localStorage.getItem('login');

    this.userService.getUserById(this.login).subscribe((resp) => {
      this.user = resp;
      console.log("useeee", this.user);

    });
  }

  openResetPassword(): void {
    this.matDialogRefRzesetPassword = this.dialog.open(ResetPasswordComponent, {
      panelClass: ['dark-theme-dialog-container-large-dialog-left'],
    });

    this.matDialogRefRzesetPassword.afterClosed().subscribe(result => {

    });
  }

  CloseDialog() {
    this._mdr.close(false)
  }

  logout() {
    this.CloseDialog();
    // this.router.navigate(['login']);
    this.authenticationService.logout().subscribe(() => this.router.navigate(['login'], { replaceUrl: true }));
    this.localStorageService.clear();
  }

  editImage() {
    console.log("edddit");
    this.isEdit = true;
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  setFileData(event, field: string, isImage) {
    return new Promise((resolve, reject) => {
      if (event && event.target && event.target.files && event.target.files[0]) {
        const file: File = event.target.files[0];
        if (isImage && !file.type.startsWith('image/')) {
          reject(`File was expected to be an image but was found to be ${file.type}`);
        } else {
          const filedContentType: string = field + 'ContentType';
          this.dataUtils.toBase64(file, base64Data => {

            this.userProfile.userImage = base64Data;
            this.userProfile.userImageContentType = file.type;

          });
        }
      } else {
        reject(`Base64 data was not set as file could not be extracted from passed parameter: ${event}`);
      }
    }).then(
      // eslint-disable-next-line no-console
      () => console.log('blob added'), // success
    );
  }

  clearInputImage(field: string, fieldContentType: string, idInput: string) {
    this.userProfile.userImage = null;
    this.userProfile.userImageContentType = null;

    if (this.elementRef && idInput && this.elementRef.nativeElement.querySelector('#' + idInput)) {
      this.elementRef.nativeElement.querySelector('#' + idInput).value = null;
    }
  }

  save() {
    console.log("gggggg", this.userProfile);
    this.profileService.createNewUserProfile(this.userProfile).subscribe((resp) => {
      this.user = resp;
      console.log("useeee", this.user);
    });
  }

  close() {
    this.isEdit = false;
  }
}
