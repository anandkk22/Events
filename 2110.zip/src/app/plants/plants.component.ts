import { Component, OnInit, OnDestroy } from '@angular/core';

import { PidilitePlantsService } from './pidilite-plants.service';
import { Router } from '@angular/router';
import { searchByPlantName } from './searchandFilter.pipe';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from './delete-plant/delete-plant';
import { pidiliteMainModel } from '../models/pidilite-model';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { IndustryType, IndustrySegment } from '../models/industry.model';
import { LoginService } from '../core/login/login.service';

@Component({
  selector: 'app-plants',
  templateUrl: './plants.component.html',
  styleUrls: ['./plants.component.scss', './plant-configuration/plant-configuration.component.scss']
})
export class PlantsComponent implements OnInit, OnDestroy {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  searchText: string = null;
  listofAllPlantsRaw: pidiliteMainModel[];
  listofAllPlants = [];
  plant: pidiliteMainModel;
  matDialogRef: MatDialogRef<DeletePlant>;
  $localPlantId: any;
  industryType: IndustryType[];
  indstrySegment: IndustrySegment[];
  userProfile: any;
  userId: any;

  constructor(private _plantService: PidilitePlantsService,
    private _router: Router,
    public dialog: MatDialog,
    private snackBar: MatSnackBar,
    private _loginService: LoginService) { }

  ngOnInit() {
    this.userId = localStorage.getItem('userId');
    this.loadAll();
    this._loginService.getUserProfileByUserId(this.userId).subscribe(
      (resp) => {this.userProfile = resp;
        // console.log("profillee", this.userProfile)
      }
    )
  }

  loadAll() {
    this.getIndustryTypeList();
  }
  
  getPlantDetails(plantId: number) {
    this.$localPlantId = localStorage.setItem('plantId',JSON.stringify(plantId));
    this._router.navigate(['/plant-details', plantId]);    
  }

  getIndustryTypeList() {
    this._plantService.getListofIndustryType().subscribe(
      data => {
        this.industryType = data;
        this.getIndustrySegmentList();
      }
    );
  }

  getIndustrySegmentList() {
    this._plantService.getListofIndustrySegment().subscribe(
      data => {
        this.indstrySegment = data;
        this.getListofPlant();
      }
    );
  }

  getListofPlant() {

    this._plantService.getListofPlant().subscribe(
      res => {
        this.listofAllPlantsRaw = res;
        this.setSinglePlantDetails();
      }
    );
  }

  setSinglePlantDetails() {
    this.listofAllPlantsRaw.forEach(plant => {
      let singlePlantDetails = {
        id: null,
        name: null,
        orgName: null,
        description: null,
        capacity: null,
        capacity_unit: null,
        timezone: null,
        industry: null,
        industrySegment: null
      };

      singlePlantDetails.id = plant.id;
      singlePlantDetails.name = plant.name;
      singlePlantDetails.orgName = plant.orgName;
      singlePlantDetails.description = plant.description;
      singlePlantDetails.capacity = plant.capacity;
      singlePlantDetails.capacity_unit = plant.capacity_unit;
      singlePlantDetails.timezone = plant.timezone;

      this.industryType.forEach(indType => {
        if(Number(indType.code) === Number(plant.industry)) {
          singlePlantDetails.industry = indType.name;
        }
      });

      this.indstrySegment.forEach(indSeg => {
        if(Number(indSeg.code) === Number(plant.industrySegment)) {
          singlePlantDetails.industrySegment = indSeg.name;
        }
      });

      this.listofAllPlants.push(singlePlantDetails);
    
    });
  }

  addNewPlant() {
    this._router.navigate(['/add-plant'])
  }

  confirmDelete(id) {    
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._plantService.deletePlant(id).subscribe(      
          () => {console.log(`Plant deleted with id =  ${id} deleted`)},          
          () => this.getListofPlant()          
        )         
      }
    })
   
  }

  showSnackbarMsge() {
    this.snackBar.open('There is related data in the system. Please delete the data before deleting the asset', '', {
      duration: 3000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    }); 
  }

  ngOnDestroy(){
    this.$localPlantId = null;  
  }

}