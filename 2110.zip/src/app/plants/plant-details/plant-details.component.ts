import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PidilitePlantsService } from '../pidilite-plants.service';
import { PidiliteUtilityPlant } from '../../models/Pidilite-Plant.model';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';
import { CustomerTypeModel } from 'src/app/models/customerType.model';
import { segmentModel } from 'src/app/models/segment.model';
import { IndustryType, IndustrySegment } from 'src/app/models/industry.model';


@Component({
  selector: 'app-plant-details',
  templateUrl: './plant-details.component.html',
  styleUrls: ['./plant-details.component.scss']
})
export class PlantDetailsComponent implements OnInit {
  listofShiftandBreaks: any[];
  public customerTypes: CustomerTypeModel[] = [];
  public segments: segmentModel[] = [];
  plant: pidiliteMainModel;
  organization: boolean = false;
  customerType: any;
  orgType: any;
  getAreaDetails: any;
  private _id: number;
  zoom: number = 15;
  constructor(private _plantService: PidilitePlantsService,    
    private _router: Router, 
    private _route: ActivatedRoute
    ) { }
  currId = null;
  industryType: IndustryType[];
  indstrySegment: IndustrySegment[];
  industryName: string;
  industrySegmentName: string;

  ngOnInit() {        
    this.getListofIndustryType();

    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this._plantService.getPlantById(this._id).subscribe(
        data => {
          this.plant = data;
          this.onIndstryTypeSelect(this.plant.industry);
        }
      );


      this._plantService.getPlantAssetDetails(this._id).subscribe(
        data => this.getAreaDetails = data
      );

      this._plantService.getShiftandBreakPlantById(this._id).subscribe(
        data => this.listofShiftandBreaks = data
      );
    });
  }

  getListofIndustryType() {
    this._plantService.getListofIndustryType().subscribe(
      data => this.industryType = data
    );
  }

  onIndstryTypeSelect(industryCode){
    this._plantService.getListofIndustrySegment().subscribe(data => {
      this.indstrySegment = data.filter(item => item.industryTypeCode == industryCode);
      this.getIndustryTitles();
    });
  }

  getIndustryTitles() {
    this.industryType.forEach(indType => {
      if(indType.code === Number(this.plant.industry)) {
        this.industryName = indType.name;
      }
    });

    this.indstrySegment.forEach(indSeg => {
      if(indSeg.code === Number(this.plant.industrySegment)) {
        this.industrySegmentName = indSeg.name;
      }
    });
  }

  open(id) {
    if (id === this.currId) {      
      this.currId = 0;
    } else {
      this.currId = id;
    }
  }

  backtoPlant() {
    this._router.navigate(['./plants'])
  }

  redirectToComponent(plantId: number) {
    this._router.navigate([`/plantConfig/${plantId}/area`]);
    // this._router.navigate([`/plantConfig/${plantId}/area`, {id: this.plant.id}]);
  }

  redirectToComponentToConfig(plantId: number, plantConfigName: string){
    this._router.navigate([`/plantConfig/${plantId}/${plantConfigName.toLocaleLowerCase().split(" ").join("-")}`]);
    // this._router.navigate([`/plantConfig/${plantId}/${plantConfigName.toLocaleLowerCase().split(" ").join("")}/`,{id: this.plant.id}]);    
  }

  editPlant() {
    this._router.navigate(['/edit-plant', this.plant.id]);
  }  

}
