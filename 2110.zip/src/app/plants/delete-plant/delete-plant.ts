import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { Component } from '@angular/core';

@Component({
    selector: 'app-delete-plant',
    templateUrl: 'delete-plant.html',
    styleUrls: ['delete-plant.scss']

})
export class DeletePlant {
    constructor(public dialogRef: MatDialogRef<DeletePlant>) { }

    onNoClick(): void {
        this.dialogRef.close();
    }
}