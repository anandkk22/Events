import { Component, OnInit } from '@angular/core';
import { CompressorsModel } from './compressors.model';
import { CompressorsService } from './compressors.service';
import { MatDialog, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from '../../pidilite-utility-plant.model';
import { CompressoreRelationshipComponent } from './compressor-relationship';

@Component({
    selector: 'app-compressors',
    templateUrl: './compressors.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class CompressorsComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    plantConfigCompressorsDetails: CompressorsModel[];
    compressor: CompressorsModel;
    plantConfigCompressorsDetail = null;
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;
    processUnits: any;
    compressorTypes: any;
    powerSupplyTypes: any = [];
    powerSources: any = [];
    $localCompressorId: any;
    formVisible: boolean = true;

    constructor(private compressorService: CompressorsService, public dialog: MatDialog,
        private _route: ActivatedRoute, private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigCompressorsDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.compressorService.getProcessUnitByPlantId(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("process unit", this.processUnits);
        });

        this.compressorService.getCompressorTypes().subscribe((resp) => {
            this.compressorTypes = resp;
            console.log("pump", this.compressorTypes);
        });

        this.compressorService.getPowerSupplyTypes().subscribe((resp) => {
            this.powerSupplyTypes = resp;
            console.log("pump33", this.powerSupplyTypes);
        });

        this.compressorService.getPowerSource().subscribe((resp) => {
            this.powerSources = resp;
            console.log("pump33", this.powerSources);
        });


        this.loadCompressor();
    }

    loadCompressor() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this.compressorService.getListofCompressors(this.getPlantId).subscribe(
                agitator => {
                    this.plantConfigCompressorsDetails = agitator
                }
            )
        })
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigCompressorsDetails) {
            if (sortFilter === 'id') {
                this.plantConfigCompressorsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigCompressorsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this.compressorService.deleteCompressorById(id).subscribe(
                    () => this.loadCompressor()
                )                
            }
        })
    }

    showRelationship(getCompressorId): void {
        this.$localCompressorId = localStorage.setItem('compressorId', JSON.stringify(getCompressorId));
        const dialogRef = this.dialog.open(CompressoreRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigCompressorsDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigCompressorsDetail = proessCell;
            }
            this.formVisible = true;
        });
    }

    addnew() {
        this.plantConfigCompressorsDetail = {};
        this.formVisible = true;
    }

    isActiveClass(processCell) {
        this.compressorService.isActiveClass(this.plantConfigCompressorsDetails, processCell)
    }

    save() {
        this.plantConfigCompressorsDetail.mfgconnectSiteId = this.getPlantId;
        if (this.plantConfigCompressorsDetail.id == undefined) {
            this.compressorService.createNewCompressor(this.plantConfigCompressorsDetail).subscribe(
                (data: CompressorsModel) => {
                    console.log(data);
                    this.loadCompressor();

                }
            );
            this.formVisible = false;
        }
        else {
            this.compressorService.updateCompressor(this.plantConfigCompressorsDetail).subscribe(
                () => {
                    console.log('updated Pump');
                    this.loadCompressor();
                }
            );
            this.formVisible = false;
        }
    }

    cancel() {
        this.plantConfigCompressorsDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}
