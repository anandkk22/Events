import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CompressorsModel } from './compressors.model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class CompressorsService {
    public listofCompressors: string = environment.PROCESS_API_URL + 'api/compressors/plant';
    public compressorApi: string = environment.PROCESS_API_URL + 'api/compressor';
    public processUnitByPlantId = environment.PROCESS_API_URL + "api/processunit/plant"
    public compressorType = environment.PROCESS_API_URL + "api/getAllCompressorTypes"
    public powerSupplyType = environment.PROCESS_API_URL + "api/powerSupplyType"
    public powerSource = environment.PROCESS_API_URL + "api/powerSource";
    public relationship: string = environment.PROCESS_API_URL + 'api/compressor';

    constructor(private _http: HttpClient) { }

    getListofCompressors(id: number): Observable<CompressorsModel[]> {
        return this._http.get<CompressorsModel[]>(`${this.listofCompressors}/${id}`)
    }

    getCompressorById(id: number): Observable<CompressorsModel> {
        return this._http.get<CompressorsModel>(`${this.compressorApi}/${id}`)
    }

    createNewCompressor(compressor: CompressorsModel): Observable<CompressorsModel> {
        return this._http.post<CompressorsModel>(`${this.compressorApi}`, compressor, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateCompressor(compressor: CompressorsModel): Observable<void> {
        return this._http.put<void>(`${this.compressorApi}`, compressor, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteCompressorById(id) {
        return this._http.delete(`${this.compressorApi}/${id}`, { responseType: 'text' })
        .pipe(catchError(this.handleError))      
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }

    getProcessUnitByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processUnitByPlantId}/${id}`);
    }

    getCompressorTypes(): Observable<any> {
        return this._http.get<any>(`${this.compressorType}`);
    }
    getPowerSupplyTypes(): Observable<any> {
        return this._http.get<any>(`${this.powerSupplyType}`);
    }

    getPowerSource(): Observable<any> {
        return this._http.get<any>(`${this.powerSource}`);
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }
    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }
}
