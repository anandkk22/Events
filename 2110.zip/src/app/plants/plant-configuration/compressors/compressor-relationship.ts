import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { CompressorsService } from './compressors.service';



@Component({
    selector: 'compressor-relationship',
    templateUrl: './compressor-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class CompressoreRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getCompressorId: any;

    constructor(private _mdr: MatDialogRef<CompressoreRelationshipComponent>, 
        private _compressorService: CompressorsService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getCompressorId = localStorage.getItem('compressorId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._compressorService.getRelationship(this.getCompressorId).subscribe(
                compresssor => {
                    this.getRelationship = compresssor
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('compressorId');
    }

}
