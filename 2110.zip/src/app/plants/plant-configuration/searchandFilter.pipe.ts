import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'searchByName' })
export class searchPlantConfigName implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}


@Pipe({ name: 'OrderBy' })
export class OrderByPlantConfigPipe implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'commissionDate') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.commissionDate).getTime() - new Date(b.commissionDate).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}