import { Component, OnInit } from '@angular/core';
import { CncMachineModel } from './cnc-machine.model';
import { DeviceService } from './cnc-machine.service';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { DeletePlant } from '../../delete-plant/delete-plant';

@Component({
  selector: 'app-cnc-machine',
  templateUrl: './cnc-machine.component.html',
  styleUrls: ['./cnc-machine.component.scss']
})
export class CncMachineComponent implements OnInit {

  cncMachineList: CncMachineModel[];
  cncMachineConfig = null;
  cncMachine: CncMachineModel;

  constructor(private cncMachineService: DeviceService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {

    this.cncMachineService.getMachineData().subscribe(cncMachine => {
      console.log("resp is", cncMachine)
      this.cncMachineList = cncMachine
      console.log("cnc machine list is", this.cncMachineList)
    })

  }

  addnew() {
    this.cncMachineConfig = new CncMachineModel();
  }

  details(id) {
    this.cncMachineList.forEach(cncMachineObject => {
      if (cncMachineObject.id === id) {
        this.cncMachineConfig = cncMachineObject;
      }
    });
  }

  cancel() {
    this.cncMachineConfig = null;
  }

  isActiveClass(cncMachine) {
    this.cncMachineService.isActiveClass(this.cncMachineList, cncMachine)
  }

  save() {
    if (this.cncMachineConfig.id == undefined) {
      this.cncMachineService.saveDeviceData(this.cncMachineConfig).subscribe(
        (data: CncMachineModel) => {
          console.log(data);
        }
      )
    }
    else {
      this.cncMachineService.updateDeviceData(this.cncMachineConfig).subscribe(
        () => {
          console.log('updated Procell Cell')
        }
      )
    }
  }

  confirmDelete(id): void {
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.cncMachineService.onDeviceDelete(id).subscribe(
          () => console.log(`Process cell deleted with id =  ${id} deleted`)
        )
      }
    })
  }

}
