import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CncMachineComponent } from './cnc-machine.component';

describe('CncMachineComponent', () => {
  let component: CncMachineComponent;
  let fixture: ComponentFixture<CncMachineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CncMachineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CncMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
