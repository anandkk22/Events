import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { ProcesscellService } from './processCell.service';
import { ActivatedRoute } from '@angular/router';
import { ProcessCellModel } from './processCell.mode';
import { AllTimezoneService } from 'src/app/shared/timezone.service';
import { ProcessCellRelationshipComponent } from './processcell-relationship';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';


@Component({
    selector: 'process-cell',
    templateUrl: './process-cell.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class ProcessCellComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    plantConfigProcessCellDetails: any[];
    processCell: ProcessCellModel;
    plantConfigProcessCellDetail: any = {
        mfgconnectSiteId: ''
    }  
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    getPlantId: any;
    private _id: number;
    hideForm: boolean = true;
    getAreaByPlantIds: any;
    activityTypes: any;
    allTimezone: any;    
    $localProcessCellId: any;
    

    constructor(private _processcellService: ProcesscellService, public dialog: MatDialog, 
        private _route: ActivatedRoute, private _allTimzone: AllTimezoneService,
        private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId');
        this.plantConfigProcessCellDetail.mfgconnectSiteId = this.getPlantId;
        this._processcellService.getProcessCellById(this.getPlantId).subscribe((resp) => {
            // console.log("Process Cell", this.processUnits);
        });
        this.plantConfigProcessCellDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.onLoad();       
        this.getAreaByPlantId();
        this.getActivityType();
        this.getTimezoneCountries();
    }

    getActivityType() {
        this._processcellService.getActivityType().subscribe(
            activityType => {
                this.activityTypes = activityType
            })
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._processcellService.getListofProcessCell(this.getPlantId).subscribe(
                area => {
                    this.plantConfigProcessCellDetails = area
                }
            )
        })
    }

    getTimezoneCountries() {
        this._allTimzone.getTimezoneCountries().subscribe(
            timezone => this.allTimezone = timezone
        );
    }

    getAreaByPlantId() {
        this._processcellService.getAreaByPlantId(this.getPlantId).subscribe(
            areaId => {
                this.getAreaByPlantIds = areaId
            }
        )
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigProcessCellDetails) {
            if (sortFilter === 'id') {
                this.plantConfigProcessCellDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigProcessCellDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id) {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._processcellService.deleteProcessCellById(id).subscribe((resp) => {
                    console.log(`Process cell deleted with id =  ${id} deleted`, resp);
                    () => this.onLoad();
                })                
            }
        })       
    }
    

    showRelationship(getProcessId): void {
        this.$localProcessCellId = localStorage.setItem('processCellId', JSON.stringify(getProcessId));
        const dialogRef = this.dialog.open(ProcessCellRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {        
        this.plantConfigProcessCellDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigProcessCellDetail = proessCell;
            }
            this.hideForm = true;
        });
    }

    addnew() {
        this.plantConfigProcessCellDetail = {};
        this.hideForm = true;
    }

    isActiveClass(processCell) {
        this._processcellService.isActiveClass(this.plantConfigProcessCellDetails, processCell)
    }

    cancel() {
        this.plantConfigProcessCellDetail = null;        
    }

    save() {      
        if (this.plantConfigProcessCellDetail.id == undefined ||  this.plantConfigProcessCellDetail.id == null) {
            this.plantConfigProcessCellDetail.plantId = this.getPlantId;
            console.log("******");
            console.log(this.plantConfigProcessCellDetail);
            this._processcellService.createNewProcessCell(this.plantConfigProcessCellDetail).subscribe((data) => {
                this.onLoad();
            });
            this.hideForm = false;
        }
        else {
            this._processcellService.updateProcessCell(this.plantConfigProcessCellDetail).subscribe(() => {
                this.onLoad();
            });
        }
        this.hideForm = false;
    }

}