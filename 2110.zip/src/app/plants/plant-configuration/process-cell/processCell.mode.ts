export class ProcessCellModel {    
    id?: number;
    name?: string;
    description?: string;
    activity?: string;
    timezone?: any;
    external_id: number;
    areaId?: number;
    lastUpdated?: Date;
}