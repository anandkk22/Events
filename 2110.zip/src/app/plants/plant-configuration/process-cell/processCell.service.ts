import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ProcessCellModel } from './processCell.mode';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ProcesscellService {
    public listofprocessCell: string = environment.PROCESS_API_URL + 'api/processcell/plant'; 
    public getprocessCell: string = environment.PROCESS_API_URL + 'api/processcell'; 
    public addUpdateprocessCell: string = environment.PROCESS_API_URL + 'api/processcell'; 
    public deleteprocessCell: string = environment.PROCESS_API_URL + 'api/processcell'; 
    public listofArea: string = environment.PROCESS_API_URL + 'api/area/plant';
    public activityType: string = environment.PROCESS_API_URL + 'api/activityType';
    public relationship: string = environment.PROCESS_API_URL + 'api/processcell/rel';
    constructor(private _http: HttpClient) { }

    getListofProcessCell(id: number): Observable<ProcessCellModel[]> {
        return this._http.get<ProcessCellModel[]>(`${this.listofprocessCell}/${id}`)
    }

    getProcessCellById(id: number): Observable<ProcessCellModel> {
        return this._http.get<ProcessCellModel>(`${this.getprocessCell}/${id}`)
    }

    createNewProcessCell(processCell: ProcessCellModel): Observable<any> {
        return this._http.post<any>(`${this.addUpdateprocessCell}`, processCell, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateProcessCell(processCell: ProcessCellModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateprocessCell}`, processCell, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }
    

    deleteProcessCellById(id: number) {
        return this._http.delete(this.deleteprocessCell+"/"+ id, {responseType: 'text'})
        .pipe(catchError(this.handleError))
    }
   
    getAreaByPlantId(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.listofArea}/${id}`);
    }

    getActivityType(): Observable<any[]> {
        return this._http.get<any[]>(this.activityType)
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }


    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
        }         
        return throwError(errorMessage);      
    }
}