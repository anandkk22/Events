import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { ActivatedRoute } from '@angular/router';
import { ProcesscellService } from './processCell.service';


@Component({
    selector: 'processCell-relationship',
    templateUrl: './processcell-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class ProcessCellRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getProcessId: any;

    constructor(private _mdr: MatDialogRef<ProcessCellRelationshipComponent>, 
        private _proceessCellService: ProcesscellService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getProcessId = localStorage.getItem('processCellId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._proceessCellService.getRelationship(this.getProcessId).subscribe(
                processCell => {                   
                    this.getRelationship = processCell
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('processCellId');
    }

}
