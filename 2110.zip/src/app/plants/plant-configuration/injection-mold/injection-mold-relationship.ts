import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { InjectionMoldService } from './injection-mold.service';
//import { CompressorsService } from './compressors.service';



@Component({
  selector: 'injection-mold-relationship',
  templateUrl: './injection-mold-relationship.html',
  styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class InjectionMoldRelationshipComponent implements OnInit, OnDestroy {
  private _id: number;
  getPlantId: any;
  getRelationship: any
  injectionMoldId: any;

  constructor(private _mdr: MatDialogRef<InjectionMoldRelationshipComponent>,
    private injectionMoldService: InjectionMoldService, private _route: ActivatedRoute) {

  }

  onNoClick(): void {
    this._mdr.close();
  }

  ngOnInit() {
    this.injectionMoldId = localStorage.getItem('injectionMoldId');
    this.onLoad();
  }

  onLoad() {
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this.injectionMoldService.getRelationship(this.injectionMoldId).subscribe(
        mold => {
          this.getRelationship = mold
        }
      )
    })
  }

  ngOnDestroy() {
    localStorage.removeItem('injectionMoldId');
  }

}
