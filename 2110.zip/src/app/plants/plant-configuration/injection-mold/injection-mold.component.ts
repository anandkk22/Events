import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { MoldMasterService } from 'src/app/product-configurator/mold-master/moldmaster.service';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { ProductionLineService } from '../production-line/production-line.service';
import { InjectionMoldRelationshipComponent } from './injection-mold-relationship';
import { InjectionMoldModel } from './injection-mold.model';
import { InjectionMoldService } from './injection-mold.service';

@Component({
  selector: 'app-injection-mold',
  templateUrl: './injection-mold.component.html',
  styleUrls: ['../plant-configuration.component.scss', './injection-mold.component.scss']
})
export class InjectionMoldComponent implements OnInit {
  tempList: any
  injectionMoldList: InjectionMoldModel[];
  distributedList: InjectionMoldModel[];
  injectionMoldConfig: InjectionMoldModel = {};
  injectionMold: InjectionMoldModel;
  moldMasterList: any = []
  hideForm: boolean = false;
  prodList: any = []
  $localInjectionMoldId: any;
  plantId: any;
  constructor(private injectionMoldService: InjectionMoldService, private moldMasterService: MoldMasterService, private prodLineService: ProductionLineService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.plantId = localStorage.getItem('plantId');
    this.onLoad()

    this.moldMasterService.getListofMoldMaster().subscribe(response => {
      this.moldMasterList = response
    })

    this.prodLineService.getAllProductionLines(this.plantId).subscribe(resp => {
      this.prodList = resp;
      let tList = []
      let temp = []
      let prodDisc = []
      console.log("resp is", resp)
      if (this.prodList instanceof Array) {
        temp = this.prodList
        if (temp instanceof Array) {
          for (let i = 0; i < temp.length; i++) {
            prodDisc = temp[i];
            if (prodDisc.length != 0) {
              for (let j = 0; j < prodDisc.length; j++) {


                tList.push(prodDisc[j]);

              }
            }
          }
        }
      }
      this.prodList = tList
    })

  }

  onLoad() {
    this.injectionMoldService.getAllMolds(this.plantId).subscribe(injectionMold => {
      let tList = []
      console.log("resp is", injectionMold)
      if (injectionMold instanceof Array) {
        this.tempList = injectionMold
        if (this.tempList instanceof Array) {
          for (let i = 0; i < this.tempList.length; i++) {
            this.distributedList = this.tempList[i];
            if (this.distributedList.length != 0) {
              for (let j = 0; j < this.distributedList.length; j++) {


                tList.push(this.distributedList[j]);

              }
            }
          }
        }
      }
      this.injectionMoldList = tList
      console.log("cnc machine list is", this.injectionMoldList)
    })
  }

  addnew() {
    this.injectionMoldConfig = new InjectionMoldModel();
    this.hideForm = true
  }

  showRelationship(injectionMoldId): void {
    this.$localInjectionMoldId = localStorage.setItem('injectionMoldId', JSON.stringify(injectionMoldId));
    const dialogRef = this.dialog.open(InjectionMoldRelationshipComponent, {
      width: '450px'
    });
  }

  details(id) {
    this.injectionMoldList.forEach(cncMachineObject => {
      if (cncMachineObject.id === id) {
        this.injectionMoldConfig = cncMachineObject;
      }
      this.hideForm = true
    });
  }

  cancel() {
    this.injectionMoldConfig = null;
  }

  isActiveClass(injectionMold) {
    this.injectionMoldService.isActiveClass(this.injectionMoldList, injectionMold)
  }

  getMachineDetails(machineList: any[]): string {
    let machineName: string = '';
    for (var i = 0; i < machineList.length; i++) {
      machineName = machineName.concat(' ' + machineList[i].equipmentName).concat(',');
    }
    return machineName.slice(0, -1);
  }

  save() {
    this.injectionMoldConfig.mfgconnectSiteId = this.plantId
    console.log("data is", this.injectionMoldConfig)
    if (this.injectionMoldConfig.id == undefined) {
      this.injectionMoldService.saveDeviceData(this.injectionMoldConfig).subscribe((data) => {
        console.log("data", data)
        this.onLoad();
        this.hideForm = false;
      });

    }
    else {
      this.injectionMoldService.updateDeviceData(this.injectionMoldConfig).subscribe(
        () => {
          console.log('updated Procell Cell')
          this.onLoad();
          this.hideForm = false
        }
      )

    }
  }

  confirmDelete(id): void {
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.injectionMoldService.onInjectionMoldDelete(id).subscribe((resp) => {
          console.log("prod line deleted", resp);
          this.onLoad();
        });
      }
    })
  }
}


