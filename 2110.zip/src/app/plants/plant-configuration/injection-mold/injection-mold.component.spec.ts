import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InjectionMoldComponent } from './injection-mold.component';

describe('InjectionMoldComponent', () => {
  let component: InjectionMoldComponent;
  let fixture: ComponentFixture<InjectionMoldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InjectionMoldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InjectionMoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
