export class InjectionMoldModel {
  id?: number;
  injMoldName?: string

  injMoldCode?: string

  mfgconnectInjMoldMasterId?: number
  mfgconnectProductionLineId?: number
  allowedMachines?: EquipmentModel[]
  mfgconnectSiteId?: number;

}

export class EquipmentModel {
  id?: number;
  equipmentName?: string
}
