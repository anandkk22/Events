import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AgitatorsModel } from './agitators.model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AgitatorService {
    public listofAgitators: string = environment.PROCESS_API_URL + 'api/agitators/plant';
    public agitatorApi: string = environment.PROCESS_API_URL + 'api/agitator';
    public processUnitByPlantId = environment.PROCESS_API_URL + "api/processunit/plant"
    public agitatorType = environment.PROCESS_API_URL + "api/getAllAgitatorTypes"
    public agitatorImpellerType = environment.PROCESS_API_URL + "api/getAllAgitatorImpellerTypes"
    public powerSupplyType = environment.PROCESS_API_URL + "api/powerSupplyType";
    public relationship: string = environment.PROCESS_API_URL + 'api/agitator';

    constructor(private _http: HttpClient) { }

    getListofAgitators(id: number): Observable<AgitatorsModel[]> {
        return this._http.get<AgitatorsModel[]>(`${this.listofAgitators}/${id}`)
    }

    getAgitatorById(id: number): Observable<AgitatorsModel> {
        return this._http.get<AgitatorsModel>(`${this.agitatorApi}/${id}`)
    }

    createNewAgitator(agitator: AgitatorsModel): Observable<AgitatorsModel> {
        return this._http.post<AgitatorsModel>(`${this.agitatorApi}`, agitator, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateAgitator(agitator: AgitatorsModel): Observable<void> {
        return this._http.put<void>(`${this.agitatorApi}`, agitator, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteAgitatorById(id) {
        return this._http.delete(`${this.agitatorApi}/${id}`, { responseType: 'text' })
        .pipe(catchError(this.handleError))
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }

    getProcessUnitByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processUnitByPlantId}/${id}`);
    }

    getAgitatorTypes() {
        return this._http.get<any>(`${this.agitatorType}`);

    }

    getAgitatorImpellerTypes() {
        return this._http.get<any>(`${this.agitatorImpellerType}`);

    }
    getPowerSupplyTypes() {
        return this._http.get<any>(`${this.powerSupplyType}`);
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }
}
