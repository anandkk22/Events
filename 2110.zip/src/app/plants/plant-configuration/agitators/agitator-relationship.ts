import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { AgitatorService } from './agitators.service';


@Component({
    selector: 'agitator-relationship',
    templateUrl: './agitator-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class AgitatorRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getAgitatorId: any;

    constructor(private _mdr: MatDialogRef<AgitatorRelationshipComponent>, 
        private _agitatorservice: AgitatorService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getAgitatorId = localStorage.getItem('agitatorId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._agitatorservice.getRelationship(this.getAgitatorId).subscribe(
                agitator => {
                    this.getRelationship = agitator
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('agitatorId');
    }

}
