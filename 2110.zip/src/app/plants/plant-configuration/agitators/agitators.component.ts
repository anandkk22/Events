import { Component, OnInit } from '@angular/core';
import { MatDialog, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { AgitatorService } from './agitators.service';
import { AgitatorsModel } from './agitators.model';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { AgitatorRelationshipComponent } from './agitator-relationship';

@Component({
    selector: 'app-agitators',
    templateUrl: './agitators.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class AgitatorsComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    plantConfigAgitatorsDetails: AgitatorsModel[];
    agitator: AgitatorsModel;
    plantConfigAgitatorsDetail: any = {};
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;
    processUnits: any;
    agitatorTypes: any;
    agitatorImpellerTypes: any;
    powerSupplyTypes: any = [];
    $localAgitatorId: any;
    formVisible: boolean = true;

    constructor(private agitatorService: AgitatorService, public dialog: MatDialog,
        private _route: ActivatedRoute, private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigAgitatorsDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.loadAgitators();

        this.agitatorService.getProcessUnitByPlantId(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("process unit", this.processUnits);
        });

        this.agitatorService.getAgitatorTypes().subscribe((resp) => {
            this.agitatorTypes = resp;
            console.log("pump", this.agitatorTypes);
        });

        this.agitatorService.getAgitatorImpellerTypes().subscribe((resp) => {
            this.agitatorImpellerTypes = resp;
            console.log("pump", this.agitatorImpellerTypes);
        });
        this.agitatorService.getPowerSupplyTypes().subscribe((resp) => {
            this.powerSupplyTypes = resp;
            console.log("pump33", this.powerSupplyTypes);
        });
    }

    loadAgitators() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this.agitatorService.getListofAgitators(this.getPlantId).subscribe(
                agitator => {
                    this.plantConfigAgitatorsDetails = agitator
                }
            )
        });
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigAgitatorsDetails) {
            if (sortFilter === 'id') {
                this.plantConfigAgitatorsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigAgitatorsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this.agitatorService.deleteAgitatorById(id).subscribe(
                    () => this.loadAgitators()
                )              
            }
        })
    }

    showRelationship(getAgitatorId): void {
        this.$localAgitatorId = localStorage.setItem('agitatorId', JSON.stringify(getAgitatorId));
        const dialogRef = this.dialog.open(AgitatorRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigAgitatorsDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigAgitatorsDetail = proessCell;
            }
            this.formVisible = true;
        });
    }

    addnew() {
        this.plantConfigAgitatorsDetail = {};
        this.formVisible = true;
    }

    isActiveClass(processCell) {
        this.agitatorService.isActiveClass(this.plantConfigAgitatorsDetails, processCell)
    }

    save() {
        this.plantConfigAgitatorsDetail.mfgconnectSiteId = this.getPlantId;
        console.log("agitator", this.plantConfigAgitatorsDetail);
        if (this.plantConfigAgitatorsDetail.id == undefined) {
            this.agitatorService.createNewAgitator(this.plantConfigAgitatorsDetail).subscribe(
                (data: AgitatorsModel) => {
                    console.log(data);
                    this.loadAgitators();
                }
            );
            this.formVisible = false;

        }
        else {
            this.agitatorService.updateAgitator(this.plantConfigAgitatorsDetail).subscribe(
                () => {
                    console.log('updated Pump');
                    this.loadAgitators();
                }
            );
            this.formVisible = false;
        }
    }

    cancel() {
        this.plantConfigAgitatorsDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}
