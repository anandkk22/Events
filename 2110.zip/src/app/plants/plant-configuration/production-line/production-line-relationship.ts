import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { ProductionLineService } from './production-line.service';

//import { CompressorsService } from './compressors.service';



@Component({
  selector: 'production-line-relationship',
  templateUrl: './production-line-relationship.html',
  styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class ProductionLineRelationshipComponent implements OnInit, OnDestroy {
  private _id: number;
  getPlantId: any;
  getRelationship: any
  prodPlanId: any;

  constructor(private _mdr: MatDialogRef<ProductionLineRelationshipComponent>,
    private prodLineService: ProductionLineService, private _route: ActivatedRoute) {

  }

  onNoClick(): void {
    this._mdr.close();
  }

  ngOnInit() {
    this.prodPlanId = localStorage.getItem('prodLineId');
    this.onLoad();
  }

  onLoad() {
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this.prodLineService.getRelationship(this.prodPlanId).subscribe(
        prodLine => {
          this.getRelationship = prodLine
        }
      )
    })
  }

  ngOnDestroy() {
    localStorage.removeItem('prodPlanId');
  }

}
