import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material';
import { Observable, throwError } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { options } from '@amcharts/amcharts4/core';
import { ProductionLineModel } from './production-line.model'
import { environment } from 'src/environments/environment';
//import { PopUpAfterDelete } from '../../pop-up-after-delete/pop-up-after-delete';

@Injectable({
  providedIn: 'root'
})
export class ProductionLineService {
  private currentMachine = new BehaviorSubject({});
  private paramData;
  private currentValue = new BehaviorSubject({});
  private currentParamValue = new BehaviorSubject({});
  private currentAlertValue = new BehaviorSubject({});

  updateMachineMessage = this.currentMachine.asObservable();
  updatedParameterMessage = this.currentParamValue.asObservable();
  updatedDeviceMessage = this.currentValue.asObservable();
  updatedAlertMessage = this.currentAlertValue.asObservable();

  constructor(private _http: HttpClient, public dialog: MatDialog) { }


  public getAllProductionLines(plantId: number): Observable<Object> {

    return this._http.get<ProductionLineModel[]>(environment.CNC_API_URL + "api/productionLine/get-by-plant/" + plantId);
  }

  public saveProductionLine(data: any): Observable<Object> {

    return this._http.post(environment.CNC_API_URL + "api/mfgconnect-production-lines", data);
  }
  public onProductionLineDelete(id: any): Observable<Object> {

    //return this._http.delete(environment.CNC_API_URL + "api/mfgconnect-production-lines/" + id);
    return this._http.delete(environment.CNC_API_URL + "api/mfgconnect-production-lines/" + id, { responseType: 'text' })
      .pipe(catchError(this.handleError))

  }

  public updateProductionLine(data: any): Observable<Object> {

    return this._http.put(environment.CNC_API_URL + "api/mfgconnect-production-lines", data);

  }

  public getRelationship(id: number): Observable<Object> {
    return this._http.get(environment.CNC_API_URL + "api/productionLine/get-relationship/" + id);
  }


  isActiveClass(componentList, currComponent) {
    componentList.forEach(element => {
      element.isActive = false;
    });
    currComponent.isActive = true;
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }
}
