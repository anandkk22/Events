import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { AreaService } from '../area/area.service';
import { ProductionLineRelationshipComponent } from './production-line-relationship';
import { ProductionLineModel } from './production-line.model';
import { ProductionLineService } from './production-line.service';

@Component({
  selector: 'app-production-line',
  templateUrl: './production-line.component.html',
  styleUrls: ['../plant-configuration.component.scss', './production-line.component.scss']
})
export class ProductionLineComponent implements OnInit {
  tempList: any
  productionLineList: ProductionLineModel[];
  distributedList: ProductionLineModel[];
  productionLineConfig = null;
  productionLine: ProductionLineModel;
  hideForm: boolean = true;
  getPlantId: any;
  areaList: any = []
  $localProdLineId;
  //moldMasterList: any = []

  constructor(private productionLineService: ProductionLineService, private areaService: AreaService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.getPlantId = localStorage.getItem('plantId');
    this.onLoad();

    this.areaService.getListofAreas(this.getPlantId).subscribe(resp => {
      console.log("areas are", resp)
      this.areaList = resp
    })



  }

  onLoad() {
    this.productionLineService.getAllProductionLines(this.getPlantId).subscribe(productionLine => {
      let tList = []
      console.log("resp is", productionLine)
      if (productionLine instanceof Array) {
        this.tempList = productionLine
        if (this.tempList instanceof Array) {
          for (let i = 0; i < this.tempList.length; i++) {
            this.distributedList = this.tempList[i];
            if (this.distributedList.length != 0) {
              for (let j = 0; j < this.distributedList.length; j++) {


                tList.push(this.distributedList[j]);

              }
            }
          }
        }
      }
      this.productionLineList = tList
      console.log("cnc machine list is", this.productionLineList)
    })
  }

  addnew() {
    this.productionLineConfig = new ProductionLineModel();
    this.hideForm = true;
  }

  details(id) {
    this.productionLineList.forEach(cncMachineObject => {
      if (cncMachineObject.id === id) {
        this.productionLineConfig = cncMachineObject;
        this.hideForm = true;
      }
    });
  }

  cancel() {
    this.productionLineConfig = null;
  }

  isActiveClass(productionLine) {
    this.productionLineService.isActiveClass(this.productionLineList, productionLine)
  }

  showRelationship(prodLineId): void {
    this.$localProdLineId = localStorage.setItem('prodLineId', JSON.stringify(prodLineId));
    const dialogRef = this.dialog.open(ProductionLineRelationshipComponent, {
      width: '450px'
    });
  }

  save() {
    this.productionLineConfig.mfgconnectSiteId = this.getPlantId
    console.log("data is", this.productionLineConfig)
    if (this.productionLineConfig.id == undefined) {
      this.productionLineService.saveProductionLine(this.productionLineConfig).subscribe((data) => {
        console.log("data", data)
        this.onLoad();
        this.hideForm = false;
      });

    }
    else {
      this.productionLineService.updateProductionLine(this.productionLineConfig).subscribe(
        (data) => {
          console.log('updated Procell Cell')
          this.onLoad();
          this.hideForm = false;
        })

    }
  }

  confirmDelete(id) {
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.productionLineService.onProductionLineDelete(id).subscribe((resp) => {
          console.log("prod line deleted", resp);
          this.onLoad();
        });
      }
    })
  }


}
