import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { ReactorsService } from './reactors.service';

@Component({
    selector: 'reactor-relationship',
    templateUrl: './reactor-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class ReactorRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getReactorId: any;

    constructor(private _mdr: MatDialogRef<ReactorRelationshipComponent>, 
        private _reactorService: ReactorsService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getReactorId = localStorage.getItem('reactorId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._reactorService.getRelationship(this.getReactorId).subscribe(
                reactor => {
                    this.getRelationship = reactor
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('reactorId');
    }

}
