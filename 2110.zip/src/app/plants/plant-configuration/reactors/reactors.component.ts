import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { ReactorsService } from './reactors.service';
import { ActivatedRoute } from '@angular/router';
import { ReactorModel } from './reactor.model';
import { ReactorRelationshipComponent } from './reactor-relationship';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

@Component({
    selector: 'app-reactors',
    templateUrl: './reactors.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class ReactorComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    plantConfigReactorDetails: ReactorModel[];
    reactor = null;
    plantConfigReactorDetail: any = {};
    mountTechnologies = [{ id: 1, name: 'Hybrid' }, { id: 2, name: 'Fixed Tilt' }, { id: 3, name: 'Seasonal Tilt' }, { id: 4, name: 'Single Axis Tracker' }, { id: 5, name: 'Dual Asix Tracker' }];
    plantTypes = [{ id: 1, name: 'Grounded Moulded Utility' }, { id: 2, name: 'Rooftop Distributed' }];
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;
    processUnits: any;
    reactorTypes: any;
    powerSupplyTypes: any = [];
    $localReactorId: any;
    formVisible: boolean = true;

    constructor(private _reactorsService: ReactorsService, public dialog: MatDialog,
        private _route: ActivatedRoute, private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        // this.plantConfigReactorDetail.mfgconnectSiteId = this.getPlantId;

        this._reactorsService.getProcessUnitByPlantId(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("process unit", this.processUnits);
        });

        this._reactorsService.getReactorTypes().subscribe((resp) => {
            this.reactorTypes = resp;
            console.log("pump", this.reactorTypes);
        });

        this._reactorsService.getPowerSupplyTypes().subscribe((resp) => {
            this.powerSupplyTypes = resp;
            console.log("pump33", this.powerSupplyTypes);
        });

        this.plantConfigReactorDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.loadReactors();
    }

    loadReactors() {

        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._reactorsService.getlistofReactors(this.getPlantId).subscribe(
                reactor => {
                    this.plantConfigReactorDetails = reactor;
                    console.log("received", this.plantConfigReactorDetails);
                }
            )
        });
    }
    applySortFilter(sortFilter) {
        if (this.plantConfigReactorDetails) {
            if (sortFilter === 'id') {
                this.plantConfigReactorDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigReactorDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }


    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._reactorsService.deleteReactorById(id).subscribe(
                    () => this.loadReactors()
                )                
            }
        })
    }

    showRelationship(getReactorId): void {
        this.$localReactorId = localStorage.setItem('reactorId', JSON.stringify(getReactorId));
        const dialogRef = this.dialog.open(ReactorRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigReactorDetails.forEach(reactor => {
            if (reactor.id === id) {
                this.plantConfigReactorDetail = reactor;
            }
            this.formVisible = true;
        });
    }

    addnew() {
        this.plantConfigReactorDetail = {};
        this.formVisible = true;
    }

    isActiveClass(processCell) {
        this._reactorsService.isActiveClass(this.plantConfigReactorDetails, processCell)
    }

    save() {
        this.plantConfigReactorDetail.mfgconnectSiteId = this.getPlantId;
        console.log("reqactor save", this.plantConfigReactorDetail);

        if (this.plantConfigReactorDetail.id == undefined) {
            this._reactorsService.createNewReactor(this.plantConfigReactorDetail).subscribe(
                (data: ReactorModel) => {
                    console.log(data);
                    this.loadReactors();
                }
            );
            this.formVisible = false;
        }
        else {
            this._reactorsService.updateReactor(this.plantConfigReactorDetail).subscribe(
                () => {
                    console.log('updated Reactor');
                    this.loadReactors();
                }
            );
            this.formVisible = false;
        }
    }

    cancel() {
        this.plantConfigReactorDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}