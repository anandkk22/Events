import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ReactorModel } from './reactor.model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ReactorsService {
    public listofReactors: string = environment.PROCESS_API_URL + 'api/reactor/plant';
    public getReactor: string = environment.PROCESS_API_URL + 'api/reactor';
    public addUpdateReactor: string = environment.PROCESS_API_URL + 'api/reactor';
    public deleteReactor: string = environment.PROCESS_API_URL + 'api/reactor';
    public processUnitByPlantId = environment.PROCESS_API_URL + "api/processunit/plant"
    public reactorType = environment.PROCESS_API_URL + "api/getAllReactorTypes"
    public powerSupplyType = environment.PROCESS_API_URL + "api/powerSupplyType";
    public relationship: string = environment.PROCESS_API_URL + 'api/reactor';

    constructor(private _http: HttpClient) { }

    getlistofReactors(id: number): Observable<ReactorModel[]> {
        return this._http.get<ReactorModel[]>(`${this.listofReactors}/${id}`)
    }

    getReactorById(id: number): Observable<ReactorModel> {
        return this._http.get<ReactorModel>(`${this.getReactor}/${id}`)
    }

    createNewReactor(reactor: ReactorModel): Observable<ReactorModel> {
        return this._http.post<ReactorModel>(`${this.addUpdateReactor}`, reactor)
    }

    updateReactor(reactor: ReactorModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateReactor}`, reactor)
    }

    deleteReactorById(id) {
        return this._http.delete(this.deleteReactor+"/"+ id, {responseType: 'text'})
        .pipe(catchError(this.handleError))
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
    getProcessUnitByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processUnitByPlantId}/${id}`);
    }

    getReactorTypes() {
        return this._http.get<any>(`${this.reactorType}`);
    }
    getPowerSupplyTypes()
    {
        return this._http.get<any>(`${this.powerSupplyType}`);
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }
}