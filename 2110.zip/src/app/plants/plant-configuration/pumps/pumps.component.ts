import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PumpService } from './pumps.service';
import { ActivatedRoute } from '@angular/router';
import { PumpsModel } from './pumps.model';
import { PumpRelationshipComponent } from './pump-relationship';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';


@Component({
    selector: 'app-pumps',
    templateUrl: './pumps.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class PumpsComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    plantConfigPumpsDetails: any = [];
    pump: any;
    plantConfigPumpsDetail: any = {
        mfgconnectSiteId: ''
    };
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;
    processUnits: any = [];
    pumpTypes: any = [];
    powerSupplyTypes: any = [];
    $localPumpId: any;
    formVisible: boolean = true;
    constructor(private _pumpService: PumpService, public dialog: MatDialog,
        private _route: ActivatedRoute, private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigPumpsDetail.mfgconnectSiteId = this.getPlantId;

        this._pumpService.getProcessUnitByPlantId(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("process unit", this.processUnits);
        });

        this._pumpService.getPumpTypes().subscribe((resp) => {
            this.pumpTypes = resp;
            console.log("pump", this.pumpTypes);
        });

        this._pumpService.getPowerSupplyTypes().subscribe((resp) => {
            this.powerSupplyTypes = resp;
            console.log("pump33", this.powerSupplyTypes);
        });

        this.plantConfigPumpsDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.onLoad();
    }
    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._pumpService.getListofPumps(this.getPlantId).subscribe(
                pump => {
                    this.plantConfigPumpsDetails = pump
                    console.log("pumsss", this.plantConfigPumpsDetails);
                }
            )
        })
    }
    applySortFilter(sortFilter) {
        if (this.plantConfigPumpsDetails) {
            if (sortFilter === 'id') {
                this.plantConfigPumpsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigPumpsDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id) {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._pumpService.deletePumpById(id).subscribe((resp) => {
                    console.log("resss", resp);
                    this.onLoad();
                });                
            }
        })
    }

    showRelationship(getPumpId): void {
        this.$localPumpId = localStorage.setItem('pumpId', JSON.stringify(getPumpId));
        const dialogRef = this.dialog.open(PumpRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigPumpsDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigPumpsDetail = proessCell;
            }
            this.formVisible = true;
        });
    }

    addnew() {
        this.plantConfigPumpsDetail = {};
        this.formVisible = true;

    }

    isActiveClass(processCell) {
        this._pumpService.isActiveClass(this.plantConfigPumpsDetails, processCell)
    }

    save() {
        this.plantConfigPumpsDetail.mfgconnectSiteId = this.getPlantId;
        console.log("pump save", this.plantConfigPumpsDetail);
        if (this.plantConfigPumpsDetail.id == undefined) {
            this._pumpService.createNewPump(this.plantConfigPumpsDetail).subscribe((data) => {
                console.log(data);
                this.onLoad();
            });
            this.formVisible = false;
        }
        else {
            this._pumpService.updatePump(this.plantConfigPumpsDetail).subscribe(() => {
                console.log('updated Pump');
                this.onLoad();
            });
            this.formVisible = false;
        }
    }

    cancel() {
        this.plantConfigPumpsDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}