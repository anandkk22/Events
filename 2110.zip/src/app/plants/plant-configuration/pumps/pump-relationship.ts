import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { PumpService } from './pumps.service';




@Component({
    selector: 'pump-relationship',
    templateUrl: './pump-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class PumpRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getPumpId: any;

    constructor(private _mdr: MatDialogRef<PumpRelationshipComponent>, 
        private _pumpService: PumpService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getPumpId = localStorage.getItem('pumpId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._pumpService.getRelationship(this.getPumpId).subscribe(
                centrifuge => {
                    this.getRelationship = centrifuge
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('pumpId');
    }

}
