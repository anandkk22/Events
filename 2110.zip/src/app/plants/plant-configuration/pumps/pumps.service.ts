import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { PumpsModel } from './pumps.model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class PumpService {
    public listofPumps: string = environment.PROCESS_API_URL + 'api/pumps/plant';
    public getPump: string = environment.PROCESS_API_URL + 'api/pump';
    public addUpdatePump: string = environment.PROCESS_API_URL + 'api/pump';
    public deletePump: string = environment.PROCESS_API_URL + 'api/pump';
    public processCellByPlantId = environment.PROCESS_API_URL + "api/processcell/plant";
    public processUnitByPlantId = environment.PROCESS_API_URL + "api/processunit/plant"
    public pumpType = environment.PROCESS_API_URL + "api/getAllPumpTypes"
    public powerSupplyType = environment.PROCESS_API_URL + "api/powerSupplyType";
    public relationship: string = environment.PROCESS_API_URL + 'api/pump';
    
    constructor(private _http: HttpClient) { }

    getListofPumps(id: number): Observable<PumpsModel[]> {
        return this._http.get<PumpsModel[]>(`${this.listofPumps}/${id}`);
    }

    getPumpById(id: number): Observable<PumpsModel> {
        return this._http.get<PumpsModel>(`${this.getPump}/${id}`);
    }

    createNewPump(pump: any): Observable<any> {
        return this._http.post<any>(`${this.addUpdatePump}`, pump);
    }

    updatePump(pump: PumpsModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdatePump}`, pump);
    }

    deletePumpById(id) {
        return this._http.delete(this.deletePump+"/"+ id, {responseType: 'text'})
        .pipe(catchError(this.handleError)) 
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }

    getProcessCellByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processCellByPlantId}/${id}`);
    }
    getProcessUnitByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processUnitByPlantId}/${id}`);
    }

    getPumpTypes() {
        return this._http.get<any>(`${this.pumpType}`);
    }
    getPowerSupplyTypes()
    {
        return this._http.get<any>(`${this.powerSupplyType}`);
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }
}