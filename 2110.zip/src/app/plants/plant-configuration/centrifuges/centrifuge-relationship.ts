import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { CentrifugeService } from './centrifuges.service';


@Component({
    selector: 'centrifuge-relationship',
    templateUrl: './centrifuge-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class CentrifugeRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getCentrifugeId: any;

    constructor(private _mdr: MatDialogRef<CentrifugeRelationshipComponent>, 
        private _centrifugeService: CentrifugeService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getCentrifugeId = localStorage.getItem('centrifugeId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._centrifugeService.getRelationship(this.getCentrifugeId).subscribe(
                centrifuge => {
                    this.getRelationship = centrifuge
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('centrifugeId');
    }
}
