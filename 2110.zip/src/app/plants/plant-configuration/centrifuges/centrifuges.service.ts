import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CentrifugesModel } from './centrifuges.model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class CentrifugeService {
    public listofCentrifuges: string = environment.PROCESS_API_URL + 'api/centrifuges/plant';
    public centrifugeApi: string = environment.PROCESS_API_URL + 'api/centrifuge';
    public processUnitByPlantId = environment.PROCESS_API_URL + "api/processunit/plant"
    public centrifugeType = environment.PROCESS_API_URL + "api/getAllCentrifugeTypes"
    public centrifugeImpellerType = environment.PROCESS_API_URL + "api/getAllCentrifugeImpellerTypes"
    public powerSupplyType = environment.PROCESS_API_URL + "api/powerSupplyType";
    public relationship: string = environment.PROCESS_API_URL + 'api/centrifuge';

    constructor(private _http: HttpClient) { }

    getListofCentrifuges(id: number): Observable<CentrifugesModel[]> {
        return this._http.get<CentrifugesModel[]>(`${this.listofCentrifuges}/${id}`)
    }

    getCentrifugeById(id: number): Observable<CentrifugesModel> {
        return this._http.get<CentrifugesModel>(`${this.centrifugeApi}/${id}`)
    }

    createNewCentrifuge(centrifuge: CentrifugesModel): Observable<CentrifugesModel> {
        return this._http.post<CentrifugesModel>(`${this.centrifugeApi}`, centrifuge, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateCentrifuge(centrifuge: CentrifugesModel): Observable<void> {
        return this._http.put<void>(`${this.centrifugeApi}`, centrifuge, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteCentrifugeById(id) {
        return this._http.delete(`${this.centrifugeApi}/${id}`, {responseType: 'text'})
        .pipe(catchError(this.handleError))  
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
    getProcessUnitByPlantId(id: number): Observable<any> {
        return this._http.get<any>(`${this.processUnitByPlantId}/${id}`);
    }

    getCentrifugeTypes() {
        return this._http.get<any>(`${this.centrifugeType}`);

    }

    getCentrifugeImpellerTypes() {
        return this._http.get<any>(`${this.centrifugeImpellerType}`);

    }
    getPowerSupplyTypes()
    {
        return this._http.get<any>(`${this.powerSupplyType}`);
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }
}
