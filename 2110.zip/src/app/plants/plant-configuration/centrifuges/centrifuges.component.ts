import { Component, OnInit } from '@angular/core';
import { CentrifugeService } from './centrifuges.service';
import { CentrifugesModel } from './centrifuges.model';
import { MatDialog, MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { PidiliteUtilityPlant } from '../../pidilite-utility-plant.model';
import { CentrifugeRelationshipComponent } from './centrifuge-relationship';

@Component({
    selector: 'app-centrifuges',
    templateUrl: './centrifuges.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class CentrifugesComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    plantConfigCentrifugesDetails: any = [];
    centrifuge: any;
    plantConfigCentrifugesDetail = null;
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    getPlantId: any;
    processUnits: any;
    centrifugeTypes: any;
    centrifugeImpellerTypes: any;
    powerSupplyTypes: any = [];
    $localCentrifugeId: any;
    formVisible: boolean = true;

    constructor(private centrifugeService: CentrifugeService, public dialog: MatDialog,
        private _route: ActivatedRoute, private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId')
        this.plantConfigCentrifugesDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';

        this.centrifugeService.getProcessUnitByPlantId(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("process unit", this.processUnits);
        });

        this.centrifugeService.getCentrifugeTypes().subscribe((resp) => {
            this.centrifugeTypes = resp;
            console.log("pump", this.centrifugeTypes);
        });

        this.centrifugeService.getCentrifugeImpellerTypes().subscribe((resp) => {
            this.centrifugeImpellerTypes = resp;
            console.log("pump4", this.centrifugeImpellerTypes);
        });

        this.centrifugeService.getPowerSupplyTypes().subscribe((resp) => {
            this.powerSupplyTypes = resp;
            console.log("pump33", this.powerSupplyTypes);
        });

        this.loadCentrifuges();
    }

    loadCentrifuges() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this.centrifugeService.getListofCentrifuges(this.getPlantId).subscribe(
                agitator => {
                    this.plantConfigCentrifugesDetails = agitator
                }
            )
        });
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigCentrifugesDetails) {
            if (sortFilter === 'id') {
                this.plantConfigCentrifugesDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigCentrifugesDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id): void {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this.centrifugeService.deleteCentrifugeById(id).subscribe(
                    () => this.loadCentrifuges()
                )             
            }
        })
    }

    showRelationship(getCentrifugeId): void {
        this.$localCentrifugeId = localStorage.setItem('centrifugeId', JSON.stringify(getCentrifugeId));
        const dialogRef = this.dialog.open(CentrifugeRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigCentrifugesDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigCentrifugesDetail = proessCell;
            }
            this.formVisible = true;
        });
    }

    addnew() {
        this.plantConfigCentrifugesDetail = {};
        this.formVisible = true;
    }

    isActiveClass(processCell) {
        this.centrifugeService.isActiveClass(this.plantConfigCentrifugesDetails, processCell)
    }

    save() {
        this.plantConfigCentrifugesDetail.mfgconnectSiteId = this.getPlantId;
        if (this.plantConfigCentrifugesDetail.id == undefined) {
            this.centrifugeService.createNewCentrifuge(this.plantConfigCentrifugesDetail).subscribe(
                (data: CentrifugesModel) => {
                    console.log(data);
                    this.loadCentrifuges();

                }
            );
            this.formVisible = false;
        }
        else {
            this.centrifugeService.updateCentrifuge(this.plantConfigCentrifugesDetail).subscribe(
                () => {
                    console.log('updated Pump');
                    this.loadCentrifuges();

                }
            );
            this.formVisible = false;
        }
    }

    cancel() {
        this.plantConfigCentrifugesDetail = null;
        // this.getPlantConfigReactorDetails();
    }
}
