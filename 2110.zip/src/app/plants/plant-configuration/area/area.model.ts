export class AreaModel {
    constructor(
        public id?: number,
        public name?: string,
        public description?: string,
        public activity?: string,
        public timezone?: any,
        public plantId?: number,
        public lastUpdated?: Date,
        public externalId?: number
    ) {

    }
}