import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AreaModel } from './area.model';
import { catchError } from 'rxjs/operators';
import { string } from '@amcharts/amcharts4/core';

@Injectable({ providedIn: 'root' })
export class AreaService {
  public listofArea: string = environment.CNC_API_URL + 'api/area/plant';
  public addUpdateArea: string = environment.CNC_API_URL + 'api/area';
  public getArea: string = environment.CNC_API_URL + 'api/area';
  public deleteArea: string = environment.CNC_API_URL + 'api/area';
  public activityType: string = environment.CNC_API_URL + 'api/activityType';
  public relationship: string = environment.CNC_API_URL + 'api/area/rel';
  error: any = string

  constructor(private _http: HttpClient) { }

  getListofAreas(id: number): Observable<AreaModel[]> {
    return this._http.get<AreaModel[]>(`${this.listofArea}/${id}`)
  }

  getAreaById(id: number): Observable<AreaModel> {
    return this._http.get<AreaModel>(`${this.getArea}/${id}`)

  }

  createNewArea(area: AreaModel): Observable<any> {
    return this._http.post<any>(`${this.addUpdateArea}`, area, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateArea(area: AreaModel): Observable<void> {
    return this._http.put<void>(`${this.addUpdateArea}`, area, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  deleteAreaById(id: number) {
    return this._http.delete(this.deleteArea + "/" + id, { responseType: 'text' })
      .pipe(catchError(this.handleError))
  }

  getActivityType(): Observable<any[]> {
    return this._http.get<any[]>(this.activityType)
  }

  getRelationship(id: number): Observable<AreaModel[]> {
    return this._http.get<AreaModel[]>(`${this.relationship}/${id}`)
  }

  isActiveClass(componentList, currComponent) {
    componentList.forEach(element => {
      element.isActive = false;
    });
    currComponent.isActive = true;
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }
}
