import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { AreaService } from './area.service';
import { ActivatedRoute } from '@angular/router';
import { AreaModel } from './area.model';

@Component({
    selector: 'area-relationship',
    templateUrl: './area-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class AreaRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getAreaId: any;

    constructor(private _mdr: MatDialogRef<AreaRelationshipComponent>, 
        private _areaService: AreaService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getAreaId = localStorage.getItem('areaId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._areaService.getRelationship(this.getAreaId).subscribe(
                area => {
                    console.log("areas", area)
                    this.getRelationship = area
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('areaId');
    }

}
