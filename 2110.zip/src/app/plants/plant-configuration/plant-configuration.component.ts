import { Component, OnInit } from '@angular/core';
import { PlantConfigurationService } from './plant-configuration.service';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { PidiliteUtilityPlant } from '../../models/Pidilite-Plant.model';
import { PidilitePlantsService } from '../pidilite-plants.service';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';


@Component({
  selector: 'app-plant-configuration',
  templateUrl: './plant-configuration.component.html',
  styleUrls: ['./plant-configuration.component.scss']
})

export class PlantConfigurationComponent implements OnInit {
  plantConfigDetails: any = [];
  currRoute: string = null;
  plant: pidiliteMainModel;
  private _id: number;


  constructor(private _plantconfigService: PlantConfigurationService,
    private _router: Router,
    private _route: ActivatedRoute,
    private _plantService: PidilitePlantsService) { }
  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      console.log("*******", this._id)
      this._plantService.getPlantById(this._id).subscribe(
        data => this.plant = data
      )
    });
    this.getPlantConigDetails();
    this.checkRoute();

    this._plantService.getPlantById(this._id).subscribe(
      (res) => {
        this.plant = res;
        this.menuItems.splice(0, 0, {
          name: '',
          children: [
            {
              name: 'Plant Details >',
              router: `/plant-details/${this.plant.id}`,
              // secondLine: this.plant.id
              secondLine: this.plant.name
            }
          ]
        });
      }
    )
  }

  getPlantConigDetails() {
    this._plantconfigService.getplantConfigDetails().subscribe(
      (data) => {
        this.plantConfigDetails = data;
      }
    )
  }

  menuItems = [
    {
      name: 'Logical Components',
      children: [
        { name: 'Area', router: 'area', secondLine: null },
        { name: 'Process Cell', router: 'processcell', secondLine: null },
        { name: 'Process Unit', router: 'processunit', secondLine: null },
        { name: 'Production Line', router: 'production-line', secondLine: null }
      ]
    },
    {
      name: 'Physical Components',
      children: [
        { name: 'Reactors', router: 'reactor', secondLine: null },
        { name: 'Pumps', router: 'pump', secondLine: null },
        { name: 'CNC Machines', router: 'cnc-machine', secondLine: null },
        { name: 'Agitator', router: 'agitator', secondLine: null },
        { name: 'Centrifuge', router: 'centrifuge', secondLine: null },
        { name: 'Compressors', router: 'compressor', secondLine: null },
        { name: 'Injection Mold', router: 'injection-mold', secondLine: null },
        { name: 'Injection Molding Machine', router: 'injection-molding-machine', secondLine: null }
      ]
    }
  ];

  checkRoute() {
    this.currRoute = this._router.url.split('/').pop();

  }
  changeRoute(newRoute) {
    // console.log("newRoute", newRoute)
    this.currRoute = newRoute;
    // this._router.navigate([`${newRoute}/`,{id: this.plant.id}])

  }
}

