import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { MoldMasterService } from 'src/app/product-configurator/mold-master/moldmaster.service';
import { DeletePlant } from '../../delete-plant/delete-plant';
import { ProductionLineService } from '../production-line/production-line.service';
import { InjectionMoldingMachineRelationshipComponent } from './injection-molding-machine-relationship';
import { InjectionMoldingMachineModel, MoldMaster } from './injection-molding-machine.model';
import { InjectionMoldingMachineService } from './injection-molding-machine.service';

@Component({
  selector: 'app-injection-molding-machine',
  templateUrl: './injection-molding-machine.component.html',
  styleUrls: ['../plant-configuration.component.scss', './injection-molding-machine.component.scss']
})
export class InjectionMoldingMachineComponent implements OnInit {
  tempList: any;
  injectionMoldingMachineList: InjectionMoldingMachineModel[];
  distributedList: InjectionMoldingMachineModel[];
  injectionMoldingMachineConfig: InjectionMoldingMachineModel = {};
  tempObj: InjectionMoldingMachineModel = {};
  injectionMoldingMachine: InjectionMoldingMachineModel;
  hideForm: boolean = true;
  prodLineList: any = [];
  typeList: any = []
  moldMasterList: any = []
  moldListName: any = []
  allowedMolds = new FormControl();
  maxDate = moment(new Date()).format('YYYY-MM-DD')
  $localInjectionMoldingMachineId: any;
  plantId: any = []
  warrantyDateMin: any
  availableMoldList: any = []
  moldMasterBoolean: boolean = false;
  //moldMasterList: any = []

  constructor(private injectionMoldingMachineService: InjectionMoldingMachineService, private prodLineService: ProductionLineService, private moldMasterService: MoldMasterService, public dialog: MatDialog, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.plantId = localStorage.getItem('plantId');
    this.onLoad()
    this.prodLineService.getAllProductionLines(this.plantId).subscribe(resp => {
      this.prodLineList = resp
      let tList = []
      let temp = []
      let prodDisc = []
      console.log("resp is", resp)
      if (this.prodLineList instanceof Array) {
        temp = this.prodLineList
        if (temp instanceof Array) {
          for (let i = 0; i < temp.length; i++) {
            prodDisc = temp[i];
            if (prodDisc.length != 0) {
              for (let j = 0; j < prodDisc.length; j++) {


                tList.push(prodDisc[j]);

              }
            }
          }
        }
      }
      this.prodLineList = tList
    })

    this.injectionMoldingMachineService.getInjMachineType().subscribe(resp => {
      this.typeList = resp;
    })

    this.moldMasterService.getListofMoldMaster().subscribe(resp => {
      this.moldMasterList = resp

    })


  }

  onLoad() {
    this.injectionMoldingMachineService.getAllInjectionMoldingMachines(this.plantId).subscribe(injectionMold => {
      let tList = []
      console.log("resp is", injectionMold)
      if (injectionMold instanceof Array) {
        this.tempList = injectionMold
        if (this.tempList instanceof Array) {
          for (let i = 0; i < this.tempList.length; i++) {
            this.distributedList = this.tempList[i];
            if (this.distributedList.length != 0) {
              for (let j = 0; j < this.distributedList.length; j++) {


                tList.push(this.distributedList[j]);

              }
            }
          }
        }
      }
      this.injectionMoldingMachineList = tList
      console.log("cnc machine list is", this.injectionMoldingMachineList)
    })
  }

  addnew() {
    this.injectionMoldingMachineConfig = new InjectionMoldingMachineModel();
    this.hideForm = false;
  }

  details(id) {
    this.injectionMoldingMachineList.forEach(cncMachineObject => {
      if (cncMachineObject.id === id) {
        this.injectionMoldingMachineConfig = cncMachineObject;
        let tempList = this.injectionMoldingMachineConfig.allowedMolds;
        if (tempList.length != 0) {
          let idList: any = []
          for (var i = 0; i < tempList.length; i++) {
            let id = tempList[i].id
            idList.push(id)
          }
          this.injectionMoldingMachineConfig.tempMolds = idList
        }
        if (this.availableMoldList != null) {
          this.availableMoldList = []
        }
        if (this.injectionMoldingMachineConfig.mfgconnectToolId != null) {
          this.availableMoldList.push(this.injectionMoldingMachineConfig.mfgconnectToolDTO)
        }
        if (this.injectionMoldingMachineConfig.allowedMolds != null) {
          let ids: { id: number }[] = [];
          if (this.injectionMoldingMachineConfig.allowedMolds != undefined) {
            if (this.injectionMoldingMachineConfig.allowedMolds instanceof Array) {
              for (let i = 0; i < this.injectionMoldingMachineConfig.allowedMolds.length; i++) {
                ids.push({ id: +this.injectionMoldingMachineConfig.allowedMolds[i].id })
              }
            }
          }
          if (ids.length != 0) {
            this.injectionMoldingMachineService.getAvailableMolds(this.plantId, ids).subscribe(resp => {
              console.log("available molds", resp)
              if (resp != null) {
                if (resp instanceof Array) {
                  for (let i = 0; i < resp.length; i++) {
                    this.availableMoldList.push(resp[i])
                  }
                }
              }
            });
          }
        }
        this.hideForm = false;


      }
    });
  }

  warrantyDateSet(installationDate) {
    console.log(installationDate)

    var newDate = moment(installationDate).add(1, 'd').format('YYYY-MM-DD')
    console.log(newDate)
    this.warrantyDateMin = moment(newDate).format('YYYY-MM-DD')
    console.log(this.warrantyDateMin)
  }

  change($event) {
    console.log("event is", $event, this.injectionMoldingMachineConfig.allowedMolds)
  }

  cancel() {
    this.injectionMoldingMachineConfig = null;
    this.hideForm = true
  }

  isActiveClass(injectionMold) {
    this.injectionMoldingMachineService.isActiveClass(this.injectionMoldingMachineList, injectionMold)
  }

  showRelationship(injectionMoldingMachineId): void {
    this.$localInjectionMoldingMachineId = localStorage.setItem('injectionMoldingMachineId', JSON.stringify(injectionMoldingMachineId));
    const dialogRef = this.dialog.open(InjectionMoldingMachineRelationshipComponent, {
      width: '450px'
    });
  }

  getmfgMoldsDetails(mfgMolds: any[]): string {
    let moldName: string = '';
    for (var i = 0; i < mfgMolds.length; i++) {
      moldName = moldName.concat(mfgMolds[i].moldName).concat(',');
    }
    return moldName.slice(0, -1);
  }

  getMoldList(list: MoldMaster[]): string {
    let injToolName: string = ''
    let toolNameList: any = []
    if (list.length != 0) {
      for (var i = 0; i < list.length; i++) {
        let moldList = list[i].moldList
        if (moldList != null && moldList.length != 0) {
          for (var j = 0; j < moldList.length; j++) {
            let finalToolList = moldList[j]

            //injToolName = injToolName.concat(finalToolList[j].injMoldName).concat(',');
            toolNameList.push(' ' + finalToolList.injMoldName)


          }
        }
      }
    }
    var filteredArray = toolNameList.filter(function (item, pos) {
      return toolNameList.indexOf(item) == pos;
    });

    return filteredArray
  }

  save() {
    let allowedMoldList: { id: number }[] = [];
    console.log("data is", typeof (this.allowedMolds))
    if (this.allowedMolds.value != undefined) {

      for (var val of this.allowedMolds.value) {
        allowedMoldList.push({ id: +val });

        this.injectionMoldingMachineConfig.allowedMolds = allowedMoldList

      }
    }
    //this.injectionMoldingMachineConfig.mfgconnectSiteId = this.plantId
    console.log("data is", this.injectionMoldingMachineConfig)

    if (this.injectionMoldingMachineConfig.id == undefined) {
      this.injectionMoldingMachineService.saveDeviceData(this.injectionMoldingMachineConfig).subscribe((data) => {
        console.log("data", data)
        this.onLoad();
        this.hideForm = true;
      });

    }
    else {
      this.injectionMoldingMachineService.updateDeviceData(this.injectionMoldingMachineConfig).subscribe(
        () => {
          console.log('updated Procell Cell')
          this.onLoad();
          this.hideForm = true;
        }
      )

    }
  }

  getAvailableMolds(value) {
    if (this.availableMoldList != null) {
      this.availableMoldList = []
    }
    if (this.injectionMoldingMachineConfig.mfgconnectToolId != null) {
      this.availableMoldList.push(this.injectionMoldingMachineConfig.mfgconnectToolDTO)
    }
    let ids: { id: number }[] = [];
    if (value != undefined) {
      if (value instanceof Array) {
        for (let i = 0; i < value.length; i++) {
          ids.push({ id: +value[i] })
        }
      }
    }
    if (ids.length != 0) {
      this.injectionMoldingMachineService.getAvailableMolds(this.plantId, ids).subscribe(resp => {
        console.log("available molds", resp)
        if (resp != null && resp instanceof Array) {
          for (let i = 0; i < resp.length; i++) {
            this.availableMoldList.push(resp[i])
          }
          //this.availableMoldList = resp
          this.moldMasterBoolean = true
        }
      });
    }
  }

  confirmDelete(id): void {
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.injectionMoldingMachineService.onMachineDelete(id).subscribe((resp) => {
          console.log("machine deleted", resp);
          this.onLoad();
        });
      }
    })



  }
}
