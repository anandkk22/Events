import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InjectionMoldingMachineComponent } from './injection-molding-machine.component';

describe('InjectionMoldingMachineComponent', () => {
  let component: InjectionMoldingMachineComponent;
  let fixture: ComponentFixture<InjectionMoldingMachineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InjectionMoldingMachineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InjectionMoldingMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
