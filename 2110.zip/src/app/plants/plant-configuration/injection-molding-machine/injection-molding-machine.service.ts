import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { MatDialog } from '@angular/material';
import { Observable, throwError } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { options } from '@amcharts/amcharts4/core';
import { InjectionMoldingMachineModel } from './injection-molding-machine.model'
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class InjectionMoldingMachineService {
  private currentMachine = new BehaviorSubject({});
  private paramData;
  private currentValue = new BehaviorSubject({});
  private currentParamValue = new BehaviorSubject({});
  private currentAlertValue = new BehaviorSubject({});

  updateMachineMessage = this.currentMachine.asObservable();
  updatedParameterMessage = this.currentParamValue.asObservable();
  updatedDeviceMessage = this.currentValue.asObservable();
  updatedAlertMessage = this.currentAlertValue.asObservable();

  constructor(private _http: HttpClient, public dialog: MatDialog) { }


  public getAllInjectionMoldingMachines(plantId: number): Observable<Object> {

    return this._http.get<InjectionMoldingMachineModel[]>(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine/get-by-plant/" + plantId);
  }

  public getMoldMasterData(): Observable<Object> {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine");
  }
  public saveDeviceData(data: any): Observable<Object> {

    return this._http.post(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine", data);
  }
  public onMachineDelete(id: any): Observable<Object> {

    //return this._http.delete(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine/" + id);
    return this._http.delete(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine/" + id, { responseType: 'text' })
      .pipe(catchError(this.handleError))

  }

  public updateDeviceData(data: any): Observable<Object> {

    return this._http.put(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine", data);

  }

  public getRelationship(id: number): Observable<Object> {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-inj-molding-machine/get-relationship/" + id);
  }

  public getDeviceStatus(id: any): Observable<Object> {

    return this._http.get(environment.SERVER_API_URL + "api/status/" + id);
  }

  public getInjMachineType(): Observable<Object> {
    return this._http.get(environment.CNC_API_URL + "api/inj-machine-type");
  }

  public getAvailableMolds(plantId: number, ids: any): Observable<Object> {

    return this._http.post(environment.CNC_API_URL + "api/mfgconnect-toolInjMold/get-available-mold/" + plantId, ids);
  }

  public changeMessage(device) {
    console.log("Device object: ", device);
    this.currentValue.next(device);
  }

  isActiveClass(componentList, currComponent) {
    componentList.forEach(element => {
      element.isActive = false;
    });
    currComponent.isActive = true;
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }
}
