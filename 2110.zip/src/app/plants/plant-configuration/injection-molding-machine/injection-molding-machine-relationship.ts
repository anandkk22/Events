import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { InjectionMoldingMachineService } from './injection-molding-machine.service';
//import { InjectionMoldService } from './injection-mold.service';
//import { CompressorsService } from './compressors.service';



@Component({
  selector: 'injection-molding-machine-relationship',
  templateUrl: './injection-molding-machine-relationship.html',
  styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class InjectionMoldingMachineRelationshipComponent implements OnInit, OnDestroy {
  private _id: number;
  getPlantId: any;
  getRelationship: any
  injectionMoldingMachineId: any;

  constructor(private _mdr: MatDialogRef<InjectionMoldingMachineRelationshipComponent>,
    private injectionMoldingMachineService: InjectionMoldingMachineService, private _route: ActivatedRoute) {

  }

  onNoClick(): void {
    this._mdr.close();
  }

  ngOnInit() {
    this.injectionMoldingMachineId = localStorage.getItem('injectionMoldingMachineId');
    this.onLoad();
  }

  onLoad() {
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this.injectionMoldingMachineService.getRelationship(this.injectionMoldingMachineId).subscribe(
        moldingMachine => {
          this.getRelationship = moldingMachine
        }
      )
    })
  }

  ngOnDestroy() {
    localStorage.removeItem('injectionMoldingMachineId');
  }

}
