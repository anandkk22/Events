import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PlantConfigurationService  {
    public url: string = "./assets/json/menuItems.json";
    constructor(private _http: HttpClient) { }


    getplantConfigDetails(): Observable<any> {
        return this._http.get<any>(this.url)
    }


    find(id: number){
        return id= 2;
    }

}