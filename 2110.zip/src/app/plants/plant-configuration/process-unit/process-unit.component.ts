import { OnInit, Component } from '@angular/core';
import { PidiliteUtilityPlant } from 'src/app/models/Pidilite-Plant.model';
import { ProcessUnitService } from './processUnit.service';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { DeletePlant } from '../../delete-plant/delete-plant';
import { RelationshipPlantComponent } from '../../relationship-plant/relationship-plant';
import { ActivatedRoute } from '@angular/router';
import { ProcessUnitModel } from './processUnit.model';
import { AllTimezoneService } from 'src/app/shared/timezone.service';
import { ProcessUnitRelationshipComponent } from './processunit-relationship';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

@Component({
    selector: 'process-unit',
    templateUrl: './process-unit.component.html',
    styleUrls: ['../plant-configuration.component.scss']
})
export class ProcessUnitComponent implements OnInit {
    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    plantConfigProcessUnitDetails: any[];
    processUnit: ProcessUnitModel;
    plantConfigProcessUnitDetail: any = {
        mfgconnectSiteId: '',
        pcId:''
    }
    maxDate: Date;
    orderbyKey: any;
    currentSearch: string;
    private _id: number;
    processUnits: any = [];
    getPlantId: any;
    hideForm: boolean = true;
    getProcessCellByIds: any;
    activityTypes: any;
    allTimezone: any;
    $localProcessUnitId: any;

    constructor(private _processUnitService: ProcessUnitService, public dialog: MatDialog, 
        private _route: ActivatedRoute, private _allTimzone: AllTimezoneService,
        private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.getPlantId = localStorage.getItem('plantId');
        this.plantConfigProcessUnitDetail.mfgconnectSiteId = this.getPlantId;
        this._processUnitService.getProcessUnitById(this.getPlantId).subscribe((resp) => {
            this.processUnits = resp;
            console.log("Area", this.processUnits);
        }); 
        this.plantConfigProcessUnitDetail = null;
        this.maxDate = new Date();
        this.orderbyKey = 'id';
        this.onLoad();
        this.getProcessCellById();        
        this.getActivityType();
        this.getTimezoneCountries();
    }

    getProcessCellById(){
        this._processUnitService.getProcessCellById(this.getPlantId).subscribe(
            processCell => {
                this.getProcessCellByIds = processCell
            }
        )
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._processUnitService.getListofProcessUnit(this.getPlantId).subscribe(
                processUnit => {
                    this.plantConfigProcessUnitDetails = processUnit
                }
            )
        })
    }

    getActivityType() {
        this._processUnitService.getActivityType().subscribe(
            activityType => {
                this.activityTypes = activityType
            })
    }

    applySortFilter(sortFilter) {
        if (this.plantConfigProcessUnitDetails) {
            if (sortFilter === 'id') {
                this.plantConfigProcessUnitDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = Number(a[sortFilter]);
                        const componentB = Number(b[sortFilter]);
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            } else {
                this.plantConfigProcessUnitDetails.sort(function (a, b) {
                    if (a[sortFilter] && b[sortFilter]) {
                        const componentA = a[sortFilter].toUpperCase();
                        const componentB = b[sortFilter].toUpperCase();
                        return componentA < componentB ? -1 : componentA > componentB ? 1 : 0;
                    }
                });
            }
        }
    }

    confirmDelete(id) {
        const dialogRef = this.dialog.open(DeletePlant, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._processUnitService.deleteProcessUnitById(id).subscribe((resp) => {
                    console.log("Process Unit deleted with id", resp);
                    () => this.onLoad()
                });               
            }
        })       
    }

    getTimezoneCountries() {
        this._allTimzone.getTimezoneCountries().subscribe(
            timezone => this.allTimezone = timezone
        );
    }
    

    showRelationship(getProcessUnitd): void {
        this.$localProcessUnitId = localStorage.setItem('ProcessUnitId', JSON.stringify(getProcessUnitd));
        const dialogRef = this.dialog.open(ProcessUnitRelationshipComponent, {
            width: '450px'
        });
    }

    details(id) {
        this.plantConfigProcessUnitDetails.forEach(proessCell => {
            if (proessCell.id === id) {
                this.plantConfigProcessUnitDetail = proessCell;
            }
            this.hideForm = true;
        });
    }

    addnew() {
        this.plantConfigProcessUnitDetail = {};        
        this.hideForm = true;
    }

    isActiveClass(processCell) {
        this._processUnitService.isActiveClass(this.plantConfigProcessUnitDetails, processCell)
    }


    save() {        
        if (this.plantConfigProcessUnitDetail.id == undefined ||  this.plantConfigProcessUnitDetail.id == null) {
            this.plantConfigProcessUnitDetail.plantId =  this.getPlantId;
            console.log("*****");
            console.log(this.plantConfigProcessUnitDetail)
            this._processUnitService.createNewProcessUnit(this.plantConfigProcessUnitDetail).subscribe((data) => {
           
                this.onLoad();
            });
            this.hideForm = false;
        }
        else {
            this._processUnitService.updateProcessUnit(this.plantConfigProcessUnitDetail).subscribe(() => {
                console.log('updated Area');
                this.onLoad();
            });
        }
        this.hideForm = false;
    }

    cancel() {
        this.plantConfigProcessUnitDetail = null;
        // this.getPlantConfigProcessUnitDetails();
    }
}