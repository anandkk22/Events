import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { ActivatedRoute } from '@angular/router';
import { ProcessUnitService } from './processUnit.service';


@Component({
    selector: 'processunit-relationship',
    templateUrl: './processunit-relationship.html',
    styleUrls: ['../../relationship-plant/relationship-plant.scss']
})
export class ProcessUnitRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getPlantId: any;
    getRelationship: any[];
    getProcessUnitId: any;

    constructor(private _mdr: MatDialogRef<ProcessUnitRelationshipComponent>, 
        private _processUnitService: ProcessUnitService, private _route: ActivatedRoute ) {

    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnInit(){
        this.getProcessUnitId = localStorage.getItem('ProcessUnitId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._processUnitService.getRelationship(this.getProcessUnitId).subscribe(
                processUnit => {
                    this.getRelationship = processUnit
                }
            )
        })
    }

    ngOnDestroy() {
        localStorage.removeItem('ProcessUnitId');
    }

}
