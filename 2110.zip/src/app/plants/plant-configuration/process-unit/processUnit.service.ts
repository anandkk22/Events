import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ProcessUnitModel } from './processUnit.model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ProcessUnitService {
    public listofProcessUnit: string = environment.PROCESS_API_URL + 'api/processunit/plant'; 
    public getprocessUnit: string = environment.PROCESS_API_URL + 'api/processunit';
    public addUpdateProcessUnit: string = environment.PROCESS_API_URL + 'api/processunit';
    public deleteProcessUnit: string = environment.PROCESS_API_URL + 'api/processunit';
    public listofprocessCell: string = environment.PROCESS_API_URL + 'api/processcell/plant'; 
    public activityType: string = environment.PROCESS_API_URL + 'api/activityType';
    public relationship: string = environment.PROCESS_API_URL + 'api/processunit/rel';
   
    constructor(private _http: HttpClient) { }

    getListofProcessUnit(id: number): Observable<ProcessUnitModel[]> {
        return this._http.get<ProcessUnitModel[]>(`${this.listofProcessUnit}/${id}`)
    }

    getProcessUnitById(id: number): Observable<ProcessUnitModel> {
        return this._http.get<ProcessUnitModel>(`${this.getprocessUnit}/${id}`)
    }

    createNewProcessUnit(processUnit: ProcessUnitModel): Observable<any> {
        return this._http.post<any>(`${this.addUpdateProcessUnit}`, processUnit, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateProcessUnit(processUnit: ProcessUnitModel): Observable<void> {
        return this._http.put<void>(`${this.addUpdateProcessUnit}`, processUnit, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteProcessUnitById(id: number) {
        return this._http.delete(this.deleteProcessUnit+"/"+ id, {responseType: 'text'})
        .pipe(catchError(this.handleError))
    }

    getProcessCellById(id: number){
        return this._http.get<any[]>(`${this.listofprocessCell}/${id}`)
    }

    getActivityType(): Observable<any[]> {
        return this._http.get<any[]>(this.activityType)
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);       
        }         
        return throwError(errorMessage);      
    }
}