export class ProcessUnitModel {
    id?: number;
    name?: string;
    description?: string;
    activity?: string;
    timezone?: any;
    pcId?: number;
    lastUpdated?: Date;
}