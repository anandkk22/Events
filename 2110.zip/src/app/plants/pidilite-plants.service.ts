import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { pidiliteMainModel } from '../models/pidilite-model';
import { environment } from '../../environments/environment';
import { CustomerTypeModel } from '../models/customerType.model';
import { segmentModel } from '../models/segment.model';
import { subSiteTypeModel } from '../models/subSiteTypeModel';
import { subSegmentModel } from '../models/subSegmentModel';
import { customerType } from '../models/customerTypeModel';
import { OrgTypeModel } from '../models/orgTypeModel';
import { IndustrySegment, IndustryType } from '../models/industry.model';
import { BreakModel, ShiftModel } from './add-plant/shiftandbreak.model';

@Injectable({ providedIn: 'root' })
export class PidilitePlantsService {

  public planturl: string = environment.CNC_API_URL + 'api/plant';
  public listofPlantUrl: string = environment.CNC_API_URL + 'api/plant/org/3';
  public deletePlantUrl: string = environment.CNC_API_URL + 'api/plant';
  public addPlantUrl: string = environment.CNC_API_URL + 'api/plant';
  public segmentUlr: string = environment.PROCESS_API_URL + 'api/segment';
  // public subSegmentUlr: string = environment.PROCESS_API_URL + 'api/subsegment';
  // public subSiteTypeUlr: string = environment.PROCESS_API_URL + 'api/SubSiteType';
  // public customerTypeUlr: string = environment.PROCESS_API_URL + 'api/customerType';
  // public orgTypeUrl: string = environment.PROCESS_API_URL + 'api/org/type/';
  public getPlantAssetUrl: string = environment.CNC_API_URL + 'api/plant/asset';
  public industryType: string = environment.CNC_API_URL + 'api/industryType';
  public industrySegment: string = environment.CNC_API_URL + 'api/industrySegment/';
  public shift: string = environment.CNC_API_URL + 'api/mfgconnect-shift-occurance';
  public break: string = environment.CNC_API_URL + 'api/mfgconnect-shift-break';
  public shiftBreaksByPlaneId: string = environment.CNC_API_URL + 'api/mfgconnect-shift-occurance/get-by-plant';

  constructor(private _http: HttpClient) { }

  getPlantById(id: number): Observable<pidiliteMainModel> {
    return this._http.get<pidiliteMainModel>(`${this.planturl}/${id}`);
  }

  getListofPlant(): Observable<pidiliteMainModel[]> {
    return this._http.get<pidiliteMainModel[]>(this.listofPlantUrl)
  }

  addPlant(plant: pidiliteMainModel): Observable<pidiliteMainModel> {
    return this._http.post<pidiliteMainModel>(`${this.addPlantUrl}`, plant, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  getListofIndustryType(): Observable<IndustryType[]> {
    return this._http.get<IndustryType[]>(this.industryType)
  }

  getListofIndustrySegment(): Observable<IndustrySegment[]> {
    return this._http.get<IndustrySegment[]>(this.industrySegment)
  }

  getShiftandBreakPlantById(id: number): Observable<any[]> {
    return this._http.get<any[]>(`${this.shiftBreaksByPlaneId}/${id}`);
  }



  updatePlant(plant: pidiliteMainModel): Observable<void> {
    return this._http.put<void>(`${this.addPlantUrl}`, plant, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  deletePlant(id: number): Observable<void> {
    return this._http.delete<void>(`${this.deletePlantUrl}/${id}`)
      .pipe(catchError(this.handleError))
  }

  getSegments(): Observable<segmentModel[]> {
    return this._http.get<segmentModel[]>(this.segmentUlr);
  }

  getPlantAssetDetails(id: number): Observable<any> {
    return this._http.get<any>(`${this.getPlantAssetUrl}/${id}`)
  }

  getListofShifts(): Observable<ShiftModel[]> {
    return this._http.get<ShiftModel[]>(this.shift);
  }

  createShifts(shift: any): Observable<any> {
    return this._http.post<any>(`${this.shift}`, shift, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateShifts(shift: ShiftModel): Observable<void> {
    return this._http.put<void>(`${this.shift}`, shift, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateBreak(b: ShiftModel): Observable<void> {
    return this._http.put<void>(`${this.break}`, b, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  getShiftById(id): Observable<ShiftModel> {
    return this._http.get<ShiftModel>(this.shift + '/' + id)
  }

  deleteShift(id: number): Observable<void> {
    return this._http.delete<void>(`${this.shift}/${id}`)
      .pipe(catchError(this.handleError))
  }

  getListofBreaks(): Observable<BreakModel[]> {
    return this._http.get<BreakModel[]>(this.break);
  }

  createBreak(b: BreakModel): Observable<BreakModel> {
    return this._http.post<BreakModel>(`${this.break}`, b, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  getBreakById(id): Observable<BreakModel> {
    return this._http.get<BreakModel>(this.break + '/' + id)
  }

  deleteBreak(id: number): Observable<void> {
    return this._http.delete<void>(`${this.break}/${id}`)
      .pipe(catchError(this.handleError))
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }
}
