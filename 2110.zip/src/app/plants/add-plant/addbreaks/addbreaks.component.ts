import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, Validators, FormArray } from '@angular/forms';
import { BreakModel, ShiftModel } from '../shiftandbreak.model';
import { PidilitePlantsService } from '../../pidilite-plants.service';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';
import { ActivatedRoute} from '@angular/router';

@Component({
    selector: 'add-breaks',
    templateUrl: 'addbreaks-component.html',
    styleUrls: ['addbreaks-component.scss']

})
export class AddBreaks implements OnInit {
    breakObj: BreakModel;
    listofShiftandBreaks: any[];
    public mainForm: {
        formFields: BreakModel[];
    };

    constructor(public dialogRef: MatDialogRef<AddBreaks>,
        private _pidilitePlantsService: PidilitePlantsService,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _route: ActivatedRoute,) { }


    ngOnInit() {
        console.log(this.data.id);
        this.breakObj = {
            id:null,
            breakName: '',
            breakStartTime: '',
            breakEndTime: '',
            mfgconnectShiftId: null
        };
        this._pidilitePlantsService.getShiftandBreakPlantById(this.data.plantId).subscribe(
            data => {
                this.listofShiftandBreaks = data;
                console.log(this.listofShiftandBreaks);
            }
        );
        if(this.data.id !== 0) {
            console.log('in if');
            this.getBreakById(this.data.id);
        }
        this.mainForm = {
            formFields: [],
        };
        this.addForm();
        
    }

    public addForm(): void {
        this.mainForm.formFields.push({
            id:null,
            breakName: '',
            breakStartTime: '',
            breakEndTime: '',
            mfgconnectShiftId: null,
        });
    }

    public submitForm(form) {
        if (form.valid) {
            console.log(form.value);
        }
    }

    save(form: any) {
        if(this.data.id === 0) {
            this._pidilitePlantsService.createBreak(this.breakObj).subscribe(
                (data) => {
                    console.log(data);
                    this.dialogRef.close();
                },
                (error: any) => {
                    console.log(error);
                }
            );
        } else {
            this._pidilitePlantsService.updateBreak(this.breakObj).subscribe(
                () => {
                    console.log('updated');
                    this.dialogRef.close();
                }
            )
        }
        
    }

    getBreakById(breakId) {
        this._pidilitePlantsService.getBreakById(breakId).subscribe(res => {
                console.log(res);
                this.breakObj = res;
                console.log(this.breakObj);
            },
            (error: any) => console.log(error)
        );
    }
    onNoClick(): void {
        this.dialogRef.close('cancel');
    }

}
