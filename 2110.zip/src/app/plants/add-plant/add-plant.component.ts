import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { PidiliteUtilityPlant } from '../../models/Pidilite-Plant.model';
import { Router, ActivatedRoute } from '@angular/router';
import { RelatedOrganizationService } from './related-organizations/related-organization.service';
import { Organisations } from './related-organizations/organizations';
import { OrganisationIdandType } from './related-organizations/orgnisationIdandName';
import { PidilitePlantsService } from '../pidilite-plants.service';
import { PlantType } from 'src/app/models/plant-type.model';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';
import { AllCountriesService } from 'src/app/shared/allCountries.service';
import { AllTimezoneService } from 'src/app/shared/timezone.service';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MatStepper, MAT_DIALOG_DATA } from '@angular/material';
import { AddShift } from './addshift/addshift-component';
import { AddBreaks } from './addbreaks/addbreaks.component';
import { IndustrySegment, IndustryType } from 'src/app/models/industry.model';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-add-plant',
  templateUrl: './add-plant.component.html',
  styleUrls: ['./add-plant.component.scss']
})
export class AddPlantComponent implements OnInit {
  @ViewChild('firstForm', { static: false }) public firstFormName: NgForm;
  @ViewChild('secondForm', { static: false }) public secondFormName: NgForm;
  @ViewChild('thirdForm', { static: false }) public thirdFormName: NgForm;
  submitted: boolean = false;
  requiredField: string;
  pidiliteUtilityPlant: PidiliteUtilityPlant;
  isSaving: boolean;
  pidiliteUtilityPlantOrgRel = [];
  plantPolicyList: any = [
    { id: 1, name: 'FDA' },
    { id: 2, name: 'DNCP' },
  ]
  segments: any;
  subSiteTypes: any;
  subsSegments: any;
  customerType: any;
  orgTypes: any;
  countries = [];
  states = [];
  timezones = [];
  currencies = [];
  org_type = '';
  org_id = '';
  orgList: any;
  maxDate: Date;
  isDevOrg: boolean;
  orgErr = '';
  saveSuccess = false;
  saveError = false;
  responseStatus: { error: boolean; message: any };
  title: String;
  selectedSegment: number;
  allCountries: any;
  allTimezone: any;
  allCurrency: any;
  plant: pidiliteMainModel;
  industryType: IndustryType[];
  indstrySegment: IndustrySegment[];
  private _id: number;
  listofShiftandBreaks: any[];
  plantSchedule: boolean = false;
  isLinear = true;
  isFormCompleted = false;
  result: string = '';

  constructor(
    private _router: Router,
    private _relOrgServide: RelatedOrganizationService,
    private _route: ActivatedRoute,
    private _plantService: PidilitePlantsService,
    private _allCountries: AllCountriesService,
    private _allTimzone: AllTimezoneService,
    public dialog: MatDialog,) { }

  selectedorganizations: Organisations = new Organisations(null, '');
  organizations: Organisations[];
  organizationIdandName: OrganisationIdandType[];

  ngOnInit() {
    this.subsSegments = "0"
    this.subSiteTypes = "0"
    this.plant = new pidiliteMainModel;
    this.allCurrency = [{ id: 1, currency: 'INR' }, { id: 2, currency: 'USD' }]
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
      this.getPlant(id);
    })
    this.maxDate = new Date();
    this.currencies = [
      { code: 'INR', icon: 'fa fa-rupee-sign', unicode: String.fromCharCode(0xf156) },
      { code: 'USD', icon: 'fa fa-dollar-sign', unicode: String.fromCharCode(0xf155) }
    ];
    this.organizations = this._relOrgServide.getOrganizations();
 
    this.getAllCountries();
    this.getTimezoneCountries();
    this.getListofIndustryType();
  }

  getAllCountries() {
    this._allCountries.getAllCountries().subscribe(
      country => this.allCountries = country
    );
  }

  getTimezoneCountries() {
    this._allTimzone.getTimezoneCountries().subscribe(
      tiemzone => this.allTimezone = tiemzone
    );
  }

  getListofIndustryType() {
    this._plantService.getListofIndustryType().subscribe(
      data => this.industryType = data
    );
  }

  getListofIndustrySegment() {
    this._plantService.getListofIndustrySegment().subscribe(
      data => this.indstrySegment = data
    );
    console.log(this.indstrySegment);
  }

  save() {
    this._router.navigate(['/plants']);
  }

  cancel() {
    this._router.navigate(['/plants'])
  }

  private getPlant(id: number) {
    if (id === 0) {
      this.isFormCompleted = false;
      this.plant = {
        responseMessage: null,
        orgId: 3,
      };
      this.title = "Add New";
    } else {
      this.isFormCompleted = true;
      this.title = "Edit";
      this._plantService.getPlantById(id).subscribe(
        (plant) => {
          this.plant = plant;
          console.log(this.plant);
          this.onIndstryTypeSelect(this.plant.industry);
          this.getShiftsAndBreaks(id);
          
        },
        (err: any) => console.log(err)
      )
    }
  }

  public saveLocationandDetails(stepper: MatStepper): void {    
    this.submitted = true;
    this.isFormCompleted = true;
    this.plantSchedule = true;
    if (this.firstFormName.invalid || this.secondFormName.invalid) {
      this.requiredField = "Required fields are missing, Please check";
      return
    } else {      
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        maxWidth: "400px"
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result === 'save') {
          if (this.plant.id == null) {         
            this.plant.orgId = 3;

            let userId = localStorage.getItem('userId');
            this.plant.userId = userId;

            this._plantService.addPlant(this.plant).subscribe(
              (data: any) => {
                this.plant.id = data.id;

                localStorage.setItem('localPlantId', JSON.stringify(data.id));
                console.log(localStorage.getItem('localPlantId'));

                stepper.next();
              });
          } else {
            console.log("plantid", this.plant.id);                         
            this._plantService.updatePlant(this.plant).subscribe(
              () => {
                // this._router.navigate(['/plants'])
                stepper.next();
              });
          }
          
        }
      });    
    }
  }

  onIndstryTypeSelect(industryCode){
    this._plantService.getListofIndustrySegment().subscribe(data => {
      this.indstrySegment = data.filter(item => item.industryTypeCode == industryCode);
    });
  }

  addShift() {
    const dialogRef = this.dialog.open(AddShift, {
      width: '500px',
      data: {id: 0, plantId: this.plant.id}
    });
    dialogRef.afterClosed().subscribe(res => {
      if(res !== 'cancel') {
        this.getShiftsAndBreaks(this.plant.id);
      }
    });
  }
  
  editShift(shiftId) {
    const dialogRef = this.dialog.open(AddShift, {
      width: '500px',
      data: {id: shiftId, plantId: this.plant.id}
    });
    dialogRef.afterClosed().subscribe(res => {
      if(res !== 'cancel') {
        this.getShiftsAndBreaks(this.plant.id);
      }
    });
  }

  deleteShift(shiftId) {
    const dialogRef = this.dialog.open(DeleteConfirmOnPlantScreen, {
      width: '500px',
      data: {type: 'Shift', id: shiftId}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._plantService.deleteShift(shiftId).subscribe(data => {
          console.log(data);
          this.getShiftsAndBreaks(this.plant.id);
        }, err => {
          console.log(err);
        });
      }
    });
  }

  addBreak() {
    const dialogRef = this.dialog.open(AddBreaks, {
      width: '500px',
      data: {id: 0, plantId: this.plant.id}
    });
    dialogRef.afterClosed().subscribe(res => {
      if(res !== 'cancel') {
        this.getShiftsAndBreaks(this.plant.id);
      }
    });
  }

  editBreak(breakId) {
    const dialogRef = this.dialog.open(AddBreaks, {
      width: '500px',
      data: {id: breakId, plantId: this.plant.id}
    });
    dialogRef.afterClosed().subscribe(res => {
      if(res !== 'cancel') {
        this.getShiftsAndBreaks(this.plant.id);
      }
    });
  }

  deleteBreak(breakId) {
    const dialogRef = this.dialog.open(DeleteConfirmOnPlantScreen, {
      width: '500px',
      data: {type: 'Break', id: breakId}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._plantService.deleteBreak(breakId).subscribe(data => {
          console.log(data);
          this.getShiftsAndBreaks(this.plant.id);
        }, err => {
          console.log(err);
        });
      }
    });
  }

  getShiftsAndBreaks(id) {
    this._plantService.getShiftandBreakPlantById(id).subscribe(
      data => this.listofShiftandBreaks = data
    );
  }
}


@Component({
  selector: 'app-delete-popup-plant-screen',
  templateUrl: './delete-confirmation-plant-screen.html',

})
export class DeleteConfirmOnPlantScreen {
  constructor(public dialogRef: MatDialogRef<DeleteConfirmOnPlantScreen>, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    component_type = this.data.type;
    CloseDialog() {
      this.dialogRef.close(false);
    }
}
