import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { PidilitePlantsService } from '../../pidilite-plants.service';
import { ShiftModel } from '../shiftandbreak.model';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';

@Component({
    selector: 'add-shift',
    templateUrl: 'addshift-component.html',
    styleUrls: ['addshift-component.scss']

})
export class AddShift implements OnInit {
    plantId = this.data.plantId;
    shifById: ShiftModel = {
        id: null,
        shiftName: '',
        shiftStartTime: '',
        shiftEndTime: '',
        mfgconnectSiteId: null
    };
    public form: {
        shift: ShiftModel[];
    };

    shift: any = {
        mfgconnectSiteId: '',
        id: ''
    }

    constructor(public dialogRef: MatDialogRef<AddShift>,
        private _pidilitePlantsService: PidilitePlantsService,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private _route: ActivatedRoute,) {
        this.form = {
            shift: []
        };
        this.addShift();
    }

    ngOnInit() {
        console.log(this.data);
        if(this.data.id !== 0) {
            this.getShiftById(this.data.id);
        }
    }

    public addShift(): void {
        this.form.shift.push({
            id: 0,
            shiftName: '',
            shiftStartTime: '',
            shiftEndTime: '',
        });
    }

    public saveForm(form: any): void {
        console.log(this.shifById);
        if (this.data.id === 0) {
            this.shifById.mfgconnectSiteId = this.data.plantId;
            this._pidilitePlantsService.createShifts(this.shifById).subscribe(
                (data: any) => {
                    console.log(data)
                }
            )
            this.dialogRef.close();
        } else {
            this.shifById.mfgconnectSiteId = this.data.plantId;
            this._pidilitePlantsService.updateShifts(this.shifById).subscribe(
                (data) => {
                    this.dialogRef.close();
                }
              )
        }
    }

    getShiftById(id){
        this._pidilitePlantsService.getShiftById(id).subscribe(
            data => this.shifById = data
        )
    }

    onNoClick(): void {
        this.dialogRef.close('cancel');
    }
}
