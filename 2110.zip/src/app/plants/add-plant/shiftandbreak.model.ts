export class ShiftModel {
    id?: number;
    shiftStartTime?: string;
    shiftEndTime?: string;
    shiftName?: string;
    mfgconnectSiteId?: number;
}


export class BreakModel {
    id?: number;
    breakName?: string;
    breakStartTime?: string;
    breakEndTime?: string;
    mfgconnectShiftId?: number;
}