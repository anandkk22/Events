import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Organisations } from './organizations';
import { OrganisationIdandType } from './orgnisationIdandName';


@Injectable({ providedIn: 'root' })
export class RelatedOrganizationService {
    public url: string = "./assets/json/related-organization.json";
    constructor(private _http: HttpClient) { }


    getRelatedOrgnizationDetails(): Observable<any> {
        return this._http.get<any>(this.url)
    }

    getOrganizations() {
        return [
            new Organisations(1, 'OEM'),
            new Organisations(2, 'OEC'),
            new Organisations(3, 'LDC')
            
        ];
    }

    getOrganizationIdandName() {
        return [
            new OrganisationIdandType(1, 1, 'Seimens'),
            new OrganisationIdandType(2, 1, 'Delta Electronics'),
            new OrganisationIdandType(3, 1, 'Renesola'),
            new OrganisationIdandType(4, 2, 'Vikram Solar'),
            new OrganisationIdandType(5, 2, 'Sungrow India'),
        ];
    }

}