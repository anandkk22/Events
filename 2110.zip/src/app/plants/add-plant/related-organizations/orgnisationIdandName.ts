export class OrganisationIdandType {
    constructor(public org_id: number, public orgId: number, public name: string) { }
}