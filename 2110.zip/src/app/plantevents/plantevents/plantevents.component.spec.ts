import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanteventsComponent } from './plantevents.component';

describe('PlanteventsComponent', () => {
  let component: PlanteventsComponent;
  let fixture: ComponentFixture<PlanteventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanteventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanteventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
