import { TestBed } from '@angular/core/testing';

import { PlanteventsService } from './plantevents.service';

describe('PlanteventsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlanteventsService = TestBed.get(PlanteventsService);
    expect(service).toBeTruthy();
  });
});
