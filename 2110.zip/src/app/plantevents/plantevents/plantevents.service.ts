import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PlanteventsService {

  public apiUrl = environment.PROCESS_API_URL + 'api/';
  public cncUrl = environment.CNC_API_URL + 'api/';

  public url: string = "./assets/json/";

  constructor(private http: HttpClient) { }

  getPlant(): Observable<any> {
    return this.http.get<any>(this.apiUrl + "plant/65");
  }

  getEvents(): Observable<any> {
    return this.http.get<any>(this.apiUrl + "events");
  }

  getEventsByEquipmentType(type): Observable<any> {
    return this.http.get<any>(this.apiUrl + "events/" + type);
  }

  getEquipmentType(): Observable<any> {
    return this.http.get<any>(this.apiUrl + "eqipType");
  }
}
