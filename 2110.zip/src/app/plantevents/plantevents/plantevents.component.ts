import { Component, OnInit, OnDestroy, Inject, NgZone } from '@angular/core';

import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTabChangeEvent, MatDatepickerInputEvent } from '@angular/material';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import { NgxSpinnerService } from 'ngx-spinner';
am4core.useTheme(am4themes_animated);
import * as moment from 'moment';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { LocalStorageService } from 'ngx-webstorage';
import { FormControl } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { faUnderline } from '@fortawesome/free-solid-svg-icons';
import { Equipments } from 'src/app/product-configurator/mold-master/mold-master.model';
import { PlanteventsService } from './plantevents.service';
am4core.useTheme(am4themes_animated);

@Component({
  selector: 'app-plantevents',
  templateUrl: './plantevents.component.html',
  styleUrls: ['./plantevents.component.scss']
})
export class PlanteventsComponent implements OnInit {

  severity = ['All', 'Insignificant', 'Low', 'Medium', 'High', 'Critical'];

  equipments = ['Pump', 'Reactor', 'Compressor', 'Agitator', 'Centrifuge'];

  orders = ['Latest First', 'Earliest First'];

  resolutions = ['Year', 'Month', 'Day'];

  categories = ['All', 'General', 'Financial']

  plantEventOccurenceListingData: any;
  public plant: any;
  public events: any;
  public equipmentTypes: any;
  public pumpEvents: any;
  public reactorEvents: any;
  public compressorEvents: any;
  public agitatorEvents: any;
  public centrifugeEvents: any;
  public resolution: any;

  constructor(private spinner: NgxSpinnerService,
    public dialog: MatDialog,
    private service: PlanteventsService
  ) { }

  ngOnInit() {

    this.service.getPlant().subscribe((resp) => {
      this.plant = resp;
      console.log("bred crumb", this.plant);
    });

    this.service.getEvents().subscribe((resp) => {
      this.plantEventOccurenceListingData = resp;
      console.log("events", this.plantEventOccurenceListingData);

      this.pumpEvents = this.plantEventOccurenceListingData.filter(data => data.equipmentTypeName == "pump");

      this.reactorEvents = this.plantEventOccurenceListingData.filter(data => data.equipmentTypeName == "reactor");

      this.compressorEvents = this.plantEventOccurenceListingData.filter(data => data.equipmentTypeName == "compressor");

      this.agitatorEvents = this.plantEventOccurenceListingData.filter(data => data.equipmentTypeName == "agitator");

      this.centrifugeEvents = this.plantEventOccurenceListingData.filter(data => data.equipmentTypeName == "centrifuge");

    });
    this.service.getEquipmentType().subscribe((resp) => {
      this.equipmentTypes = resp;
      console.log("bred crumb", this.equipmentTypes);
    });



    for (let i = 0; i < this.equipments.length; i++) {
      setTimeout(() => this.constructDonutChart(`chartdiv_${i}`, 30), 1000);
      console.log("lll", `chartdiv_${i}`);
    }

  }

  minus_plus_icon_toggle(id) {
    const element = document.getElementById('minus-image-' + id);
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-' + id);
    element2.classList.toggle('d-none');
  }

  openEventsDetailPopup(data) {
    // const req_obj = {
    //   plantId: data.plantId,
    //   instanceType, // data.instanceType,
    //   instanceId: data.instanceId,
    //   eventCode: data.eventCode,
    //   category: data.category,
    //   stateCode: 'ON',
    //   severity: data.severity,
    //   fromDate: data && data.firstTs != null ? data.firstTs.split('T')[0] : null,
    //   fromTime: data && data.firstTs != null ? data.firstTs.split('T')[1] : null,
    //   toDate: data && data.lastTs != null ? data.lastTs.split('T')[0] : null,
    //   toTime: data && data.lastTs != null ? data.lastTs.split('T')[1] : null
    // };
    this.getEventDetails(data);
  }

  getEventDetails(data) {
    // this.spinner.show();
    // this.plantevents.getPlantEventData(req_obj).subscribe(
    //     resp => {
    //         this.spinner.hide();
    //         const rel_data = [];
    //         rel_data['eventDetails'] = resp.body;
    //         rel_data['eventSeverity'] = this.eventSeverity;
    let dialogRefNotifi = this.dialog.open(PlanteventsDetailedEventAnalysisHistoricalViewPopupComponent, {
      panelClass: 'dark-theme-dialog-container-event-analytics',
      autoFocus: false,
      data: data
    });
    dialogRefNotifi.afterClosed().subscribe(result => {
      dialogRefNotifi = null;
    });
    // },
    err => {
      // this.spinner.hide();
    }
    // );
  }

  constructDonutChart(chartName, chartData, ) {
    let chart = am4core.create(chartName, am4charts.PieChart);
    chart.logo.disabled = true;
    chart.data = [{
      "label": "High",
      "value": 40
    }, {
      "label": "Low",
      "value": 60
    }];;
    // Set inner radius
    chart.innerRadius = am4core.percent(38);
    chart.fontSize = 11;
    // Add and configure Series
    const pieSeries = chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = 'value';
    pieSeries.dataFields.category = 'label';
    pieSeries.slices.template.propertyFields.fill = 'color';

    pieSeries.slices.template.strokeWidth = 1;
    pieSeries.slices.template.strokeOpacity = 1;
    pieSeries.slices.template.tooltipHTML = `<span>{category}: <strong>{value}% </strong></span><br/> <span>Count: <strong>{tooltipCount}</strong></span>`;
    pieSeries.alignLabels = false;
    pieSeries.labels.template.fontSize = 11;
    /* tslint:disable */
    pieSeries.labels.template.text = "{value.percent.formatNumber('#.0')}% {count}";
    pieSeries.labels.template.radius = am4core.percent(-23);
    pieSeries.labels.template.fill = am4core.color('#000');
    /* tslint:enable */


    pieSeries.hiddenState.properties.opacity = 1;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;
  }

}

/* plantevents -> Detailed Event Analysis (Historical View) popup dialogue */
@Component({
  selector: 'jhi-dialogue-detailed-event-analysis-historical-view',
  templateUrl: 'dialogue-detailed-event-analysis-historical-view.component.html',
  styleUrls: ['dialogue-detailed-event-analysis-historical-view.scss']
})
export class PlanteventsDetailedEventAnalysisHistoricalViewPopupComponent implements OnInit {
  private chartData: am4charts.XYChart;
  private timer: Observable<any>;
  eventSubscriber: Subscription;
  public eventDetails: any;
  // public accountInfo: User;
  public isManager: boolean;
  public isHistorical: boolean;
  actionItems: any;
  result_data = [];
  chartErr = '';
  chartError = [];
  AIReadPermission;
  AIWritePermission;
  chart: any;
  slaList: any;
  statusList: any;
  severityList: any;
  i: any; // considered as index of chart div

  constructor(
    public dialogRef: MatDialogRef<PlanteventsDetailedEventAnalysisHistoricalViewPopupComponent>,
    private zone: NgZone,
    public dialog: MatDialog,
    private spinner: NgxSpinnerService,
    private $localStorage: LocalStorageService,
    @Inject(MAT_DIALOG_DATA) public data
  ) { }

  ngOnInit() {
    this.i = 0;
    this.chartErr = '';
    this.result_data = [];
    this.eventDetails = this.data;
    this.result_data = this.eventDetails.eventPlotOutputList ? this.eventDetails.eventPlotOutputList : null;
    if (!this.isHistorical) {
      // this.setDuration();
    }
    // this.spinner.show();
    // this.eventSubscriber = this.timer.subscribe(() => {
    //   this.spinner.hide();
    //   if (this.result_data !== null) {
    //     this.setChart();
    //   }
    // });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }


  fetchActionItemsByEventDetails() {
    const criteria = {
      // plantId: this.eventDetails.plantId,
      // instanceId: this.eventDetails.instanceId,
      // instanceType: this.eventDetails.instanceType,
      // eventCode: this.eventDetails.eventCode,
      // date: this.eventDetails.firstTs.split('T')[0],
      // time: this.eventDetails.firstTs.split('T')[1]
    };


  }

  // getActionItemCommentDetails(index) {
  //   this.dialog.open(DialogActionItemCommentDetailsPopupComponent, {
  //     panelClass: 'dark-theme-dialog-container-action-item-creation',
  //     backdropClass: 'backdrop-background',
  //     autoFocus: false,
  //     data: this.actionItems[index]
  //   });
  // }

  // getActionItemImageDetails(index) {
  //   this.dialog.open(DialogActionItemImageDetailsPopupComponent, {
  //     panelClass: 'dark-theme-dialog-container-action-item-creation',
  //     backdropClass: 'backdrop-background',
  //     autoFocus: false,
  //     data: this.actionItems[index]
  //   });
  // }

  // createActionItem() {
  //   if (this.AIWritePermission) {
  //     const dialogRef = this.dialog.open(DialogCreateActionItemPopupComponent, {
  //       panelClass: 'dark-theme-dialog-container-action-item-creation',
  //       backdropClass: 'backdrop-background',
  //       autoFocus: false,
  //       data: this.eventDetails
  //     });

  //     dialogRef.afterClosed().subscribe(result => {
  //       if (result !== '') {
  //         this.fetchActionItemsByEventDetails();
  //       }
  //     });
  //   } else {
  //     this.accessibilityService.openSnackBar();
  //   }
  // }

  getEventCategory(defaultEventSeverity) {
    this.data.eventSeverity.forEach(element => {
      if (element.first === defaultEventSeverity) {
        return element.second;
      }
    });
  }





}


