import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { ScheduleService } from "./schedule.service";
import { Router } from "@angular/router";
import { TreeComponent, ITreeState, IActionMapping, TREE_ACTIONS, TreeNode, TreeModel } from 'angular-tree-component';
import * as moment from 'moment';
/* Imports */

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: "app-schedule",
  templateUrl: "./schedule.component.html",
  styleUrls: ["./schedule.component.scss"],
})
export class ScheduleComponent implements OnInit {
  miniPopupWidth = '250px';
  mPopupWidth = '450px';
  lPopupWidth = '650px';
  xlPopupWidth = '850px';

  customers: any;
  products: any;
  productsRaw: any;
  productList: any;

  selectedCustId = 0;
  selectedProdId = 0; 
  selectedCustName = '';

  months = [];
  weeks = [];
  allMondays = [];
  allMondaysMonthly = [];

  demandWeekSchedule = [];
  targetWeeklySchedule = [];
  componentWeeklySchedule = [];

  dsch = false;
  tsch = false;
  csch = false;

  selectedDemand = 0;
  selectedTarget = 0;

  state: ITreeState;
  productDemandMapping:IActionMapping = {
		mouse: {
			click: (tree, node, $event) => {
        $event.preventDefault();
        // this.getScheduleDetails(tree, node, $event);
      },
      expanderClick: (tree, node, $event) => {
        $event.preventDefault();
        this.getScheduleDetails(tree, node, $event);
      }
		}
	};
	options = {
		useCheckbox: false,
    useTriState: false,
    actionMapping: this.productDemandMapping
  }
  sentForApproval = false;
  sentForSchedule = false;

  constructor(
    private service: ScheduleService, 
    private matDialog: MatDialog,
    private _router: Router) {}

  ngOnInit() {
    this.getProductData();
    this.getFiscalMonths();
    this.addProduct();
  }

  getProductData() {
    this.customers = [ 
      { id: 1, name: 'Ferrero' }, 
      { id: 1, name: 'Hamleys' } 
    ];

    this.productsRaw = [
      { id: 1, name: 'Rochere', custId: 1},
      { id: 2, name: 'Kinder Joy', custId: 1},
      { id: 3, name: 'Kinder Wonder', custId: 1},
      { id: 4, name: 'Wonder Bar', custId: 2},
      { id: 5, name: 'Aqua Jelly', custId: 2}
    ];

    this.productList = [];
  }
  
  getFiscalMonths() {
    // call api to get all months from certain fiscal year
    this.months = [
      { monthNumber: 4, monthName: 'Apr', year: 2020 },
      { monthNumber: 5, monthName: 'May', year: 2020 },
      { monthNumber: 6, monthName: 'Jun', year: 2020 },
      { monthNumber: 7, monthName: 'Jul', year: 2020 },
      { monthNumber: 8, monthName: 'Aug', year: 2020 },
      { monthNumber: 9, monthName: 'Sep', year: 2020 },
      { monthNumber: 10, monthName: 'Oct', year: 2020 },
      { monthNumber: 11, monthName: 'Nov', year: 2020 },
      { monthNumber: 12, monthName: 'Dec', year: 2020 },
      { monthNumber: 1, monthName: 'Jan', year: 2021 },
      { monthNumber: 2, monthName: 'Feb', year: 2021 },
      { monthNumber: 3, monthName: 'Mar', year: 2021 }
    ];
    let weekCount = 0;
    this.months.forEach(month => {
      const monthNumber =  month.monthNumber - 1;
      let allMondays = this.getAllMondaysMonthly(month.year, month.monthNumber);
      this.weeks[month.monthName] = [];
      allMondays.forEach(w => {
        weekCount++;
        this.allMondays.push(w);
        this.weeks[month.monthName].push({weekNumber: weekCount, weekTitle: w});
      });
    });
    console.log(this.weeks);
  }

  selectCustomer(event) {
    this.products = [];
    this.selectedCustId = event.value;

    this.customers.forEach(cust => {
      if(cust.id === this.selectedCustId) {
        this.selectedCustName = cust.name;
      }
    });

    this.productsRaw.forEach(p => {
      if(p.custId === this.selectedCustId) {
        this.products.push(p);
      }
    });
    console.log(this.products);
  }

  selectProduct(event) {
    this.selectedProdId = event.value;
  }

  getAllMondaysYearly() {
    let start = moment().date(1).month(3).year(2020);
    let end = moment().date(31).month(2).year(2021);

    var arr = [];
    // Get "next" monday
    let tmp = start.clone().day(1);
    if( tmp.isAfter(start, 'd') ){
      arr.push(tmp.format('YYYY-MM-DD'));
    }
    while( tmp.isBefore(end) ){
      tmp.add(7, 'days');
      arr.push(tmp.format('YYYY-MM-DD'));
    }
    console.log(arr);
    this.allMondays = arr;
  }

  getAllMondaysMonthly(y, m) {
    const allMondaysMonthly = [];
    let monday = moment().year(y).month(m-1)
    .startOf('month')
    .day("Monday");

    if (monday.date() > 7) monday.add(7,'d');

    let month = monday.month();

    while(month === monday.month()){
      allMondaysMonthly.push(monday.format('DD/MM'));
        monday.add(7,'d');
    }
    return allMondaysMonthly;
  }

  addProduct() {
    this.productList = [{
      id: 1, // product id
      parentId:1, // customer id 
      name: 'Colormix Spinner Chameleon', 
      quantity: '',
      level: 'product',
      actions: [
        {name: 'Define Demand', code: 'define_demand'},
        {name: 'Remove Product', code: 'remove_product'}
      ],
      weeklySchedule: [],
      children: [
        { 
          nodeId: 11, 
          parentId: 1, // prod id
          name: 'Demand - 1', 
          quantity: '400', 
          level: 'demand',
          frequency: 'Yearly', 
          isScheduled: true,
          actions: [
            {name: 'Schedule', code: 'schedule'},
            {name: 'Breakdown', code: 'breakdown'},
            {name: 'Edit Demand', code: 'edit_demand'},
            {name: 'Delete Demand', code: 'delete_demand'}
          ],
          weeklySchedule: this.tempFunctionGetSchedule(11), // passing random number to generate count
          children: [
          { 
            nodeId: 21, 
            parentId: 11, // demand id
            name: 'Target 1 - using Heuristics', 
            quantity: '100', 
            level: 'target',
            frequency: 'Monthly', 
            isScheduled: false,
            actions: [
              {name: 'Schedule', code: 'schedule'},
              {name: 'Edit Target', code: 'edit_target'},
              {name: 'Approve Target', code: 'approve_target'},
              {name: 'Delete Target', code: 'delete_target'},
              {name: 'Delete Schedule', code: 'delete_schedule'}
            ], 
            weeklySchedule: this.tempFunctionGetSchedule(21), // passing random number to generate count
            children: [
              {nodeId: 121, name: 'Chameleon Plate Blue', actions: [], children:[], quantity:235, parentId: 21, 
                weeklySchedule: this.tempFunctionGetSchedule(9), // passing random number to generate count
                level: 'component' },
              {nodeId: 122, name: 'Chameleon Plate Red', actions: [], children:[], quantity:150, parentId: 21,
                weeklySchedule: this.tempFunctionGetSchedule(8), // passing random number to generate count
                level: 'component' },
              {nodeId: 123, name: 'Chameleon Plate Yellow', actions: [], children:[], quantity:270, parentId: 21,
                weeklySchedule: this.tempFunctionGetSchedule(13), // passing random number to generate count
                level: 'component' }
            ]
          },
          { 
            nodeId: 22, 
            parentId: 11, // demand id
            name: 'Target 2 - using Constraints', 
            quantity: '100', 
            level: 'target',
            actions: [
              {name: 'Schedule', code: 'schedule'},
              {name: 'Edit Target', code: 'edit_target'},
              {name: 'Approve Target', code: 'approve_target'},
              {name: 'Delete Target', code: 'delete_target'},
              {name: 'Delete Schedule', code: 'delete_target'}
            ], 
            weeklySchedule: this.tempFunctionGetSchedule(22), // passing random number to generate count
            children: [
              {nodeId: 121, name: 'Chameleon Plate Blue', actions: [], children:[], quantity:700, parentId: 22,
                weeklySchedule: this.tempFunctionGetSchedule(7), // passing random number to generate count
                level: 'component' },
              {nodeId: 122, name: 'Chameleon Plate Red', actions: [], children:[], quantity:750, parentId: 22,
                weeklySchedule: this.tempFunctionGetSchedule(12), // passing random number to generate count
                level: 'component' },
              {nodeId: 123, name: 'Chameleon Plate Yellow', actions: [], children:[], quantity:700, parentId: 22,
                weeklySchedule: this.tempFunctionGetSchedule(9), // passing random number to generate count
                level: 'component' }
            ]
          }
        ]},
        { nodeId: 12, name: 'Demand - 2', quantity: '', frequency: 'Yearly', 
          actions: [
            {name: 'Schedule', code: 'schedule'},
            {name: 'Breakdown', code: 'breakdown'},
            {name: 'Edit Demand', code: 'edit_demand'},
            {name: 'Delete Demand', code: 'delete_demand'}
          ],
          weeklySchedule: this.tempFunctionGetSchedule(12),
          children: [
          { nodeId: 31, name: 'Target 1 - using Heuristics', 
            actions: [
              {name: 'Schedule', code: 'schedule'},
              {name: 'Edit Target', code: 'edit_target'},
              {name: 'Approve Target', code: 'approve_target'},
              {name: 'Delete Target', code: 'delete_target'},
              {name: 'Delete Schedule', code: 'delete_target'}
            ],
            weeklySchedule: this.tempFunctionGetSchedule(31),
            children: [], quantity: 230, demandId: 12 },
          { nodeId: 32, name: 'Target 2 - using Constraints', 
            actions: [
              {name: 'Schedule', code: 'schedule'},
              {name: 'Edit Target', code: 'edit_target'},
              {name: 'Approve Target', code: 'approve_target'},
              {name: 'Delete Target', code: 'delete_target'},
              {name: 'Delete Schedule', code: 'delete_target'}
            ],
            weeklySchedule: this.tempFunctionGetSchedule(32),
            children: [], quantity: 180, demandId: 12 }
        ]},
        { nodeId: 13, name: 'Demand - 3', quantity: '', frequency: 'Yearly', 
          actions: [
            {name: 'Schedule', code: 'schedule'},
            {name: 'Breakdown', code: 'breakdown'},
            {name: 'Edit Demand', code: 'edit_demand'},
            {name: 'Delete Demand', code: 'delete_demand'}
          ],
          weeklySchedule: this.tempFunctionGetSchedule(13),
          children: [
          { 
            nodeId: 41, name: 'Target 1 - using Heuristics', 
            actions: [
              {name: 'Schedule', code: 'schedule'},
              {name: 'Edit Target', code: 'edit_target'},
              {name: 'Approve Target', code: 'approve_target'},
              {name: 'Delete Target', code: 'delete_target'},
              {name: 'Delete Schedule', code: 'delete_target'}
            ], 
            weeklySchedule: this.tempFunctionGetSchedule(14),
            children: [], quantity: 150, demandId: 13 },
          { 
            nodeId: 42, name: 'Target 2 - using Constraints', 
            actions: [
              {name: 'Schedule', code: 'schedule'},
              {name: 'Edit Target', code: 'edit_target'},
              {name: 'Approve Target', code: 'approve_target'},
              {name: 'Delete Target', code: 'delete_target'},
              {name: 'Delete Schedule', code: 'delete_target'}
            ], 
            weeklySchedule: this.tempFunctionGetSchedule(15),
            children: [], quantity: 100, demandId: 13 }
        ]}
      ]
    }];
  }

  clickAction(action_code, id, parentId, level) {
    switch (action_code) {
      case 'define_demand':
        this.defineDemand(id);
        break;
      case 'remove_product':
        this.removeProduct(id);
        break;
      case 'edit_target':
        this.editTarget(id, parentId);
        break;
      case 'breakdown':
        this.breakdownDemand(id);
        break;
      case 'edit_demand':
        this.editDemand(id);
        break;
      case 'delete_demand':
        this.deleteDemand(id);
        break;
      case 'approve_target':
        this.approveTarget(id);
        break;
      case 'delete_target':
        this.deleteTarget(id);
        break;
      case 'schedule':
        this.scheduleProduct(id, parentId, level);
        break;
      
      default:
        break;
    }
  }

  defineDemand(productId) {
    console.log(productId);
    let demandObj = {
      customerId: this.selectedCustId,
      customerName: this.selectedCustName,
      productId: productId,
      productName: null,
      demandId: null,
      demandName: null,
      demandQuantity: null,
      frequency: null,
      demandStartDate: null,
      demandEndDate: null
    };
    this.productList.forEach(product => {
      if(product.id === productId) {
        demandObj.productName = product.name;
      }
    });

    const dialogRef = this.matDialog.open(DemandDefinePopup, {
      width: this.mPopupWidth,
      data: {demandObj: demandObj}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== 'cancel') {
        // call api
        console.log('success');
      }
    });
  }

  removeProduct(productId) {
    console.log(productId);
    const dialogRef = this.matDialog.open(DeletePopup, {
      width: this.mPopupWidth,
      data: {component_type: 'Product'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        // call api
        console.log('success');
      }
    });
  }

  breakdownDemand(demandId) {
    console.log(demandId);
    let scheduleObj = {
      customerId: this.selectedCustId,
      customerName: this.selectedCustName,
      productId: this.selectedProdId,
      productName: null,
      demandId: demandId,
      demandName: 'Demand - 1',
      targetId: null,
      targetName: null,
      targetQuantity: null,
      targetStartDate: new Date(),
      targetEndDate: new Date()
    };
    this.productList.forEach(product => {
      if(product.id === this.selectedProdId) {
        scheduleObj.productName = product.name;
      }
    });

    const dialogRef = this.matDialog.open(TargetDefinePopup, {
      width: this.mPopupWidth,
      data: {scheduleObj: scheduleObj}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== 'cancel') {
        // call api
        console.log('success');
      }
    });
  }

  editTarget(targetId, parentId) {
    console.log(targetId);
    let scheduleObj = {
      customerId: this.selectedCustId,
      customerName: this.selectedCustName,
      productId: this.selectedProdId,
      productName: null,
      demandId: parentId,
      demandName: 'Demand - 1', // need to pull this details when actual object starts appearing
      targetId: targetId,
      targetName: 'Schedule 1 - using Heuristics', // need to pull this details when actual object starts appearing
      targetQuantity: '40', // need to pull this details when actual object starts appearing
      targetStartDate: new Date(),
      targetEndDate: new Date()
    };
    this.productList.forEach(product => {
      if(product.id === this.selectedProdId) {
        scheduleObj.productName = product.name;
      }
    });

    const dialogRef = this.matDialog.open(TargetDefinePopup, {
      width: this.mPopupWidth,
      data: {scheduleObj: scheduleObj}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== 'cancel') {
        // call api
        console.log('success');
      }
    });
  }

  editDemand(demandId) {
    console.log(demandId);
    let demandObj = {
      customerId: this.selectedCustId,
      customerName: this.selectedCustName,
      productId: this.selectedProdId,
      productName: null,
      demandId: demandId,
      demandName: 'Demand - 1',
      demandQuantity: 140,
      frequency: 'Yearly',
      demandStartDate: new Date(),
      demandEndDate: new Date()
    };
    this.productList.forEach(product => {
      if(product.id === this.selectedProdId) {
        demandObj.productName = product.name;
      }
    });

    const dialogRef = this.matDialog.open(DemandDefinePopup, {
      width: this.mPopupWidth,
      data: {demandObj: demandObj}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== 'cancel') {
        // call api
        console.log('success');
      }
    });
  }

  deleteDemand(demandId) {
    console.log(demandId);
    const dialogRef = this.matDialog.open(DeletePopup, {
      width: this.mPopupWidth,
      data: {component_type: 'Demand'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        // call api
        console.log('success');
      }
    });
  }

  approveTarget(targetId) {
    console.log(targetId);
    const dialogRef = this.matDialog.open(ApproveTargetPopup, {
      width: this.mPopupWidth
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'confirm') {
        // call api
        this.sentForApproval = true;
        setTimeout(() => {
          this.sentForApproval = false;
        }, 3000);
        console.log('success');
      }
    });
  }

  deleteTarget(targetId) {
    console.log(targetId);
    const dialogRef = this.matDialog.open(DeletePopup, {
      width: this.mPopupWidth,
      data: {component_type: 'Schedule'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        // call api
        console.log('success');
      }
    });
  }

  scheduleProduct(id, parentId, level) {
    console.log(id);
    console.log(level);

    //call api to get product details by product id
    const product_details = {
      productName: 'Colormix chameleon',
      quantity: 400,
      startDate: '01/10/2020',
      endDate: '25/11/2020',
      requestLevel: level
    };

    const dialogRef = this.matDialog.open(RequestSchedulePopup, {
      width: this.mPopupWidth,
      data: {productDetails: product_details},
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'confirm') {
        // call api
        this.sentForSchedule = true;
        setTimeout(() => {
          this.sentForSchedule = false;
        }, 3000);
        console.log('success');
      }
    });
  }

  getScheduleDetails(tree: TreeModel, node: TreeNode, $event) {
    TREE_ACTIONS.TOGGLE_EXPANDED(tree, node, $event);
    console.log(node);
    console.log('expanded');
    
    switch (node.data.level) {
      case 'product':
        this.dsch = node.isExpanded;
        this.setScrlls();
        break;

      case 'demand':
        this.selectedDemand = node.data.nodeId;
        const varId = "demand-" + this.selectedDemand;
        const all_target_rows = document.getElementById("quantity-list").querySelectorAll<HTMLElement>("#" + varId);
        if(node.isExpanded === true) {
          all_target_rows.forEach(row => {
            row.style.display = "block";
          });
        } else {
          all_target_rows.forEach(row => {
            row.style.display = "none";
          });
          this.selectedDemand = 0;
        }

        if(this.selectedTarget !== 0) {
          const vartId = "demand-" + this.selectedDemand + "-target-" + this.selectedTarget;
          const all_comp_rows = document.getElementById("quantity-list").querySelectorAll<HTMLElement>("#" + vartId);
          if(node.isExpanded === true) {
            all_comp_rows.forEach(row => {
              row.style.display = "block";
            });
          } else {
            all_comp_rows.forEach(row => {
              row.style.display = "none";
            });
            this.selectedTarget = 0;
          }
        }
        
        this.setScrlls();
        break;

      case 'target':
        this.selectedTarget = node.data.nodeId;
        const vartId = "demand-" + this.selectedDemand + "-target-" + this.selectedTarget;
        const all_comp_rows = document.getElementById("quantity-list").querySelectorAll<HTMLElement>("#" + vartId);
        if(node.isExpanded === true) {
          all_comp_rows.forEach(row => {
            row.style.display = "block";
          });
        } else {
          all_comp_rows.forEach(row => {
            row.style.display = "none";
          });
          this.selectedTarget = 0;
        }

        this.setScrlls();
        break;
      
      default:
        break;
    }
  }

  tempFunctionGetSchedule(n) {
    let weeklySch = [];
    this.months.forEach(month => {
      const monthNumber =  month.monthNumber - 1;
      let allMondays = this.getAllMondaysMonthly(month.year, monthNumber);
      weeklySch[month.monthName] = [];
      allMondays.forEach(w => {
        weeklySch[month.monthName].push({weekQuantity: ~~(Math.random()*52*n), weekTitle: w});
      });
    });
    return weeklySch;
  }

  setScrlls(): void {
		let isSyncingRectHeadScroll = false;
    const rectHeadScrollDiv = document.getElementById('rect-head-scroll');
    const allScrolls = document.getElementById("quantity-list").querySelectorAll(".horizontal-scrollable");

    rectHeadScrollDiv.onscroll = function() {
      if (!isSyncingRectHeadScroll) {
        allScrolls.forEach(oneScroll => {
          oneScroll.scrollLeft = rectHeadScrollDiv.scrollLeft;
        });
      }
      isSyncingRectHeadScroll = false;
    }

	}
}

@Component({
  selector: 'app-delete-popup',
  templateUrl: './delete-confirmation.html',

})
export class DeletePopup {
  constructor(public dialogRef: MatDialogRef<DeletePopup>, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    component_type = this.data.component_type;
    CloseDialog() {
      this.dialogRef.close(false);
    }
}


@Component({
  selector: 'app-demand-define-popup',
  templateUrl: './demand-define-popup.html',

})
export class DemandDefinePopup {
  constructor(public dialogRef: MatDialogRef<DemandDefinePopup>, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    demandObj = this.data.demandObj;
    requirementTypes = ['Yearly', 'Monthly', 'Weekly'];
    demandStartDate = new FormControl({value: new Date(), disabled: true},  Validators.required);
    demandEndDate = new FormControl({value: new Date(), disabled: true},  Validators.required);

    save() {
      this.demandObj.demandStartDate= this.demandStartDate.value;
      this.demandObj.demandEndDate= this.demandEndDate.value;
      console.log(this.demandObj);
    }

    CloseDialog() {
      this.dialogRef.close('cancel');
    }
}


@Component({
  selector: 'app-demand-schedule-popup',
  templateUrl: './schedule-define-popup.html',

})
export class TargetDefinePopup {
  constructor(public dialogRef: MatDialogRef<TargetDefinePopup>, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    scheduleObj = this.data.scheduleObj;
    targetStartDate = new FormControl({value: new Date(), disabled: true},  Validators.required);
    targetEndDate = new FormControl({value: new Date(), disabled: true},  Validators.required);

    save() {
      this.scheduleObj.targetStartDate= this.targetStartDate.value;
      this.scheduleObj.targetEndDate= this.targetEndDate.value;
      console.log(this.scheduleObj);
    }

    CloseDialog() {
      this.dialogRef.close('cancel');
    }
}

@Component({
  selector: 'app-approve-schedule-popup',
  templateUrl: './approve-schedule-popup.html',

})
export class ApproveTargetPopup {
  constructor(public dialogRef: MatDialogRef<ApproveTargetPopup>, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    CloseDialog() {
      this.dialogRef.close(false);
    }
}


@Component({
  selector: 'app-request-schedule-popup',
  templateUrl: './request-schedule-popup.html',

})
export class RequestSchedulePopup {
  constructor(public dialogRef: MatDialogRef<RequestSchedulePopup>, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    CloseDialog() {
      this.dialogRef.close(false);
    }
}
