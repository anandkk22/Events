import { HttpClient } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class DiscreteOperatorDashboardService {
    url: string = '../assets/json/matrix-machine-mold.json'
    constructor(private _http: HttpClient) { }

    public getMachineMoldMatrixData(): Observable<any[]>{
        return this._http.get<any[]>(this.url);
    }
    
}