import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DiscreteEnterDownTimeComponent } from './downtime-entry/discreteEnterDownTime.component';
import { DiscreteEventsComponent } from './events/discrete-events.component';
import * as am4charts from "@amcharts/amcharts4/charts";
import * as am4core from "@amcharts/amcharts4/core";
import { DiscreteOperatorDashboardService } from './discrete-operator-dashboard.service';

@Component({
    selector: 'discrete-operator-dashboard',
    templateUrl: './discrete-operator-dashboard.component.html',
    styleUrls: ['./discrete-operator-dashboard.component.scss', '../production-live-dashboard/dashboard.component.scss']
})

export class DiscreteOperatorDashboardComponent implements OnInit {
    todaysDate = new Date();
    dataPartProductionQty: number = 171;
    dataPartProductionoriginalQuantity: number = 750;
    moldMachineMatrix: any[] = [];

    constructor(public dialog: MatDialog, 
        private _discreteOperatorDashboardService: DiscreteOperatorDashboardService
        ) {

    }
    ngOnInit() {
        this.machineAvailabilityStatus();
        this.load();        
        this.machinUtilization();
        this.partsWidget();
    }

    getDownTimeEntry() {
        const dialogRef = this.dialog.open(DiscreteEnterDownTimeComponent, {
            width: '550px'
        });
    }

    getEvents() {
        const dialogRef = this.dialog.open(DiscreteEventsComponent, {
            width: '450px'
        });
    }

    load(){
       this._discreteOperatorDashboardService.getMachineMoldMatrixData().subscribe(
           data => this.moldMachineMatrix = data
       )
    }

    machineAvailabilityStatus() {
        let chart = am4core.create("ganttChart", am4charts.XYChart);
        chart.hiddenState.properties.opacity = 0; 
        chart.paddingRight = 30;
        chart.dateFormatter.inputDateFormat = "yyyy-MM-dd HH:mm";
    
        let colorSet = new am4core.ColorSet();
        colorSet.saturation = 0.4;
    
        chart.data = [
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 07:00",
            toTime: "2018-01-01 08:00" ,
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 08:01",
            toTime: "2018-01-01 09:00",
            color: "#FA6D6D" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 09:01",
            toTime: "2018-01-01 10:00",
            color: "#41CF76" 
          },
    
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 10:01",
            toTime: "2018-01-01 11:00",
            color: "#FFAC5B" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 11:01",
            toTime: "2018-01-01 12:00",
            color: "#FA6D6D" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 12:01",
            toTime: "2018-01-01 13:00",
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 13:01",
            toTime: "2018-01-01 14:00",
            color: "#FA6D6D" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 14:01",
            toTime: "2018-01-01 15:00",
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 15:01",
            toTime: "2018-01-01 16:00",
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 16:01",
            toTime: "2018-01-01 17:00",
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 17:01",
            toTime: "2018-01-01 18:00",
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 18:01",
            toTime: "2018-01-01 19:00",
            color: "#41CF76" 
          },
          {
            date: "2018-01-01",
            fromTime: "2018-01-01 19:01",
            toTime: "2018-01-01 20:00",
            color: "#41CF76" 
          }
        ];
    
        let categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis());
        categoryAxis.dataFields.category = "date";    
        categoryAxis.renderer.grid.template.location = 10;
        categoryAxis.renderer.inversed = true;
        categoryAxis.paddingLeft = 0;
        categoryAxis.paddingBottom = 0;
        categoryAxis.title.text = "Date";
        categoryAxis.layout = "absolute";
        categoryAxis.title.rotation = 0;
        categoryAxis.title.align = "center";
        categoryAxis.title.valign = "middle";
        categoryAxis.title.dy = -20;
        let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.renderer.minGridDistance = 40;
        dateAxis.baseInterval = { count: 60, timeUnit: "minute" };
        dateAxis.renderer.tooltipLocation = 0;    
    
        let series1 = chart.series.push(new am4charts.ColumnSeries());
        series1.columns.template.width = am4core.percent(40);
        series1.columns.template.height = am4core.percent(30);
        series1.columns.template.tooltipText = "{fromTime} - {toTime}";
    
        series1.dataFields.openDateX = "fromTime";
        series1.dateFormatter.dateFormat = "HH-mm";
        series1.dataFields.dateX = "toTime";    
        series1.dataFields.categoryY = "date";
        
        series1.columns.template.propertyFields.fill = "color"; 
        series1.columns.template.propertyFields.stroke = "color";
        series1.columns.template.strokeOpacity = 1;
    
        chart.scrollbarX = new am4core.Scrollbar();
      }


      machinUtilization() {
        let chart = am4core.create("chartdiv", am4charts.XYChart);
        chart.data = [{
          "time": "7am",
          "Part Utilization Percentage": 15
        }, {
          "time": "8am",
          "Part Utilization Percentage": 70
        }, {
          "time": "9am",
          "Part Utilization Percentage": 65
        }, {
          "time": "10am",
          "Part Utilization Percentage": 90
        }, {
          "time": "11am",
          "Part Utilization Percentage": 85
        }, {
          "time": "12pm",
          "Part Utilization Percentage": 66
        }, {
          "time": "1pm",
          "Part Utilization Percentage": 66
        }, {
          "time": "2pm",
          "Part Utilization Percentage": 78
        }, {
          "time": "3pm",
          "Part Utilization Percentage": 68
        }, {
          "time": "4pm",
          "Part Utilization Percentage": 55
        }, {
          "time": "5pm",
          "Part Utilization Percentage": 89
        }, {
          "time": "6pm",
          "Part Utilization Percentage": 60
        }, {
          "time": "7pm",
          "Part Utilization Percentage": 76
        }];
    
        let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
        categoryAxis.minX = 0;
        categoryAxis.dataFields.category = "time";
        categoryAxis.renderer.grid.template.location = 0;
        categoryAxis.renderer.minGridDistance = 5;    
    
        let valueyAxis = chart.yAxes.push(new am4charts.ValueAxis());
        let valuexAxis = chart.xAxes.push(new am4charts.ValueAxis());
    
        valueyAxis.title.text = "Part Utilization Percentage (%)";
    
        valuexAxis.title.text = "Shifts";
    
        categoryAxis.marginTop = -55;
        let series = chart.series.push(new am4charts.ColumnSeries());
        series.dataFields.valueY = "Part Utilization Percentage";
        series.dataFields.categoryX = "time";
        series.name = "Part Utilization Percentage";
        series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
        series.fill = am4core.color("#3DB6FF");
        series.columns.template.fillOpacity = 1;
        series.columns.template.width = am4core.percent(70);
        let columnTemplate = series.columns.template;
        columnTemplate.strokeWidth = 0;
        columnTemplate.strokeOpacity = 0;
      }

      partsWidget() {
        let chartParts = am4core.create("partsDvi", am4charts.XYChart);
    
        chartParts.data = [{
          "timePart": "7am",
          "part": 5
        }, {
          "timePart": "8am",
          "part": 24
        }, {
          "timePart": "9am",
          "part": 33
        }, {
          "timePart": "10am",
          "part": 18
        }, {
          "timePart": "11am",
          "part": 60
        }, {
          "timePart": "12pm",
          "part": 26
        }, {
          "timePart": "1pm",
          "part": 18
        }, {
          "timePart": "2pm",
          "part": 30
        }, {
          "timePart": "3pm",
          "part": 18
        }, {
          "timePart": "4pm",
          "part": 19
        }, {
          "timePart": "5pm",
          "part": 34
        }, {
          "timePart": "6pm",
          "part": 33
        }, {
          "timePart": "7pm",
          "part": 26
        }];
    
        let categoryAxis = chartParts.xAxes.push(new am4charts.CategoryAxis());
        categoryAxis.dataFields.category = "timePart";
        categoryAxis.renderer.grid.template.location = 0;
        categoryAxis.renderer.minGridDistance = 5;
    
        let valueyAxis = chartParts.yAxes.push(new am4charts.ValueAxis());
        let valuexAxis = chartParts.xAxes.push(new am4charts.ValueAxis());
    
        valueyAxis.title.text = "Number of Parts";
        valuexAxis.title.text = "Shifts";
        categoryAxis.marginTop = -56;
        let series = chartParts.series.push(new am4charts.ColumnSeries());
        series.dataFields.valueY = "part";
        series.dataFields.categoryX = "timePart";
        series.name = "part";
        series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
        series.fill = am4core.color("#3DB6FF");
        series.columns.template.fillOpacity = 1;
        series.columns.template.width = am4core.percent(70);
        let columnTemplate = series.columns.template;
        columnTemplate.strokeWidth = 0;
        columnTemplate.strokeOpacity = 0;
      }
    


}