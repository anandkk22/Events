import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";


@Component({
    selector: 'events',
    templateUrl: './discrete-events.component.html',
    styleUrls: ['./discrete-events.component.scss']
})
export class DiscreteEventsComponent implements OnInit {
    events: any[];
    constructor(private _mdr: MatDialogRef<DiscreteEventsComponent>){}

    ngOnInit(){
        this.events = [{eventTime: "8:00 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am", downTime: "21 min", reason: "No Operator"}];
    }

    onNoClick(): void {
        this._mdr.close();        
    }
}