import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from "@angular/material/dialog";


@Component({
    selector: 'events-downTime',
    templateUrl: './discreteEnterDownTime.component.html',
    styleUrls: ['./events.component.scss']
})
export class DiscreteEnterDownTimeComponent implements OnInit {
    events: any[];
    constructor(private _mdr: MatDialogRef<DiscreteEnterDownTimeComponent>){}

    ngOnInit(){
        this.events = [{eventTime: "8:00 am - 8:21 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am - 8:21 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am - 8:21 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am - 8:21 am", downTime: "21 min", reason: "No Operator"},{eventTime: "8:00 am - 8:21 am", downTime: "21 min", reason: "No Operator"}];
    }

    onNoClick(): void {
        this._mdr.close();        
    }
}