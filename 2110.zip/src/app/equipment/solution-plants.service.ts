import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class SolutionPlantsService {
  public url: string = "./assets/json/";
  constructor(private http: HttpClient) {}

  getelementsDetails() {
    return this.http.get(this.url + "solution_Plant_Level.json");
  }

  getidesDetails() {
    return this.http.get(this.url + "solution_Asset_Level.json");
  }
}
