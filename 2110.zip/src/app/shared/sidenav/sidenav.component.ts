import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {
  currentAccount: any;
  menuItems = [
    // {
    //     name: 'Portfolio',
    //     router: 'portfolio',
    //     permission: 'PORTFOLIO_MGMT_R',
    //     selected: 'apo-icon-portfolio-selected selected-icon',
    //     unselected: 'apo-icon-portfolio-selected deselected-icon'
    // },
    {
      name: 'Dashboard',
      router: 'dashboard',
      selected: '../../../assets/Images/Dashboard-unselected.png',
      // unselected: 'apo-icon-command-center deselected-icon'
    },
    {
      name: 'Discrete360',
      router: 'discrete-app',
      selected: '',
      // unselected: 'apo-icon-command-center deselected-icon'
    },
    {
      name: 'Batch Analysis',
      router: 'batch-analysis',
      selected: '../../../assets/Images/BatchAnalytics-unselected.png',
      // unselected: 'apo-icon-events-selected deselected-icon'
    },
    {
      name: 'SPC Analysis',
      router: 'performance',
      selected: '../../../assets/Images/SPCAnalytics-unselected.png',
      // unselected: 'apo-icon-performance-selected deselected-icon'
    },
    {
      name: 'Trends',
      router: 'health',
      selected: '../../../assets/Images/Trends-unselected.png',
      // unselected: '../../../content/images/icons/Health_unselected.png'
    },
    {
      name: 'Reports',
      router: 'energy',
      permission: 'ENERGY_LOSS_MGMT_R',
      selected: '../../../assets/Images/Reports-unselected.png',
      // unselected: 'apo-icon-energy-selected deselected-icon'
    },
  ];
  currRoute: string = null;
  @ViewChild('sidenav', { static: true }) sidenav: MatSidenav;

  isOpenNavBar: boolean;
  activeNavbar: boolean;
  constructor(
    private router: Router,
  ) { }

  ngOnInit() {
    this.activeNavbar = true;
    this.isOpenNavBar = true;
  }

  checkRoute() {
    this.currRoute = this.router.url.split('/').pop();
    if (
      this.currRoute === 'remote-monitoring' ||
      this.currRoute === 'plantremotemonitoring' ||
      this.router.url.includes('assetremotemonitoring')
    ) {
      this.currRoute = 'roc-base/remote-monitoring';
    }
  }

  collapseSideBar() {
    this.isOpenNavBar = !this.isOpenNavBar;
    this.activeNavbar = this.isOpenNavBar ? true : false;
    if (!this.isOpenNavBar) {
      this.sidenav.close();
    } else {
      this.sidenav.open();
    }
    const element1 = document.getElementById('side-navbar-collapse-arrow-left-id');
    element1.classList.toggle('side-navbar-collapse-arrow-right');
  }
  expandOnHover() {
    if (!this.activeNavbar) {
      this.sidenav.open();
    }
  }
  collapseOnHover() {
    if (!this.activeNavbar) {
      this.sidenav.close();
    }
  }

}
