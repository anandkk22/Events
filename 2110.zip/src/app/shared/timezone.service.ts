import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AllTimezoneService {

    public url: string = '../assets/json/all-timezone.json';
    constructor(private _http: HttpClient){}

    getTimezoneCountries():Observable<any> {
        return this._http.get<any>(this.url)
    }
}