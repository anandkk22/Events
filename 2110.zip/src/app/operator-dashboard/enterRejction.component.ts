import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";


@Component({
    selector: 'events',
    templateUrl: './enterRejection.component.html',
    styleUrls: ['./events.component.scss']
})
export class EventsRejection implements OnInit {
    
    todayDate = new Date()
    constructor(private _mdr: MatDialogRef<EventsRejection>){}

    ngOnInit(){    
    }

    onNoClick(): void {
        this._mdr.close();        
    }
}