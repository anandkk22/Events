import { of } from 'rxjs';
import { OperatorDashboardComponent } from './operator-dashboard.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartsModule } from 'ng2-charts';
import { OperatorRoutingModule } from './operator-dashboard-routing.module';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { ProgressBarModule } from "angular-progress-bar";
import { NbProgressBarModule } from '@nebular/theme';
import { MaterialModule } from '../material.module';


@NgModule({
  declarations: [OperatorDashboardComponent, BarChartComponent],
  imports: [
    CommonModule,
    OperatorRoutingModule,
    ChartsModule,
    ProgressBarModule,
    NbProgressBarModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      "radius": 80,
      "space": -10,
      "outerStrokeLinecap": "square",
      "outerStrokeGradient": true,
      "innerStrokeWidth": 10,
      "title": '',
      "titleFontSize": '15',
      "titleFontWeight": 'bold',
      "titleColor": '#000000',
      "units": '',
      "unitsFontSize": '30',
      "unitsFontWeight": 'normal',
      "unitsColor": '#000000',
      "subtitle": '',
      "subtitleColor": '#000000',
      "subtitleFontSize": '15',
      "subtitleFontWeight": 'normal',
      "showBackground": true,
      "clockwise": true,
      "startFromZero": false,
      "responsive": true,
      "outerStrokeColor": "#000000",
      "outerStrokeGradientStopColor": "#000000",
      "renderOnClick": false
    }),
    MaterialModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [OperatorDashboardComponent]
})
export class OperatorModule { }
