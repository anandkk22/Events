import { HttpClient } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OperatorService {

  constructor(private _http: HttpClient) { }

  public getOperatorData() {
    return this._http.get("assets/json/operator-dash-data.json");
  }

  public getCurrentJobList(equipmentId) {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-production-schedule/current-job-list/' + equipmentId)
  }

  public hourAggregationData(equipmentId) {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-hour-level-aggregation/aggregated-data-for-equipment/' + equipmentId);
  }

  public getKpiData(equipmentId) {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-hour-level-kpi/operator-data/' + equipmentId);
  }

  public getHourSpecificData(equipmentId) {
    return this._http.get(environment.CNC_API_URL + 'api/mfgconnect-hour-level-aggregation/operator-data/' + equipmentId);
  }
}
