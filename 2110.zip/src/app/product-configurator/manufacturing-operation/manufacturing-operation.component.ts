import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { AssemblyProcessService } from 'src/app/library/parameter-tags/assembly-process/assembly-process.service';
import { EquipmentMesurementDataService } from 'src/app/library/parameter-tags/equipment-measurement-data/equipment-measurement-data.service';
import { ManufacturingProcessService } from 'src/app/library/parameter-tags/manufacturing-process/manufacturing-process.service';
import { DeletePlant } from 'src/app/plants/delete-plant/delete-plant';
import { DeleteProduct } from '../delete-plantconfigurator/delete-plantconfigurator';
import { ManufacturingOperationRelationship } from './manufacturing-operation-relationship';
import { ManufacturingOperationModel } from './manufacturing-operation.model';
import { ManufacturingOperationService } from './manufacturing-operation.service';
import { DataUploadComponent } from '../data-upload/data-upload.component';

@Component({
  selector: 'app-manufacturing-operation',
  templateUrl: './manufacturing-operation.component.html',
  styleUrls: ['../../plants/plant-configuration/plant-configuration.component.scss', './manufacturing-operation.component.scss']
})
export class ManufacturingOperationComponent implements OnInit {

  manufacturingOperationDetails: ManufacturingOperationModel[];
  //productFamilyDetails: ProductFamilyModel[];
  manufacturingOperationDetail: ManufacturingOperationModel = {};
  hideForm: boolean = true
  $localmanufacturingOperationDetailId: any;
  noOfManuProcess: any[];
  menuProcess = new FormControl();
  operationTypeList: any[]
  equipParamList: any[]
  processParameters = new FormControl();
  assemblyList: any[]
  manufacturingList: any[]
  assemblyBoolean: boolean = false
  manufacturingBoolean: boolean = false
  selectedManuProcess;

  constructor(private manufacturingOperationService: ManufacturingOperationService, private equipParamService: EquipmentMesurementDataService, private assemblyProcessService: AssemblyProcessService, private manufacturingProcessService: ManufacturingProcessService, public dialog: MatDialog
  ) { }

  //private _productFamilyService: ProductFamilyService


  ngOnInit() {
    this.loadProduct();

    this.equipParamService.getEquipmentMesData().subscribe(data =>
      this.equipParamList = data)

    this.assemblyProcessService.getAssemblyProcessList().subscribe(data =>
      this.assemblyList = data)

    this.manufacturingProcessService.getManufacturingProcessList().subscribe(data =>
      this.manufacturingList = data


    )
    //this.loadProductFamily();
  }

  addnew() {
    this.manufacturingOperationDetail = {}
    this.hideForm = false
  }

  onOptionsSelected(optType) {
    console.log("select event is ", optType)
    if (optType == 1) {
      this.manufacturingBoolean = true
      if (this.assemblyBoolean) {
        this.assemblyBoolean = false
      }
    } else if (optType == 2) {
      this.assemblyBoolean = true
      if (this.manufacturingBoolean) {
        this.manufacturingBoolean = false
      }
    }
  }

  getProcessParamDetails(mfgTools: any[]): string {
    let processParamName: string = '';
    for (var i = 0; i < mfgTools.length; i++) {
      processParamName = processParamName.concat(' ' + mfgTools[i].name).concat(',');
    }
    return processParamName.slice(0, -1);
  }

  details(id) {
    this.manufacturingOperationDetails.forEach(manufacturingOperation => {
      if (manufacturingOperation.id === id) {
        this.manufacturingOperationDetail = manufacturingOperation;
        let tempList = this.manufacturingOperationDetail.processParameters;
        if (tempList.length != 0) {
          let idList: any = []
          for (var i = 0; i < tempList.length; i++) {
            let id = tempList[i].id
            idList.push(id)
          }
          this.manufacturingOperationDetail.processParamTemp = idList
        }
        if (manufacturingOperation.operationType == "1") {
          this.manufacturingBoolean = true
          if (this.assemblyBoolean) {
            this.assemblyBoolean = false
          }
        } else if (manufacturingOperation.operationType == "2") {
          this.assemblyBoolean = true
          if (this.manufacturingBoolean) {
            this.manufacturingBoolean = false
          }
        }
      }
      this.hideForm = false;
      // this.manufacturingBoolean = false
      // this.assemblyBoolean = false
    });
  }

  loadProduct() {
    this.manufacturingOperationService.getOperationType().subscribe(data =>
      this.operationTypeList = data
    )
    this.manufacturingOperationService.getListofproduct().subscribe(
      data => {
        this.manufacturingOperationDetails = data
        if (this.manufacturingOperationDetails) {
          this.manufacturingOperationDetails.forEach(list => {
            if (list.operationType == "1") {
              list.operationName = this.operationTypeList[0].name
            }
            if (list.operationType == "2") {
              list.operationName = this.operationTypeList[1].name
            }
          })
        }

      }
    )
  }

  // loadProductFamily() {
  //     this._productFamilyService.getListofproductFamily().subscribe(
  //         data => this.productFamilyDetails = data
  //     )
  // }

  confirmDelete(id) {
    const dialogRef = this.dialog.open(DeletePlant, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.manufacturingOperationService.deleteProductById(id).subscribe((resp) => {
          console.log("operation deleted", resp);
          this.loadProduct();
        });
      }
    })
  }
  showRelationship(manufacturingOperationDetailId): void {
    this.$localmanufacturingOperationDetailId = localStorage.setItem('manufacturingOperationDetailId', JSON.stringify(manufacturingOperationDetailId));
    const dialogRef = this.dialog.open(ManufacturingOperationRelationship, {
      width: '450px'
    });
  }

  save() {
    let processList: { id: number }[] = [];
    console.log("data is", typeof (this.processParameters))
    if (this.processParameters) {

      for (var val of this.processParameters.value) {
        processList.push({ id: +val });



      }
      this.manufacturingOperationDetail.processParameters = processList
      this.manufacturingOperationDetail.processParamTemp = null
    }
    console.log("final object is", this.manufacturingOperationDetail)
    if (this.manufacturingOperationDetail.id == undefined || this.manufacturingOperationDetail.id == null) {
      this.manufacturingOperationService.createProduct(this.manufacturingOperationDetail).subscribe((data) => {
        this.loadProduct();
      });
      this.hideForm = true;
    }
    else {
      if (this.manufacturingOperationDetail.operationType == "1") {
        if (this.manufacturingOperationDetail.mfgconnectAssemblyProcessId != null) {
          this.manufacturingOperationDetail.mfgconnectAssemblyProcessId = null;
        }
      } else if (this.manufacturingOperationDetail.operationType == "2") {
        if (this.manufacturingOperationDetail.mfgconnectManufacturingProcessId != null) {
          this.manufacturingOperationDetail.mfgconnectManufacturingProcessId = null
        }

      }
      this.manufacturingOperationService.updateProduct(this.manufacturingOperationDetail).subscribe(() => {
        this.loadProduct();
      });
    }
    this.hideForm = true;
  }

  cancel() {
    this.manufacturingOperationDetail = null;
  }

  isActiveClass(manufacturingOperation) {
    this.manufacturingOperationService.isActiveClass(this.manufacturingOperationDetails, manufacturingOperation)
  }

  upload() {
    const dialogRef = this.dialog.open(DataUploadComponent, {
      width: '400px'
    });
    dialogRef.afterClosed().subscribe(result => {
      // if (result === 'delete') {
      //   this.manufacturingOperationService.deleteProductById(id).subscribe((resp) => {
      //     console.log("operation deleted", resp);
      //     this.loadProduct();
      //   });
      // }
    });
  }
}

// @Pipe({ name: 'searchByProductName' })
// export class searchByProductName implements PipeTransform {
//   transform(items: any[], searchTerm: string): any[] {
//     if (!items || !searchTerm) {
//       return items
//     }

//     return items.filter(item =>
//       item.productName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
//     )
//   }
// }

// @Pipe({ name: 'OrderByProductPipe' })
// export class OrderByProductPipe implements PipeTransform {
//   transform(items: any[], field: string, reverse: boolean = false): any[] {
//     if (!items) return [];
//     if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
//     else items.sort((a, b) => a > b ? -1 : 1);

//     if (field === 'lastUpdated') {
//       let values = items.sort((a: any, b: any) => {
//         return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
//       });
//       return values.reverse();
//     }
//     return items;
//   }

// }
