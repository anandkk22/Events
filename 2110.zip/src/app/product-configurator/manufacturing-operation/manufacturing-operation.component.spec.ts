import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufacturingOperationComponent } from './manufacturing-operation.component';

describe('ManufacturingOperationComponent', () => {
  let component: ManufacturingOperationComponent;
  let fixture: ComponentFixture<ManufacturingOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManufacturingOperationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManufacturingOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
