import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';

import { catchError } from 'rxjs/operators';
import { ManufacturingOperationModel } from './manufacturing-operation.model';



@Injectable({ providedIn: 'root' })
export class ManufacturingOperationService {
  public product: string = environment.CNC_API_URL + 'api/mfgconnect-manufacturing-operation';
  public relationship: string = environment.CNC_API_URL + 'api/mfgconnect-manufacturing-operation/get-relationship';
  public operationType: string = environment.CNC_API_URL + 'api/operation-type'

  constructor(private _http: HttpClient) { }

  getListofproduct(): Observable<ManufacturingOperationModel[]> {
    return this._http.get<ManufacturingOperationModel[]>(`${this.product}`)
  }

  getProductById(id: number): Observable<ManufacturingOperationModel> {
    return this._http.get<ManufacturingOperationModel>(`${this.product}/${id}`)
  }

  getOperationType(): Observable<any> {
    return this._http.get<any>(`${this.operationType}`)
  }

  createProduct(product: ManufacturingOperationModel): Observable<any> {
    return this._http.post<any>(`${this.product}`, product, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateProduct(product: ManufacturingOperationModel): Observable<void> {
    return this._http.put<void>(`${this.product}`, product, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  deleteProductById(id: number) {
    return this._http.delete(this.product + "/" + id, { responseType: 'text' })
      .pipe(catchError(this.handleError))
  }

  getRelationship(id: number): Observable<any[]> {
    return this._http.get<any[]>(`${this.relationship}/${id}`)
  }



  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }

  isActiveClass(componentList, currComponent) {
    componentList.forEach(element => {
      element.isActive = false;
    });
    currComponent.isActive = true;
  }
}
