import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { ManufacturingOperationService } from './manufacturing-operation.service';




@Component({
  selector: 'manufacturing-operation-relationship',
  templateUrl: './manufacturing-operation-relationship.html',
  styleUrls: ['../../plants/relationship-plant/relationship-plant.scss']
})
export class ManufacturingOperationRelationship implements OnInit, OnDestroy {
  private _id: number;
  getPlantId: any;
  getRelationship: any
  operationId: any;

  constructor(private _mdr: MatDialogRef<ManufacturingOperationRelationship>,
    private manufacturingOperationService: ManufacturingOperationService, private _route: ActivatedRoute) {

  }

  onNoClick(): void {
    this._mdr.close();
  }

  ngOnInit() {
    this.operationId = localStorage.getItem('manufacturingOperationDetailId');
    this.onLoad();
  }

  onLoad() {
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this.manufacturingOperationService.getRelationship(this.operationId).subscribe(
        operation => {
          this.getRelationship = operation
        }
      )
    })
  }

  ngOnDestroy() {
    localStorage.removeItem('injectionMoldId');
  }

}
