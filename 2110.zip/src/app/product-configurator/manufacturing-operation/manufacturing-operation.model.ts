export class ManufacturingOperationModel {
  id?: number
  code?: string
  name?: string
  operationType?: string
  operationName?: string
  mfgconnectManufacturingProcessId?: number
  mfgconnectAssemblyProcessId?: number
  processParameters?: ProcessParameter[]
  processParamTemp?: any[]

}

export class ProcessParameter {
  id?: number

  name?: string


}
