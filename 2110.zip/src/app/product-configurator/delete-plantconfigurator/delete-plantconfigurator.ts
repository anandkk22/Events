import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { Component } from '@angular/core';

@Component({
    selector: 'app-delete-plantconfigurator',
    templateUrl: 'delete-plantconfigurator.html',
    styleUrls: ['delete-plantconfigurator.scss']

})
export class DeleteProduct {
    constructor(public dialogRef: MatDialogRef<DeleteProduct>) { }

    onNoClick(): void {
        this.dialogRef.close();
    }
}