import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { ActivatedRoute } from '@angular/router';
import { MoldMasterService } from './moldmaster.service';




@Component({
    selector: 'productFamily-relationship',
    templateUrl: './mold-master-relationship.html',
    styleUrls: ['../../plants/relationship-plant/relationship-plant.scss']
})

export class MoldMasterRelationshipComponent {
    private _id: number;
    getRelationship: any[];
    getMoldMasterId: any;    

    constructor(private _route: ActivatedRoute, private _moldMasterService: MoldMasterService,
        private _mdr: MatDialogRef<MoldMasterRelationshipComponent>){}

    ngOnInit(){
        this.getMoldMasterId = localStorage.getItem('moldMasterId');
        this.onLoad();
    }


    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._moldMasterService.getRelationship(this.getMoldMasterId).subscribe(
                moldMaster => {                   
                    this.getRelationship = moldMaster
                }
            )
        })
    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnDestroy(){
        localStorage.removeItem('moldMasterId');
    }

}