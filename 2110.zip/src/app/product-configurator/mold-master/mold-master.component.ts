import { OnInit, Component, ViewChild, PipeTransform, Pipe } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { DeleteProduct } from '../delete-plantconfigurator/delete-plantconfigurator';
import { MoldMasterRelationshipComponent } from './mold-master-relationship';
import { MoldMasterModel } from './mold-master.model';
import { MoldMasterService } from './moldmaster.service';


@Component({
  selector: 'moldmaster',
  templateUrl: './mold-master-component.html',
  styleUrls: ['../../plants/plant-configuration/plant-configuration.component.scss']
})
export class MoldMasterComponent implements OnInit {
  moldMasterDetails: MoldMasterModel[];
  moldMasterDetail: MoldMasterModel = {}
  hideForm: boolean = false
  $localMoldMasterId: any;
  allowedMachineList: any[];
  mfgTools: any[];
  menumfgconnectTools = new FormControl();
  //plantId: any;

  constructor(private _moldMasterService: MoldMasterService, public dialog: MatDialog) { }

  ngOnInit() {
    //this.plantId = localStorage.getItem('plantId');
    this.loadMoldMaster();
    this.loadMachinAllowedList();
  }

  addnew() {
    this.moldMasterDetail = {}
    this.hideForm = true;
  }

  loadMachinAllowedList() {
    this._moldMasterService.getMachineAllowedList().subscribe(
      data => this.mfgTools = data
    )
  }

  getAllowedEquipment(mfgTools: any[]): string {
    let toolsName: string = '';
    if (mfgTools != undefined) {
      for (var i = 0; i < mfgTools.length; i++) {
        toolsName = toolsName.concat(mfgTools[i].equipmentName).concat(',');
      }
      return toolsName.slice(0, -1);
    }
  }

  loadMoldMaster() {
    this._moldMasterService.getListofMoldMaster().subscribe(
      data => this.moldMasterDetails = data
    )
  }

  details(id) {
    this.moldMasterDetails.forEach(moldMaster => {
      if (moldMaster.id === id) {
        this.moldMasterDetail = moldMaster;
      }
      this.hideForm = true;
    });
  }

  confirmDelete(id) {
    const dialogRef = this.dialog.open(DeleteProduct, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._moldMasterService.deleteMoldMasterById(id).subscribe((resp) => {
          console.log(`Mold Master deleted with id =  ${id} deleted`, resp);
          () => this.loadMoldMaster();
        })
      }
    })
  }

  showRelationship(getMoldMasterId): void {
    this.$localMoldMasterId = localStorage.setItem('moldMasterId', JSON.stringify(getMoldMasterId));
    const dialogRef = this.dialog.open(MoldMasterRelationshipComponent, {
      width: '450px'
    });
  }

  save() {
    let mfgTools: { id: number }[] = [];
    if (this.menumfgconnectTools instanceof Array) {

      if (this.menumfgconnectTools.length != 0)
        for (var val of this.menumfgconnectTools.value) {
          mfgTools.push({ id: +val });
        }
    }
    this.moldMasterDetail.allowedEquipments = mfgTools;
    //this.moldMasterDetail.mfgconnectSiteId = this.plantId
    if (this.moldMasterDetail.id == undefined || this.moldMasterDetail.id == null) {

      this._moldMasterService.createMoldMaster(this.moldMasterDetail).subscribe((data) => {
        this.loadMoldMaster();
      });
      this.hideForm = false;
    }
    else {
      this._moldMasterService.updateMoldMaster(this.moldMasterDetail).subscribe(() => {
        this.loadMoldMaster();
      });
    }
    this.hideForm = false;
  }

  cancel() {
    this.moldMasterDetail = null;
  }
}

@Pipe({ name: 'searchByMoldName' })
export class searchByMoldName implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.moldName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}

@Pipe({ name: 'OrderByMoldMaster' })
export class OrderByMoldMaster implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}
