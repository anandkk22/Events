import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';

import { catchError } from 'rxjs/operators';
import { ProductFamilyModel } from './product.model';

@Injectable({ providedIn: 'root' })
export class ProductFamilyService {
    public productFamily: string = environment.CNC_API_URL + 'api/mfgconnect-productFamily'; 
    public relationship: string = environment.CNC_API_URL + 'api/mfgconnect-productFamily/get-relationship';  

    constructor(private _http: HttpClient) { }

    getListofproductFamily(): Observable<ProductFamilyModel[]> {
        return this._http.get<ProductFamilyModel[]>(`${this.productFamily}`)
    }

    getProductFamilyById(id: number): Observable<ProductFamilyModel> {
        return this._http.get<ProductFamilyModel>(`${this.productFamily}/${id}`)
    }

    createProductFamily(productFamily: ProductFamilyModel): Observable<any> {
        return this._http.post<any>(`${this.productFamily}`, productFamily, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateProductFamily(processCell: ProductFamilyModel): Observable<void> {
        return this._http.put<void>(`${this.productFamily}`, processCell, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    deleteProductFamilyById(id: number) {
        return this._http.delete(this.productFamily+"/"+ id, {responseType: 'text'})
        .pipe(catchError(this.handleError))
    }

    getRelationship(id: number): Observable<any[]> {
        return this._http.get<any[]>(`${this.relationship}/${id}`)
    }

    private handleError(error) { 
        let errorMessage = '';
        if (error.status !== 200) {
          window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
        }         
        return throwError(errorMessage);      
    }

    isActiveClass(componentList, currComponent) {
        componentList.forEach(element => {
            element.isActive = false;
        });
        currComponent.isActive = true;
    }
}