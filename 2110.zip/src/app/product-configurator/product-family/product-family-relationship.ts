import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { ActivatedRoute } from '@angular/router';
import { ProductFamilyService } from './product-family.service';



@Component({
    selector: 'productFamily-relationship',
    templateUrl: './product-family-relationship.html',
    styleUrls: ['../../plants/relationship-plant/relationship-plant.scss']
})
export class ProductFamilyRelationshipComponent implements OnInit, OnDestroy{
    private _id: number;
    getRelationship: any[];
    getProductFamilyId: any;

    constructor(private _route: ActivatedRoute, private _productFamilyService: ProductFamilyService,
        private _mdr: MatDialogRef<ProductFamilyRelationshipComponent>){}

    ngOnInit(){
        this.getProductFamilyId = localStorage.getItem('productFamilyId');
        this.onLoad();
    }


    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._productFamilyService.getRelationship(this.getProductFamilyId).subscribe(
                productFamily => {                   
                    this.getRelationship = productFamily
                }
            )
        })
    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnDestroy(){
        localStorage.removeItem('productFamilyId');
    }

}