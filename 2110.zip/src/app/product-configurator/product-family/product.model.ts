export class ProductFamilyModel {    
    id?: number;
    productFamilyName?: string;
    productFamilyNumber?: string;
    productFamilyDescription?: string;
    erpProductFamilyCode?: string
    erpProductFamilyNumber?: string;
    customerName?: string;   
}