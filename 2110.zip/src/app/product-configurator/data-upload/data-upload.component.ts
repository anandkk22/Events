import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-data-upload',
  templateUrl: './data-upload.component.html',
  styleUrls: ['./data-upload.component.scss']
})
export class DataUploadComponent implements OnInit {

  constructor(private dialog: MatDialogRef<DataUploadComponent>) { }

  ngOnInit() {
  }

  cancel(){
    this.dialog.close(false)
  }
}
