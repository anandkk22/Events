import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { ActivatedRoute } from '@angular/router';
import { ComponentService } from './component.service';


@Component({
  selector: 'product-relationship',
  templateUrl: './component-relationship.html',
  styleUrls: ['../../plants/relationship-plant/relationship-plant.scss']
})

export class ComponentRelationship implements OnInit, OnDestroy {
  private _id: number;
  getRelationship: any[];
  getComponentId: any;

  constructor(private _route: ActivatedRoute, private _componentService: ComponentService,
    private _mdr: MatDialogRef<ComponentRelationship>) { }

  ngOnInit() {
    this.getComponentId = localStorage.getItem('componentId');
    this.onLoad();
  }

  onLoad() {
    this._route.paramMap.subscribe(params => {
      this._id = +params.get('id');
      this._componentService.getRelationship(this.getComponentId).subscribe(
        component => {
          this.getRelationship = component
        }
      )
    })
  }

  onNoClick(): void {
    this._mdr.close();
  }

  ngOnDestroy() {
    localStorage.removeItem('componentId');
  }

}
