import { OnInit, Component, ViewChildren, QueryList, ElementRef, ViewChild } from '@angular/core';
import { ProductFamilyService } from '../../product-family/product-family.service';
import { ProductFamilyModel } from '../../product-family/product.model';

import { FormArray, FormBuilder, FormControl, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ComponentProductModel } from '../component.model';
import { ComponentService } from '../component.service';
import { MoldMasterService } from '../../mold-master/moldmaster.service';
import { MoldMasterModel } from '../../mold-master/mold-master.model';
import { InjectionMoldModel } from 'src/app/plants/plant-configuration/injection-mold/injection-mold.model';


@Component({
  selector: 'add-component',
  templateUrl: './add-component.component.html',
  styleUrls: ['./add-component.component.scss', '../../../plants/add-plant/add-plant.component.scss']
})

export class AddComponent implements OnInit {
  @ViewChild('firstForm', { static: false }) public firstFormName: NgForm;
  @ViewChild('secondForm', { static: false }) public secondFormName: NgForm;
  fieldArray: Array<number> = [0];

  submitted: boolean = false;
  title: string = '';
  requiredField: string;

  componentProductDetails: ComponentProductModel[];
  componentProductDetail: ComponentProductModel = {};

  form: FormGroup;
  selectedMoldMasters: any[] = [];

  manufacturingProcesses: any[];
  moldMasterDetails: MoldMasterModel[];
  moldMasterDetail: MoldMasterModel = {};
  injectionMoldList: InjectionMoldModel[];


  constructor(private _componentServie: ComponentService, private _moldMasterService: MoldMasterService,
    private _productFamilyService: ProductFamilyService, private _router: Router,
    private _route: ActivatedRoute, private fb: FormBuilder
  ) {
    this.form = this.fb.group({
      checkArray: this.fb.array([])
    })

  }

  ngOnInit() {
    this.getInjectionMoldParts();
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
      this.getComponent(id);
      this.getManufacturingProcess();
      this.componentProductDetails.forEach(componentProduct => {
        if (componentProduct.id === id) {
          this.componentProductDetail = componentProduct;

        }
      });
    })
    this.loadMoldMaster();
    this.loadComponent();
  }

  getInjectionMoldParts() {
    this._componentServie.getListofInjectionMoldPart().subscribe(
      data => this.injectionMoldList = data
    )
  }

  getManufacturingProcess() {
    this._componentServie.getManufacturingProcess().subscribe(
      data => {
        // if (data != undefined) {
        //   if (data.length > 1) {
        //     let obj = data[0]
        //     let temp = []
        //     temp.push(obj)
        //     this.manufacturingProcesses = temp
        //   }
        //   else {
        //     this.manufacturingProcesses = data
        //   }
        // }
        this.manufacturingProcesses = data
      }
    )
    this.changeList();
  }
  changeList() {
  }


  loadMoldMaster() {
    this._moldMasterService.getListofMoldMaster().subscribe(
      data => this.moldMasterDetails = data
    )
  }

  loadComponent() {
    this._componentServie.getListofcomponent().subscribe(
      data => this.componentProductDetails = data
    )
  }

  addMoldMasterField() {
    this.selectedMoldMasters.push({ id: null });
  }

  deleteMoldMaster(index) {
    this.selectedMoldMasters.splice(index, 1);
  }

  private getComponent(id: number) {
    if (id === 0) {
      this.componentProductDetail = {};
      this.title = "Add new";
    } else {
      this.title = "Edit";
      this._componentServie.getComponentById(id).subscribe(
        (product) => {
          this.componentProductDetail = product;
          this.selectedMoldMasters = this.componentProductDetail.moldMasters;
          console.log(this.componentProductDetail);
          console.log(this.selectedMoldMasters);
        }
      )
    }
  }

  save() {
    if (this.moldMasterDetail.id == undefined || this.moldMasterDetail.id == null) {
      this._moldMasterService.createMoldMaster(this.moldMasterDetail).subscribe((data) => {
        this.loadMoldMaster();
      });
    }
    else {
      this._moldMasterService.updateMoldMaster(this.moldMasterDetail).subscribe(() => {
        this.loadMoldMaster();
      });
    }
  }

  saveComponent() {
    if (this.firstFormName.invalid) {
      this.requiredField = "Required fields are missing, Please check";
      return;
    } else {
      this.componentProductDetail.moldMasters = this.selectedMoldMasters;
      console.log(this.componentProductDetail);

      if (this.componentProductDetail.id == undefined || this.componentProductDetail.id == null) {
        this._componentServie.createComponent(this.componentProductDetail).subscribe((data) => {
          this._router.navigate(['/productConfig/component'])
        });
      }
      else {
        this._componentServie.updateComponent(this.componentProductDetail).subscribe(() => {
          this._router.navigate(['/productConfig/component'])
        });
      }
    }

  }

  cancel() {
    this._router.navigate(['/productConfig/component'])
  }

}
