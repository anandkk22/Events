export class ComponentProductModel {
  id?: number;
  partNumber?: string;
  partDescription?: string;
  partFamilyID?: number;
  partNetWeight?: number;
  partColor?: string;
  erpPartCode?: string;
  erpMaterialCode?: string;
  erpPartNumber?: string;
  mfgconnectProductId?: number;
  mfgconnectTools?: ComponentTool[];
  tempTools?: any[];
  mfgconnectManufacturingProcessId?: number;
  moldMasters?: any[];
}

export class ComponentTool {
  id?: number;
  toolName?: string;
  toolCode?: string;
  toolType?: string;
  toolCapacity?: number;
  operatorsTools?: string;
  toolScheduleTools?: string;
  mfgconnectParts?: string;
  cycleTime?: number;
  allowedEquipments?: string
  noOfCavities?: number;
  injMoldName?: string

}
