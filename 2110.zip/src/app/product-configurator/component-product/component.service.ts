import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';

import { catchError } from 'rxjs/operators';
import { ComponentProductModel } from './component.model';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';



@Injectable({ providedIn: 'root' })
export class ComponentService {
  public component: string = environment.CNC_API_URL + 'api/mfgconnect-injection-molding-part';
  public mfgTool: string = environment.CNC_API_URL + 'api/mfgconnect-toolInjMold';
  public manufacturingProcess: string = environment.CNC_API_URL + 'api/mfgconnect-manufacturing-operation/get-manufacturing-process'
  public relationship: string = environment.CNC_API_URL + 'api/mfgconnect-injection-molding-part/get-relationship';
  public injectionMoldPart: string = environment.CNC_API_URL + 'api/mfgconnect-injection-molding-part';

  constructor(private _http: HttpClient) { }

  getListofcomponent(): Observable<ComponentProductModel[]> {
    return this._http.get<ComponentProductModel[]>(`${this.component}`)
  }

  getListofInjectionMoldPart(): Observable<any[]> {
    return this._http.get<any[]>(`${this.injectionMoldPart}`)
  }

  getComponentById(id: number): Observable<ComponentProductModel> {
    return this._http.get<ComponentProductModel>(`${this.component}/${id}`)
  }

  createComponent(component: any): Observable<any> {
    return this._http.post<any>(`${this.component}`, component, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }


  getMfgConnectTool(): Observable<any[]> {
    return this._http.get<any[]>(`${this.mfgTool}`)
  }

  updateComponent(component: ComponentProductModel): Observable<void> {
    return this._http.put<void>(`${this.component}`, component, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  getManufacturingProcess(): Observable<any[]> {
    return this._http.get<any[]>(`${this.manufacturingProcess}`)
  }

  deleteComponentById(id: number) {
    return this._http.delete(this.component + "/" + id, { responseType: 'text' })
      .pipe(catchError(this.handleError))
  }

  getRelationship(id: number): Observable<any[]> {
    return this._http.get<any[]>(`${this.relationship}/${id}`)
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }

  isActiveClass(componentList, currComponent) {
    componentList.forEach(element => {
      element.isActive = false;
    });
    currComponent.isActive = true;
  }
}
