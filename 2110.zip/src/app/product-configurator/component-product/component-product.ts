import { OnInit, Component, ViewChild, PipeTransform, Pipe } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { DeleteProduct } from '../delete-plantconfigurator/delete-plantconfigurator';
import { ProductModel } from '../product/product.model';
import { ProductService } from '../product/product.service';
import { ComponentRelationship } from './component-relationship';
import { ComponentProductModel } from './component.model';
import { ComponentService } from './component.service';
import { DataUploadComponent } from '../data-upload/data-upload.component';


@Component({
  selector: 'component-product',
  templateUrl: './component-product.html',
  styleUrls: ['../../plants/plant-configuration/plant-configuration.component.scss', './component-product.scss']
})

export class ComponentProduct implements OnInit {
  componentProductDetails: ComponentProductModel[];
  componentProductDetail: ComponentProductModel = {};
  productDetails: ProductModel[];
  mfgTools: any[];
  hideForm: boolean = false;
  $localComponentId: any;
  noOfManuProcess: any[];
  menumfgconnectTools = new FormControl();
  manufacturingProcesses: any[];
  // getTools:any[] = []

  form: FormGroup

  constructor(private _componentServie: ComponentService, public dialog: MatDialog,
    private _productService: ProductService, private fb: FormBuilder, private _router: Router) {
    this.form = this.fb.group({
      checkArray: this.fb.array([])
    })
  }

  ngOnInit() {
    this.loadComponent();
    this.loadProduct();
    this.loadmfgTools();
    this.getManufacturingProcess()
    this.noOfManuProcess = [{ code: 1, name: 'Process 1' }, { code: 2, name: 'Process 2' }]
  }


  addnew() {
    this._router.navigate([`./add-component`]);
  }

  loadProduct() {
    this._productService.getListofproduct().subscribe(
      data => this.productDetails = data
    )
  }

  loadmfgTools() {
    this._componentServie.getMfgConnectTool().subscribe(
      data => this.mfgTools = data
    )
  }

  getManufacturingProcess() {
    this._componentServie.getManufacturingProcess().subscribe(
      data => {
        // if (data != undefined) {
        //   if (data.length > 1) {
        //     let obj = data[0]
        //     let temp = []
        //     temp.push(obj)
        //     this.manufacturingProcesses = temp
        //   }
        //   else {
        //     this.manufacturingProcesses = data
        //   }
        // }
        this.manufacturingProcesses = data
      }
    )
    this.changeList();
  }

  changeList() {

  }

  details(id) {
    this._router.navigate(['./add-component', id]);
    // this.componentProductDetails.forEach(componentProduct => {
    //   if (componentProduct.id === id) {
    //     this.componentProductDetail = componentProduct;
    //     let tempList = this.componentProductDetail.mfgconnectTools;
    //     if (tempList.length != 0) {
    //       let idList: any = []
    //       for (var i = 0; i < tempList.length; i++) {
    //         let id = tempList[i].id
    //         idList.push(id)
    //       }
    //       this.componentProductDetail.tempTools = idList
    //     }
    //   }
    //   this.hideForm = true;
    // });
  }

  confirmDelete(id) {
    const dialogRef = this.dialog.open(DeleteProduct, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._componentServie.deleteComponentById(id).subscribe((resp) => {
          console.log(`Product deleted with id =  ${id} deleted`, resp);
          () => this.loadComponent();
        })
      }
    })
  }

  showRelationship(getComponentId): void {
    this.$localComponentId = localStorage.setItem('componentId', JSON.stringify(getComponentId));
    const dialogRef = this.dialog.open(ComponentRelationship, {
      width: '450px'
    });
  }

  loadComponent() {
    this._componentServie.getListofcomponent().subscribe(
      data => this.componentProductDetails = data
    )
  }

  getmfgToolsDetails(mfgTools: any[]): string {
    let toolsName: string = '';
    for (var i = 0; i < mfgTools.length; i++) {
      toolsName = toolsName.concat(mfgTools[i].injMoldName).concat(',');
    }
    return toolsName.slice(0, -1);
  }

  // isSelected(getTools){
  //     let status=false;
  //     for(let mfgTool of getTools){
  //         if(mfgTool.id === getTools.id ){
  //             status=true;
  //             break;
  //         }
  //     }
  //     return status
  // }


  save() {
    let allowedMoldList: { id: number }[] = [];
    console.log("data is", typeof (this.menumfgconnectTools))
    if (this.menumfgconnectTools) {

      for (var val of this.menumfgconnectTools.value) {
        allowedMoldList.push({ id: +val });



      }
      this.componentProductDetail.mfgconnectTools = allowedMoldList
      this.componentProductDetail.tempTools = null
    }
    // this.componentProductDetail.mfgconnectTools = mfgTools;
    console.log("object to be saved", this.componentProductDetail)
    if (this.componentProductDetail.id == undefined || this.componentProductDetail.id == null) {

      this._componentServie.createComponent(this.componentProductDetail).subscribe((data) => {
        this.loadComponent();
      });
      this.hideForm = false;
    }
    else {
      this._componentServie.updateComponent(this.componentProductDetail).subscribe(() => {
        this.loadComponent();
      });
    }
    this.hideForm = false;
  }

  cancel() {
    this.componentProductDetail = null;
  }

  upload() {
    const dialogRef = this.dialog.open(DataUploadComponent, {
      width: '400px'
    });
    dialogRef.afterClosed().subscribe(result => {
      // if (result === 'delete') {
      //   this.manufacturingOperationService.deleteProductById(id).subscribe((resp) => {
      //     console.log("operation deleted", resp);
      //     this.loadProduct();
      //   });
      // }
    });
  }
}


@Pipe({ name: 'searchByComponent' })
export class searchByComponent implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.partName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}

@Pipe({ name: 'OrderByComponentPipe' })
export class OrderByComponentPipe implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}
