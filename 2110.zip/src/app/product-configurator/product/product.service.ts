import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';

import { catchError } from 'rxjs/operators';
import { ProductModel } from './product.model';


@Injectable({ providedIn: 'root' })
export class ProductService {
  public product: string = environment.CNC_API_URL + 'api/mfgconnect-product';
  public relationship: string = environment.CNC_API_URL + 'api/mfgconnect-product/get-relationship';
  public components: string = environment.CNC_API_URL + 'api/mfgconnect-injection-molding-part';
  public assemblyProcess: string = environment.CNC_API_URL + 'api/mfgconnect-manufacturing-operation/get-assembly-process';

  constructor(private _http: HttpClient) { }

  getListofproduct(): Observable<ProductModel[]> {
    return this._http.get<ProductModel[]>(`${this.product}`);
  }

  getProductById(id: number): Observable<ProductModel> {
    return this._http.get<ProductModel>(`${this.product}/${id}`);
  }

  getListofComponents(): Observable<any[]> {
    return this._http.get<any[]>(`${this.components}`);
  }

  createProduct(product: ProductModel): Observable<any> {
    return this._http.post<any>(`${this.product}`, product, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateProduct(product: ProductModel): Observable<void> {
    return this._http.put<void>(`${this.product}`, product, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  deleteProductById(id: number) {
    return this._http.delete(this.product + "/" + id, { responseType: 'text' })
      .pipe(catchError(this.handleError))
  }

  getRelationship(id: number): Observable<any[]> {
    return this._http.get<any[]>(`${this.relationship}/${id}`);
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.status !== 200) {
      window.alert(`There is related data in the system. Please delete the data before deleting the asset`);
    }
    return throwError(errorMessage);
  }

  isActiveClass(componentList, currComponent) {
    componentList.forEach(element => {
      element.isActive = false;
    });
    currComponent.isActive = true;
  }

  getListgetAssemblyProcess(): Observable<any[]> {
    return this._http.get<any[]>(`${this.assemblyProcess}`);
  }

}
