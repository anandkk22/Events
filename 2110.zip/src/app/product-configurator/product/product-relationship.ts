import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { ActivatedRoute } from '@angular/router';
import { ProductService } from './product.service';


@Component({
    selector: 'product-relationship',
    templateUrl: './product-relationship.html',
    styleUrls: ['../../plants/relationship-plant/relationship-plant.scss']
})

export class ProductRelationship implements OnInit, OnDestroy{
    private _id: number;
    getRelationship: any[];
    getProductId: any;

    constructor(private _route: ActivatedRoute, private _productService: ProductService,
        private _mdr: MatDialogRef<ProductRelationship>){}


    ngOnInit(){
        this.getProductId = localStorage.getItem('productId');
        this.onLoad();
    }

    onLoad() {
        this._route.paramMap.subscribe(params => {
            this._id = +params.get('id');
            this._productService.getRelationship(this.getProductId).subscribe(
                product => {                   
                    this.getRelationship = product
                }
            )
        })
    }

    onNoClick(): void {
        this._mdr.close();        
    }

    ngOnDestroy(){
        localStorage.removeItem('productId');
    }

}