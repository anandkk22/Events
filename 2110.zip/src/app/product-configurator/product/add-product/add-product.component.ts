import { OnInit, Component, ViewChildren, QueryList, ElementRef, ViewChild } from '@angular/core';
import { ProductFamilyService } from '../../product-family/product-family.service';
import { ProductFamilyModel } from '../../product-family/product.model';
import { PartListModel, ProductModel } from '../product.model';
import { ProductService } from '../product.service';
import { FormArray, FormBuilder, FormControl, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss', '../../../plants/add-plant/add-plant.component.scss']
})

export class AddProduct implements OnInit {
  @ViewChildren("selectAssembly") assemblyProSelects: QueryList<ElementRef<HTMLSelectElement>>;
  @ViewChildren("selectComponentAssembly") assemblyProComponentSelects: QueryList<ElementRef<HTMLSelectElement>>;
  @ViewChild('firstForm', { static: false }) public firstFormName: NgForm;
  @ViewChild('secondForm', { static: false }) public secondFormName: NgForm;

  componentArr: PartListModel[] = [];
  assemblyArr = [];

  componentDetails: any[];
  assemblyProcess: any[];
  addedAllAssemblyProcs: boolean = false;

  submitted: boolean = false;
  existing: number = 1;

  title: string = '';
  requiredField: string;
  productDetails: ProductModel[];
  productFamilyDetails: ProductFamilyModel[];
  productDetail: ProductModel = {};

  constructor(private _productService: ProductService,
    private _productFamilyService: ProductFamilyService, private _router: Router,
    private _route: ActivatedRoute
  ) {

  }

  ngOnInit() {
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
      this.getProduct(id);
    })
    this.loadComponents();
    this.getListAssemblyProcess();
    this.loadProduct();
    this.loadProductFamily();
  }

  loadProduct() {
    this._productService.getListofproduct().subscribe(
      data => this.productDetails = data
    )
  }

  loadProductFamily() {
    this._productFamilyService.getListofproductFamily().subscribe(
      data => this.productFamilyDetails = data
    )
  }

  loadComponents() {
    this.componentDetails = [];
    this._productService.getListofComponents().subscribe(
      data => {
        this.componentDetails = data;

      }
    )
  }

  getListAssemblyProcess() {
    this.assemblyProcess = [];
    this._productService.getListgetAssemblyProcess().subscribe(
      data => {
        this.assemblyProcess = data;
      }
    )
  }

  addComponent() {
    this.componentArr.push({ mfgconnectPartId: null, quantity: 1 });
  }

  deleteComponentValue(index: number) {
    this.componentArr.splice(index, 1);
  }

  addAssemblyProcess() {
    if (this.assemblyProcess.length > this.assemblyArr.length) {
      let newSequence = this.assemblyArr.length + 1;
      this.assemblyArr.push({ mfgconnectManufacturingOperationId: null, sequence: newSequence });
    } else {
      this.addedAllAssemblyProcs = true;
    }
    console.log(this.assemblyArr);
  }

  deleteAssemblyProcess(index: number) {
    console.log(this.assemblyProcess);
    this.assemblyArr.splice(index, 1);

    for (let index = 0; index < this.assemblyArr.length; index++) {
      const currIndex = index + 1;
      this.assemblyArr[index].sequence = currIndex;
    }
    if (this.assemblyProcess.length > this.assemblyArr.length) {
      this.addedAllAssemblyProcs = false;
    }
    console.log(this.assemblyArr);
  }

  saveProduct() {
    this.submitted = true;
    if (this.firstFormName.invalid || this.secondFormName.invalid) {
      this.requiredField = "Required fields are missing, Please check";
      return;
    } else {
      for (let index = 0; index < this.assemblyArr.length; index++) {
        const currIndex = index + 1;
        this.assemblyArr[index].sequence = currIndex;
      }
      this.productDetail.partList = this.componentArr;
      this.productDetail.sequence = this.assemblyArr;

      console.log(this.productDetail);
      if (this.productDetail.id == null) {
        this._productService.createProduct(this.productDetail).subscribe(
          (data: any) => {
            this._router.navigate(['/productConfig/product']);
          }
        )
      } else {
        this._productService.updateProduct(this.productDetail).subscribe(
          () => {
            this._router.navigate(['/productConfig/product']);
          }
        )
      }
    }
  }

  cancel() {
    this._router.navigate(['/productConfig/product'])
  }

  private getProduct(id: number) {
    if (id === 0) {
      this.productDetail = {};
      this.title = "Add new";
    } else {
      this.title = "Edit";
      this._productService.getProductById(id).subscribe(
        (product) => {
          this.productDetail = product;
          console.log(this.productDetail);
          if (this.productDetail.partList.length > 0) {
            this.componentArr = this.productDetail.partList;
          } else {
            this.componentArr = [{ mfgconnectPartId: null, quantity: 0 }];
          }
          if (this.productDetail.sequence !== null) {
            this.assemblyArr = this.productDetail.sequence;
          } else {
            this.assemblyArr = [{ mfgconnectManufacturingOperationId: null, sequence: 1 }];
          }
        }
      )
    }
  }


}
