export class ProductModel {
  id?: number;
  productName?: string;
  productNumber?: string;
  productDescription?: string;
  erpProductCode?: string;
  erpMaterialCode?: string;
  erpProductNumber?: string;
  mfgconnectAssemblyProcessId?: number
  mfgconnectProductFamilyId?: number;
  productType?: string;
  familyName?: string;
  processPhase?: string;
  noOfManuProcessId?: string;
  partList? : PartListModel[];
  sequence?: SequenceModel[];
}

export class AssemblyProcessModel {
  id?: number;
  processType?: string;
  displayName?: string;
}

export class PartListModel {
  mfgconnectPartId?: number;
  quantity?: number;
}

export class SequenceModel {
  mfgconnectAssemblyProcessId: number;
  sequence: number;
}
