import { OnInit, Component, ViewChild, PipeTransform, Pipe } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DeleteProduct } from '../delete-plantconfigurator/delete-plantconfigurator';
import { ProductRelationship } from './product-relationship';
import { ProductModel } from './product.model';
import { ProductService } from './product.service';
import { FormControl } from '@angular/forms';
import { ProductFamilyModel } from '../product-family/product.model';
import { ProductFamilyService } from '../product-family/product-family.service';
import { AssemblyProcessService } from 'src/app/library/parameter-tags/assembly-process/assembly-process.service';
import { Router } from '@angular/router';
import { DataUploadComponent } from '../data-upload/data-upload.component';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styleUrls: ['../../plants/plant-configuration/plant-configuration.component.scss', './product.component.scss']
})

export class Product implements OnInit {
  productDetails: ProductModel[];
  productFamilyDetails: ProductFamilyModel[];

  productDetail: ProductModel = {};
  hideForm: boolean = false
  $localProductId: any;
  // noOfManuProcess: any[];
  menuProcess = new FormControl();
  assemblyProcesses: any[];
  selectedManuProcess;
  components: any[];

  constructor(private _productService: ProductService, private assemblyService: AssemblyProcessService, public dialog: MatDialog,
    private _productFamilyService: ProductFamilyService, private _router: Router) { }

  ngOnInit() {
    this.loadProduct();
    this.loadProductFamily();
    this.getAssemblyProcess();
    this.loadComponents();
    // this.noOfManuProcess = [{ code: 1, name: 'Process 1' }, { code: 2, name: 'Process 2' }, { code: 3, name: 'Process 3' }, { code: 4, name: 'Process 4' }]
  }

  getAssemblyProcess() {
    this.assemblyService.getAssemblyProcessList().subscribe(data => this.assemblyProcesses = data)
  }

  addnew() {
    this._router.navigate([`./add-product`]);
  }


  details(productId) {
    this._router.navigate(['/add-product', productId]);  
  }

  loadProduct() {
    this._productService.getListofproduct().subscribe(
      data => this.productDetails = data
    )
  }

  loadProductFamily() {
    this._productFamilyService.getListofproductFamily().subscribe(
      data => this.productFamilyDetails = data
    )
  }

  loadComponents() {
    // this._componentServie.getMfgConnectTool().subscribe(
    //   data => this.components = data
    // )
  }

  getComponentDetails(components: any[]): string {
    let compName: string = '';
    for (var i = 0; i < components.length; i++) {
      compName = compName.concat(components[i].injMoldName).concat(',');
    }
    return compName.slice(0, -1);
  }
  
  confirmDelete(id) {
    const dialogRef = this.dialog.open(DeleteProduct, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this._productService.deleteProductById(id).subscribe((resp) => {
          console.log(`Product deleted with id =  ${id} deleted`, resp);
          () => this.loadProduct();
        })
      }
    })
  }

  showRelationship(getProductId): void {
    this.$localProductId = localStorage.setItem('productId', JSON.stringify(getProductId));
    const dialogRef = this.dialog.open(ProductRelationship, {
      width: '450px'
    });
  }

  save() {
    if (this.productDetail.id == undefined || this.productDetail.id == null) {
      this._productService.createProduct(this.productDetail).subscribe((data) => {
        this.loadProduct();
      });
      this.hideForm = false;
    }
    else {
      this._productService.updateProduct(this.productDetail).subscribe(() => {
        this.loadProduct();
      });
    }
    this.hideForm = false;
  }

  cancel() {
    this.productDetail = null;
  }

  upload() {
    const dialogRef = this.dialog.open(DataUploadComponent, {
      width: '400px'
    });
    dialogRef.afterClosed().subscribe(result => {
      // if (result === 'delete') {
      //   this.manufacturingOperationService.deleteProductById(id).subscribe((resp) => {
      //     console.log("operation deleted", resp);
      //     this.loadProduct();
      //   });
      // }
    });
  }
}

@Pipe({ name: 'searchByProductName' })
export class searchByProductName implements PipeTransform {
  transform(items: any[], searchTerm: string): any[] {
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.productName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}

@Pipe({ name: 'OrderByProductPipe' })
export class OrderByProductPipe implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}
