import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { pidiliteMainModel } from 'src/app/models/pidilite-model';


@Component({
  selector: 'app-plant-configuration',
  templateUrl: './product-configurator.component.html',
  styleUrls: ['./product-configurator.component.scss']
})

export class ProductConfigurationComponent implements OnInit {
  plantConfigDetails: any = [];
  currRoute: string = null;
  plant: pidiliteMainModel;
  private _id: number;


  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
  ) { }
  ngOnInit() {
    this.checkRoute();
    // this.menuItems.splice(0, 0, {
    //     name: '',
    //     children: [
    //         {
    //             name: '',
    //             router: null,
    //             // secondLine: this.plant.id
    //             secondLine: null
    //         }
    //     ]
    // });

  }


  menuItems = [
    {
      name: '',
      children: [
        { name: 'Manufacturing Operations', router: 'manufacturing-operation', secondLine: null },
        { name: 'Product Family', router: 'productFamily', secondLine: null },
        { name: 'Product', router: 'product', secondLine: null },
        { name: 'Component', router: 'component', secondLine: null }
        // { name: 'Mold Master', router: 'moldMaster', secondLine: null }
      ]
    }
  ];

  checkRoute() {
    this.currRoute = this._router.url.split('/').pop();

  }
  changeRoute(newRoute) {
    this.currRoute = newRoute;


  }
}

