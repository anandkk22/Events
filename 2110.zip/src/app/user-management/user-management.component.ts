import { Component, OnInit, Inject } from '@angular/core';
import { UserManagementService } from './user-management.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { CreateUserManagementComponent } from './create/create-user-management';
import { Router } from '@angular/router';
import { DeletePermisionItem } from './permission-management/permission-management.component';

@Component({
    selector: 'user-management',
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {
    // users: any[];
    users = [];

    currentPage = 1;
    page = 1;
    pageSize = 10;
    stItemsByPage = 10;

    constructor(
        public dialog: MatDialog,
        private matDialog: MatDialog,
        private route: Router,
        private service: UserManagementService) { }



    ngOnInit() {
        this.getUserList();
    }

    getUserList() {
        this.service.getListofUsers().subscribe((resp) => {
            this.users = resp;
            console.log("user", this.users);
        });
    }

    createUserManagement() {
        this.route.navigate(['user-management/new']);
    }

    edit(login) {
        this.route.navigate(['user-management', login, 'edit']);
    }

    view(login) {
        this.route.navigate(['user-management', login, 'view']);
    }

    confirmDelete(login): void {
        const dialogRef = this.matDialog.open(DeletePermisionItem, {

        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this.service.deleteUser(login).subscribe(() =>
                    this.getUserList()
                );

            }
        })

    }

}






