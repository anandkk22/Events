import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RoleManagementService } from '../role-management.service';

@Component({
    selector: 'permission-management',
    templateUrl: './dialog-edit-permission.component.html',
    styleUrls: ['../role-management.component.scss']
})
export class DialogEditPermissionComponent implements OnInit {
    permissions = [];
    allRoleDetails: any[] = [];
    userPermissions: any[];

    rolesPermissions: any[] = [];
    getRoleId: string;
    editPermissionForm: FormGroup;
    constructor(private _roleManagementService: RoleManagementService,
        private _route: ActivatedRoute,
        private fb: FormBuilder,
        public dialog: MatDialog) { }

    ngOnInit() {
        this.getAllRoles();
        this.getRoleId = localStorage.getItem('roleId');
        this._route.paramMap.subscribe(parameterMap => {
            const id = +parameterMap.get('id');
        });
        this.editPermissionForm = this.fb.group({
            editPermissionControl: []
        });
        this._roleManagementService.getRolePermissionByRollId(this.getRoleId).subscribe((data) => {
            this.userPermissions = data
        });

    }

    getAllRoles() {
        this._roleManagementService.getReferenccePermissions().subscribe(
            (roles) => {
                this.allRoleDetails = roles
            });
    }


    getRoleById() {
        this._roleManagementService.getRolePermissionByRollId(this.getRoleId).subscribe(
            (data) => {
                this.rolesPermissions = data;
                console.log("jjjjj", this.rolesPermissions);
            });
    }

}