import { Component, OnInit } from '@angular/core';
import { RoleManagementService } from './role-management.service';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DialogEditPermissionComponent } from './edit/dialog-edit-permission.component';

@Component({
    selector: 'role-management',
    templateUrl: './role-management.component.html',
    styleUrls: ['./role-management.component.scss']
})
export class RoleManagementComponent implements OnInit {
    authorities: any[];
    editPermissionForm: FormGroup;
    getRoleId: any;
    $localRoleId: any;
    allRoleDetails: any[] = [];
    rolesPermissions: any[] = [];
    permissions: any = [];

    constructor(private _roleManagementService: RoleManagementService,
        private _route: ActivatedRoute,
        public dialog: MatDialog) { }

    ngOnInit() {
        this.getRoleId = localStorage.getItem('roleId');
        this._route.paramMap.subscribe(parameterMap => {
            const id = +parameterMap.get('id');
        })
        this.getRoles();
        this.getRoleById();
    }

    getRoles() {
        this._roleManagementService.getAllRoles().subscribe(
            authority => {
                this.authorities = authority
            }
        )
    }

    editPermission(getRoleId) {
        this.getAllRoles();
        this.getRoleById();
        this.$localRoleId = localStorage.setItem('roleId', getRoleId);
        console.log("********");
        console.log(this.allRoleDetails);
        console.log(this.rolesPermissions);
        const dialogRef = this.dialog.open(DialogEditPermissionComponent, {
            width: '450px',
        });

        dialogRef.afterClosed().subscribe(result => {
            this.permissions = result;
            console.log("reee", result);
            if (this.permissions.length !== 0) {
                /* Passing permissions selected in dialog to API */
                this._roleManagementService.createRolePermission(this.getRoleId, this.permissions).subscribe((resp) => {
                });
            }
        });
    }

    getAllRoles(): any {
        this._roleManagementService.getReferenccePermissions().subscribe(
            (roles: any[]) => {

                this.allRoleDetails = roles
            });
    }

    getRoleById() {
        this._roleManagementService.getRolePermissionByRollId(this.getRoleId).subscribe(
            (data: any[]) => {
                this.rolesPermissions = data;
                console.log(this.rolesPermissions);
            }
        )
    }

}
