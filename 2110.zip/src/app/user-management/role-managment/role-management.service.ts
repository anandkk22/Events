import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class RoleManagementService {
    public roleType: string = '../../assets/json/roles.json';
    public permissionType: string = '../../assets/json/permission.json';
    public roleUrl: string = environment.PROCESS_API_URL + 'api/userrole';
    public permissionUrl: string = environment.PROCESS_API_URL + 'api/permission';
    public authUrl: string = environment.AUTH_URL + 'api/';

    constructor(private _http: HttpClient) { }

    getAllRoles(): Observable<any[]> {
        return this._http.get<any[]>(this.authUrl + 'roles');
    }

    getRolePermissionByRollId(code): Observable<any[]> {
        return this._http.get<any[]>(this.authUrl + 'role-permission-rel/' +code );
    }

    // getPermissionType(): Observable<any[]> {
    //     return this._http.get<any[]>(`${this.permissionType}`);
    // }

    getReferenccePermissions(): Observable<any[]> {
        return this._http.get<any[]>(this.authUrl + 'permission');
    }

    createRolePermission(roleCode, permissions): Observable<any[]> {
        return this._http.put<any[]>(this.authUrl + 'role-permission-rel/' + roleCode, permissions);
    }

}