import { Component, OnInit } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserManagementService } from '../user-management.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RoleManagementService } from '../role-managment/role-management.service';
import { UserProfileService } from './user-profile.service';

@Component({
    selector: 'create-user-profile',
    templateUrl: './create-user-profile.html',
    styleUrls: ['./user-profile.component.scss']
})
export class CreateUserProfileComponent implements OnInit {

    apolloUserOrgRel: any = {};
    private _id: number;
    organizationRoles: any = [];
    users: any = [];
    organizations: any = [];
    isView: boolean = false;
    isEdit: boolean = false;
    constructor(private route: Router,
        private matDialog: MatDialog,
        private service: UserProfileService,
        private _route: ActivatedRoute, ) { }


    ngOnInit() {
        this.isView = false;
        this.isEdit = false;
        this.apolloUserOrgRel = {};
        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
            console.log("idddd", this._id);
        })
        if (this._id != 0) {
            this.service.getUserProfileById(this._id).subscribe((resp) => {
                this.apolloUserOrgRel = resp;
            });
        }

        if (this.route.url.endsWith("/view")) {
            this.isView = true;
            this.isEdit = false;
        }
        if (this.route.url.endsWith("/edit") || this.route.url.endsWith("/new")) {
            this.isEdit = true;
            this.isView = false;

        }

        this.service.getListofUsers().subscribe((resp) => {
            this.users = resp;
            console.log("user", this.users);
        });

        this.service.getOrganizations().subscribe((resp) => {
            this.organizations = resp;
            console.log("orgg", this.organizations);
        });
        this.service.getOrganizationRoleList().subscribe((resp) => {
            this.organizationRoles = resp;
            console.log("orgg", this.organizationRoles);
        });

    }

    save() {
        console.log("new org", this.apolloUserOrgRel);
        this.service.createNewUserProfile(this.apolloUserOrgRel).subscribe((resp) => {
            this.route.navigate(['./user-profile']);
        });
    }

    cancel() {
        this.route.navigate(['./user-profile']);
    }
    back() {
        this.route.navigate(['./user-profile']);
    }
}