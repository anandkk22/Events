import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PlantOrgRelationService {

  public url: string = environment.PROCESS_API_URL + 'api/';
  public authUrl: string = environment.AUTH_URL + 'api/';
  public discretapp = environment.CNC_API_URL + 'api/';

  constructor(private http: HttpClient) { }

  getOrganizationsByType(type): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'organization/Type/' + type);
  }

  getAllPlants(): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'plants');
  }

  createPlantOrgRel(data): Observable<any> {
    return this.http.post<any>(this.discretapp + 'plant-org-rel', data);
  }

  getUserProfileList(): Observable<any> {
    return this.http.get<any>(this.discretapp + 'plant-org-rel/all');
  }

  getPlantOrgRelById(id): Observable<any> {
    return this.http.get<any>(this.discretapp + 'plant-org-rel/' + id);
  }

  deletePlantOrgRel(id): Observable<any> {
    return this.http.delete<any>(this.discretapp + 'plant-org-rel/' + id, { responseType: 'text' as 'json' });
  }
}
