import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PlantOrgRelationService } from './plant-org-relation.service';
import { MatDialog } from '@angular/material';
import { DeletePermisionItem } from '../permission-management/permission-management.component';

@Component({
  selector: 'app-plant-org-relation',
  templateUrl: './plant-org-relation.component.html',
  styleUrls: ['./plant-org-relation.component.scss']
})
export class PlantOrgRelationComponent implements OnInit {

  apolloPlantOrgRels: any;

  constructor(private route: Router,
    private service: PlantOrgRelationService,
    public dialog: MatDialog,
    private matDialog: MatDialog) { }

  ngOnInit() {
    this.getPlantOrgRelList();
  }

  getPlantOrgRelList() {
    this.service.getUserProfileList().subscribe((resp) => {
      this.apolloPlantOrgRels = resp;
      console.log("user", this.apolloPlantOrgRels);
    });
  }

  createNewPlantOrgRelation() {
    this.route.navigate(['plant-org-rel/new']);

  }

  edit(id: number) {
    this.route.navigate(['plant-org-rel', id, 'edit']);
  }

  view(id: number) {
    this.route.navigate(['plant-org-rel', id, 'view']);
  }

  confirmDelete(id): void {
    const dialogRef = this.matDialog.open(DeletePermisionItem, {

    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.service.deletePlantOrgRel(id).subscribe(() =>
          this.getPlantOrgRelList()
        );

      }
    })

  }

}
