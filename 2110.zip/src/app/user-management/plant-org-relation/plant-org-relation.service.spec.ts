import { TestBed } from '@angular/core/testing';

import { PlantOrgRelationService } from './plant-org-relation.service';

describe('PlantOrgRelationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlantOrgRelationService = TestBed.get(PlantOrgRelationService);
    expect(service).toBeTruthy();
  });
});
