import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PlantOrgRelationService } from './plant-org-relation.service';


@Component({
    selector: 'create-plant-org-relation',
    templateUrl: './create-plant-org-relation.html',
    styleUrls: ['./plant-org-relation.component.scss']
})
export class CreatePlantOrgRelComponent implements OnInit {
    plantOrgRel = {};
    enterpriseOrg: any = [];
    resellerOrg: any;
    plantList: any;
    private _id: number;
    isView: boolean = false;
    isEdit: boolean = false;
    plantOrgRels: any = [];
    constructor(private route: Router,
        private service: PlantOrgRelationService,
        private _route: ActivatedRoute) { }

    ngOnInit() {
        this.plantOrgRel = {};

        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
            console.log("idddd", this._id);
        })
        if (this._id != 0) {
            this.service.getPlantOrgRelById(this._id).subscribe((resp) => {
                this.plantOrgRel = resp;
            });
        }

        if (this.route.url.endsWith("/view")) {
            this.isView = true;
            this.isEdit = false;
        }
        if (this.route.url.endsWith("/edit") || this.route.url.endsWith("/new")) {
            this.isEdit = true;
            this.isView = false;

        }

        this.service.getAllPlants().subscribe((resp) => {
            this.plantList = resp;
            console.log("roles", this.plantList);
            if (this.plantList != null) {
                this.service.getUserProfileList().subscribe((resp) => {
                    this.plantOrgRels = resp;
                    console.log("user", this.plantOrgRels);
                    for (let i = 0; i < this.plantOrgRels.length; i++) {
                        if (this.isEdit && this.plantOrgRels[i].id != this._id)
                            this.plantList = this.plantList.filter(plant => plant.id != this.plantOrgRels[i].plantId);
                    }

                    console.log("filterd plants", this.plantList);
                });
            }
        });

        this.service.getOrganizationsByType('ENTERPRISE').subscribe((resp) => {
            this.enterpriseOrg = resp;
            console.log("roles", this.enterpriseOrg);
        });

        this.service.getOrganizationsByType('RESELLER').subscribe((resp) => {
            this.resellerOrg = resp;
            console.log("roles", this.resellerOrg);
        },
            (error) => {
                console.log("error", error);
            }
        );



    }

    save() {
        console.log("new org", this.plantOrgRel);
        this.service.createPlantOrgRel(this.plantOrgRel).subscribe((resp) => {
            this.route.navigate(['./plant-org-rel']);
        });
    }

    cancel() {
        this.route.navigate(['./plant-org-rel']);
    }
    back() {
        this.route.navigate(['./plant-org-rel']);
    }
}