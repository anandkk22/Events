import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlantOrgRelationComponent } from './plant-org-relation.component';

describe('PlantOrgRelationComponent', () => {
  let component: PlantOrgRelationComponent;
  let fixture: ComponentFixture<PlantOrgRelationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlantOrgRelationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlantOrgRelationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
