import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-access-menu',
  templateUrl: './access-menu.component.html',
  styleUrls: ['./access-menu.component.scss']
})
export class AccessMenuComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  navigation(url) {
    if (url !== undefined) {
      console.log(url)
      this.router.navigate([url]);
    }
  }
}
