import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrganizationRoleService } from './organization-role.service';
import { MatDialog } from '@angular/material';
import { DeletePermisionItem } from '../permission-management/permission-management.component';

@Component({
  selector: 'app-organization-role-management',
  templateUrl: './organization-role-management.component.html',
  styleUrls: ['./organization-role-management.component.scss']
})
export class OrganizationRoleManagementComponent implements OnInit {

  apolloOrganisationRoles:any;
  constructor(private route: Router,
    private service: OrganizationRoleService,
    public dialog: MatDialog,
    private matDialog: MatDialog,) { }

  ngOnInit() {
    this.getOrganizationRoleList();
  }

  getOrganizationRoleList() {
    this.service.getOrganizationRoleList().subscribe((resp) => {
      this.apolloOrganisationRoles = resp;
      console.log("user", this.apolloOrganisationRoles);
    });
  }

  createOrganizationRole() {
    this.route.navigate(['organization-role/new']);

  }

  edit(id: number) {
    this.route.navigate(['organization-role', id, 'edit']);
  }

  view(id: number) {
    this.route.navigate(['organization-role', id, 'view']);
  }

  confirmDelete(login): void {
    const dialogRef = this.matDialog.open(DeletePermisionItem, {

    });
    dialogRef.afterClosed().subscribe(result => {
        if (result === 'delete') {
            this.service.deleteOrganizationRole(login).subscribe(() =>
                this.getOrganizationRoleList()
            );

        }
    })

}
}
