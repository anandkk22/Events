import { Component, OnInit } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserManagementService } from '../user-management.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RoleManagementService } from '../role-managment/role-management.service';
import { OrganizationRoleService } from './organization-role.service';

@Component({
    selector: 'create-organization-role',
    templateUrl: './create-organization-role.html',
    styleUrls: ['./organization-role-management.component.scss']
})
export class CreateOrganizationRoleComponent implements OnInit {

    private _id: number;
    apolloOrganisationRole: any = {};
    isView: boolean = false;
    isEdit: boolean = false;
    constructor(private route: Router,
        private matDialog: MatDialog,
        private _route: ActivatedRoute,
        private service: OrganizationRoleService) { }

    ngOnInit() {
        this.isView = false;
        this.isEdit = false;
        this.apolloOrganisationRole = {};
        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
            console.log("idddd", this._id);
        })
        if (this._id != 0) {
            this.service.getOrganizationRoleById(this._id).subscribe((resp) => {
                this.apolloOrganisationRole = resp;
            });
        }

        if (this.route.url.endsWith("/view")) {
            this.isView = true;
            this.isEdit = false;
        }
        if (this.route.url.endsWith("/edit") || this.route.url.endsWith("/new")) {
            this.isEdit = true;
            this.isView = false;

        }
    }

    save() {
        console.log("new org", this.apolloOrganisationRole);
        this.service.createOrganizationRole(this.apolloOrganisationRole).subscribe((resp) => {
            this.route.navigate(['./organization-role']);
        });
    }

    cancel() {
        this.route.navigate(['./organization-role']);
    }
    back() {
        this.route.navigate(['./organization-role']);
    }
}
