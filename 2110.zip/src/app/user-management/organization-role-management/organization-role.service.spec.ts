import { TestBed } from '@angular/core/testing';

import { OrganizationRoleService } from './organization-role.service';

describe('OrganizationRoleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OrganizationRoleService = TestBed.get(OrganizationRoleService);
    expect(service).toBeTruthy();
  });
});
