import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganizationRoleManagementComponent } from './organization-role-management.component';

describe('OrganizationRoleManagementComponent', () => {
  let component: OrganizationRoleManagementComponent;
  let fixture: ComponentFixture<OrganizationRoleManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrganizationRoleManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganizationRoleManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
