import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OrganizationRoleService {
  public authUrl: string = environment.AUTH_URL + 'api/';

  public url: string = environment.PROCESS_API_URL + 'api/';

  public discretapp: string = environment.CNC_API_URL + 'api/';

  constructor(private http: HttpClient) { }

  createOrganizationRole(data): Observable<any[]> {
    return this.http.post<any[]>(this.discretapp + 'organization-role', data);

  }

  getOrganizationRoleList(): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'organization-role/all');
  }

  getOrganizationRoleById(id): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'organization-role/' + id);
  }

  deleteOrganizationRole(id): Observable<void> {
    return this.http.delete<void>(this.discretapp + 'organization-role/' + id, { responseType: 'text' as 'json' });
  }
}
