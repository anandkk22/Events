import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrganizationManagementService } from './organization-management.service';
import { Sort, MatDialog } from '@angular/material';
import { DeletePermisionItem } from '../permission-management/permission-management.component';

@Component({
  selector: 'app-organization-management',
  templateUrl: './organization-management.component.html',
  styleUrls: ['./organization-management.component.scss']
})
export class OrganizationManagementComponent implements OnInit {

  currentPage = 1;
  page = 1;
  pageSize = 10;
  stItemsByPage = 10;
  
  constructor(private route: Router,
    private service: OrganizationManagementService,
    private matDialog: MatDialog) { }

  public organizations: any;

  ngOnInit() {
    this.loadOrganisation();

  }

  loadOrganisation() {
    this.service.getOrganizations().subscribe((resp) => {
      this.organizations = resp;
      console.log("orgg", this.organizations);
    });
  }

  sortData(sort: Sort) {
    const data = this.organizations.slice();
    if (!sort.active || sort.direction === '') {
      this.organizations = data;
      return;
    }


  }

  createNewOrganization() {
    this.route.navigate(['organization/new']);
  }

  edit(id: number) {
    this.route.navigate(['organization', id, 'edit']);
  }

  view(id: number) {
    this.route.navigate(['organization', id, 'view']);
  }

  confirmDelete(id): void {
    const dialogRef = this.matDialog.open(DeletePermisionItem, {

    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.service.deleteOrganization(id).subscribe(() =>
          this.loadOrganisation()
        );

      }
    })

  }
}
