import { Component, OnInit, Inject, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RelatedOrganizationService } from 'src/app/plants/add-plant/related-organizations/related-organization.service';
import { OrganizationManagementService } from './organization-management.service';
import { JhiDataUtils } from 'src/app/core';


@Component({
    selector: 'create-organization',
    templateUrl: './create-organization.html',
    // styleUrls: ['../../role-managment/role-management.component.scss']
})


export class CreateOrganizationComponent implements OnInit {

    public organizationTypes: any;
    public organisation: any = {};
    isView: boolean = false;
    isEdit: boolean = false;

    private _id: number;
    constructor(
        private _route: ActivatedRoute,
        private route: Router,
        private service: OrganizationManagementService,
        protected dataUtils: JhiDataUtils,
        protected elementRef: ElementRef

    ) { }

    ngOnInit() {
        this.isView = false;
        this.isEdit = false;
        this.organisation = {};
        this.service.getOrganizationTypes().subscribe((resp) => {
            this.organizationTypes = resp;
            this.organizationTypes = this.organizationTypes.filter(word => word.name != "DEVOPS");
            console.log("orggt", this.organizationTypes);
        });

        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
        })
        if (this._id != 0) {
            this.service.getOrganizationById(this._id).subscribe((resp) => {
                this.organisation = resp;
            });
        }
        if (this.route.url.endsWith("/view")) {
            this.isView = true;
            this.isEdit = false;
        }
        if (this.route.url.endsWith("/edit") || this.route.url.endsWith("/new")) {
            this.isEdit = true;
            this.isView = false;

        }

    }

    save() {
        console.log("new org", this.organisation);
        this.service.createNewOrganization(this.organisation).subscribe((resp) => {
            this.route.navigate(['./organization']);
        });

    }

    cancel() {
        this.route.navigate(['./organization']);
    }
    back() {
        this.route.navigate(['./organization']);
    }


    byteSize(field) {
        return this.dataUtils.byteSize(field);
      }
    
      openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
      }
    
      setFileData(event, field: string, isImage) {
        return new Promise((resolve, reject) => {
          if (event && event.target && event.target.files && event.target.files[0]) {
            const file: File = event.target.files[0];
            if (isImage && !file.type.startsWith('image/')) {
              reject(`File was expected to be an image but was found to be ${file.type}`);
            } else {
              const filedContentType: string = field + 'ContentType';
              this.dataUtils.toBase64(file, base64Data => {
               
                this.organisation.organizationImage = base64Data;
                this.organisation.organizationImageContentType = file.type;
                
              });
            }
          } else {
            reject(`Base64 data was not set as file could not be extracted from passed parameter: ${event}`);
          }
        }).then(
          // eslint-disable-next-line no-console
          () => console.log('blob added'), // success
        );
      }
    
      clearInputImage(field: string, fieldContentType: string, idInput: string) {
        this.organisation.organizationImage = null;
        this.organisation.organizationImageContentType = null;

        if (this.elementRef && idInput && this.elementRef.nativeElement.querySelector('#' + idInput)) {
          this.elementRef.nativeElement.querySelector('#' + idInput).value = null;
        }
      }

}