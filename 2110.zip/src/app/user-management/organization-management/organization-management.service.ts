import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrganizationManagementService {

  public url: string = environment.PROCESS_API_URL + 'api/';

  public discretapp: string = environment.CNC_API_URL + 'api/';

  constructor(private http: HttpClient) { }

  getOrganizations(): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'org/all');
  }

  getOrganizationTypes(): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'organizationType');
  }

  createNewOrganization(data): Observable<any[]> {
    return this.http.post<any[]>(this.discretapp + 'org', data);
  }

  getOrganizationById(id): Observable<any> {
    return this.http.get<any>(this.discretapp + 'org/' + id);
  }

  deleteOrganization(id: number): Observable<void> {
    return this.http.delete<void>(this.discretapp + 'org/' + id, { responseType: 'text' as 'json' });
  }
}
