import { TestBed } from '@angular/core/testing';

import { OrganizationManagementService } from './organization-management.service';

describe('OrganizationManagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OrganizationManagementService = TestBed.get(OrganizationManagementService);
    expect(service).toBeTruthy();
  });
});
