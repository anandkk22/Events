import { Component, OnInit } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserManagementService } from '../user-management.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RoleManagementService } from '../role-managment/role-management.service';

@Component({
    selector: 'create-user-management',
    templateUrl: './create-user-management.html',
    styleUrls: ['../user-management.component.scss']
})
export class CreateUserManagementComponent implements OnInit {
    languages: any[];
    private _id: any;
    user: any = {
    };
    isView: boolean = false;
    isEdit: boolean = false;
    authorities: any = [];
    organizations: any = [];
    auth: any = [];
    constructor(private _userManagement: UserManagementService,
        public dialog: MatDialog,
        private route: Router,
        private _route: ActivatedRoute,
        private service: UserManagementService
    ) { }

    ngOnInit() {
        this.user = {};
        this._route.paramMap.subscribe(parameterMap => {
            this._id = parameterMap.get('login');
            console.log("idddd", this._id );
        })
        if (this._id != 0) {
            this.service.getUserById(this._id).subscribe((resp) => {
                this.user = resp;
            });
        }

        if (this.route.url.endsWith("/view")) {
            this.isView = true;
            this.isEdit = false;
        }
        if (this.route.url.endsWith("/edit") || this.route.url.endsWith("/new")) {
            this.isEdit = true;
            this.isView = false;

        }

        this.service.getAuthorities().subscribe((resp) => {
            this.authorities = resp;
            console.log("roles", this.authorities);
        });

        this.service.getOrganizations().subscribe((resp) => {
            this.organizations = resp;
        });
    }

    save() {
        console.log("user", this.user);
        if (this.user.id == undefined && this.user.id == null) {
            this.service.createNewUser(this.user).subscribe((resp) => {
                this.route.navigate(['./user-management']);
            });
        }
        else{
       
            this.service.updateUser(this.user).subscribe((resp) => {
                this.route.navigate(['./user-management']);
            });
        }
        
    }
    cancel() {
        this.route.navigate(['./user-management']);
    }
    back() {
        this.route.navigate(['./user-management']);
    }
}