import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'adminPanelFrontPage',
    template: `<div class="mainDiv"></div>
    <div class="plant-content">
        <h1>Welcome to Process360 Admin Panel</h1>
        <h2>YOU CAN SETUP DATA FROM HERE</h2>
    </div>`,
    styles: [`
    .mainDiv {
        background-image: url('../../assets/Images/adminPanelBgImage.jpg');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        display: block;
        filter: blur(8px);
        -webkit-filter: blur(8px);
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        height: 93%;
        margin-top: 2%;
        overflow: hidden;
    }
    
    .plant-content {
        background-color: #000;
        background-color: rgba(0,0,0,.4);
        color: #fff;
        font-weight: 700;
        border: 3px solid #f1f1f1;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
        z-index: 2;
        width: 80%;
        padding: 20px;
        text-align: center; 
    }`]

})
export class AdminPanelFrontPage implements OnInit {

    ngOnInit(){
        
    }
}