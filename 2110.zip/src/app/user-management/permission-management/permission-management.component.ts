import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { PermissionManagementService } from './permission-management.service';
import { Pipe, PipeTransform } from '@angular/core';
import { orderBy, sortBy } from 'lodash';
import { Sort } from '@angular/material';
import { PermissionModel } from './permission.model';

@Component({
    selector: 'permission-management',
    templateUrl: './permission-management.component.html',
    styleUrls: ['./permission-management.component.scss']
})
export class PermissionManagementComponent implements OnInit {
    users = [];
    currentPage = 1;
    page = 1;
    pageSize = 10;
    permissions: PermissionModel[] = [];

    constructor(private _permissionManagementService: PermissionManagementService,
        public dialog: MatDialog,
        private matDialog: MatDialog,
        private route: Router,
        private _route: ActivatedRoute) {
        // for (let i = 1; i <= 100; i++) {
        //     this.users.push({ i });
        // }
        this._permissionManagementService.getReferenccePermissions().subscribe(
            permission => {
                this.permissions = permission
            }
        )

    }

    ngOnInit() {
        this.loadPermission();
        this._route.paramMap.subscribe(parameterMap => {
            const id = +parameterMap.get('id');
        })
    }

    sortData(sort: Sort) {
        const data = this.permissions.slice();
        if (!sort.active || sort.direction === '') {
            this.permissions = data;
            return;
        }
        this.permissions = data.sort((a, b) => {
            const isAsc = sort.direction === 'asc';
            switch (sort.active) {
                case 'id': return compare(a.id, b.id, isAsc);
                case 'code': return compare(a.code, b.code, isAsc);
                case 'desc': return compare(a.desc, b.desc, isAsc);
                default: return 0;
            }
        })
    }



    loadPermission() {
        this._permissionManagementService.getReferenccePermissions().subscribe(
            permission => {
                this.permissions = permission
            }
        )
    }

    createNewRefPermission() {
        this.route.navigate(['createNewPermission']);
    }

    view(id: number) {
        this.route.navigate(['viewPermissionComponent', id]);
    }

    edit(id: number) {
        this.route.navigate(['editNewPermission', id]);
    }

    confirmDelete(id): void {
        const dialogRef = this.matDialog.open(DeletePermisionItem, {

        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._permissionManagementService.deletePermission(id).subscribe((resp) => {
                    this.loadPermission()
                });

            }
        })

    }

}

@Component({
    selector: 'app-delete-item',
    templateUrl: './delete-permission-management.html',

})
export class DeletePermisionItem {
    constructor(public dialogRef: MatDialogRef<DeletePermisionItem>) { }


    CloseDialog() {
        this.dialogRef.close(false)
    }
}

@Pipe({ name: 'sortBy' })
export class OrderByPipeId implements PipeTransform {

    transform(value: any[], order = '', column: string = ''): any[] {
        if (!value || order === '' || !order) { return value; } // no array
        if (!column || column === '') {
            if (order === 'asc') { return value.sort() }
            else { return value.sort().reverse(); }
        } // sort 1d array
        if (value.length <= 1) { return value; } // array with only one item
        return orderBy(value, [column], [order]);
    }
}

function compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}