import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';


@Injectable({ providedIn: 'root' })
export class PermissionManagementService {
    public permissionUrl: string = environment.PROCESS_API_URL + 'api/permission';

    public authUrl: string = environment.AUTH_URL + 'api/';

    constructor(private _http: HttpClient) { }

    getReferenccePermissions(): Observable<any[]> {
        return this._http.get<any[]>(this.authUrl + 'permission');
    }

    getReferenccePermissionById(id: number): Observable<any> {
        return this._http.get<any>(this.authUrl + 'permission/' + id);
    }

    createNewPermission(permission: any): Observable<any> {
        return this._http.post<any>(this.authUrl + 'permission', permission);
    }

    updatePermission(permission: any): Observable<void> {
        return this._http.put<any>(this.authUrl + 'permission', permission);
    }

    deletePermission(id: number): Observable<void> {
        return this._http.delete<any>(this.authUrl + 'permission/' + id);
    }
}

