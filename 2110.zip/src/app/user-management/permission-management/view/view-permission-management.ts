import { Component, OnInit, Inject } from '@angular/core';
import { PermissionManagementService } from '../permission-management.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'view-permission-management',
    templateUrl: './view-permission-management.html',
    styleUrls: ['../../role-managment/role-management.component.scss']
})
export class ViewPermissionComponent implements OnInit {
    permissions: any[];
    private _id: number;

    constructor(private _permissionManagementService: PermissionManagementService,
        private _route: ActivatedRoute,
        private route: Router
    ) { }

    ngOnInit() {
        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
        })
        if (this._id != 0) {
            this._permissionManagementService.getReferenccePermissionById(this._id).subscribe(
                permissionDetail => this.permissions = permissionDetail
            )
        }
    }


    formControl = new FormControl('', [
        Validators.required
    ]);

    back() {
        this.route.navigate(['./permission-management']);
    }
}