import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PermissionManagementService } from '../permission-management.service';
import { PermissionModel } from '../permission.model';

@Component({
    selector: 'edit-permission-management',
    templateUrl: './edit-permission-management.html',
    styleUrls: ['../../role-managment/role-management.component.scss']
})

export class EditPermissionComponent implements OnInit {
    permissions: PermissionModel[];
    private _id: number;

    constructor(private _permissionManagementService: PermissionManagementService,
        private _route: ActivatedRoute,
        private route: Router
    ) { }

    ngOnInit() {

        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
        })
        if (this._id != 0) {
            this._permissionManagementService.getReferenccePermissionById(this._id).subscribe(
                permissionDetail => this.permissions = permissionDetail
            )
        }
    }



    update() {
        this._permissionManagementService.updatePermission(this.permissions).subscribe(
            () => {
                console.log('updated');
                this.route.navigate(['./permission-management'])

            }
        )


    }

    cancel() {
        this.route.navigate(['./permission-management']);
    }
}
