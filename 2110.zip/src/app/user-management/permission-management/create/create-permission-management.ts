import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PermissionModel } from '../permission.model';
import { PermissionManagementService } from '../permission-management.service';


@Component({
    selector: 'create-permission-management',
    templateUrl: './create-permission-management.html',
    styleUrls: ['../../role-managment/role-management.component.scss']
})

export class CreatePermissionComponent implements OnInit {
    permissions: any = {};
    private _id: number;
    constructor(private _permissionManagementService: PermissionManagementService,
        private _route: ActivatedRoute,
        private route: Router
    ) { }

    ngOnInit() {
        this.permissions = {};
        // this.loadPermission();
        this._route.paramMap.subscribe(parameterMap => {
            this._id = +parameterMap.get('id');
        })
        if (this._id != 0) {
        this._permissionManagementService.getReferenccePermissionById(this._id).subscribe(
            permissionDetail => this.permissions = permissionDetail
        )
        }
    }

    // loadPermission() {
    //     this._permissionManagementService.getReferenccePermissions().subscribe(
    //         permission => {
    //             this.permissions = permission
    //         }
    //     )
    // }

    save() {
        console.log("new perm", this.permissions);
        this._permissionManagementService.createNewPermission(this.permissions).subscribe((data) => {
            console.log(data);
            this.route.navigate(['./permission-management']);
        },
            (error: any) => console.log(error)
        )

    }

    cancel() {
        this.route.navigate(['./permission-management']);
    }
}