export class PermissionModel {
    id?: number;
    code?: string;
    desc?: string;
}
