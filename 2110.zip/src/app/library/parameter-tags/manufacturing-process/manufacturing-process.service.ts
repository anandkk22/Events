import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ManufacturingProcessModel } from './manufacturing-process.model';


@Injectable({ providedIn: 'root' })
export class ManufacturingProcessService {
  public manufacturingProcessAPI: string = environment.CNC_API_URL + 'api/mfgconnect-manufacturing-process';

  constructor(private _http: HttpClient) { }

  getManufacturingProcessList(): Observable<ManufacturingProcessModel[]> {
    return this._http.get<ManufacturingProcessModel[]>(this.manufacturingProcessAPI);
  }

  getManufacturingProcessById(id: number): Observable<ManufacturingProcessModel> {
    return this._http.get<ManufacturingProcessModel>(`${this.manufacturingProcessAPI}/${id}`);
  }

  createManufacturingProcess(data: ManufacturingProcessModel): Observable<ManufacturingProcessModel> {
    return this._http.post<ManufacturingProcessModel>(`${this.manufacturingProcessAPI}`, data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateManufacturingProcess(data: ManufacturingProcessModel): Observable<void> {
    return this._http.put<void>(`${this.manufacturingProcessAPI}`, data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  deleteManufacturingProcess(id: number): Observable<void> {
    return this._http.delete<void>(`${this.manufacturingProcessAPI}/${id}`);
  }
}
