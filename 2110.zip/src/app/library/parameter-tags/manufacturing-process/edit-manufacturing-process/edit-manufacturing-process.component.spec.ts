import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditManufacturingProcessComponent } from './edit-manufacturing-process.component';

describe('EditManufacturingProcessComponent', () => {
  let component: EditManufacturingProcessComponent;
  let fixture: ComponentFixture<EditManufacturingProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditManufacturingProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditManufacturingProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
