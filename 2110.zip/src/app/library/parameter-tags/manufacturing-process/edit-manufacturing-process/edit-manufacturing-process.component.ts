import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ManufacturingProcessModel } from '../manufacturing-process.model';
import { ManufacturingProcessService } from '../manufacturing-process.service';

@Component({
  selector: 'app-edit-manufacturing-process',
  templateUrl: './edit-manufacturing-process.component.html',
  styleUrls: ['./edit-manufacturing-process.component.scss']
})
export class EditManufacturingProcessComponent implements OnInit {
  manufacturingProcessTypes: ManufacturingProcessModel[];
  manufacturingProcessType: ManufacturingProcessModel;
  constructor(private _mdr: MatDialogRef<EditManufacturingProcessComponent>,
    private manufacturingProcessService: ManufacturingProcessService,
    private matDialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }
  CloseDialog() {
    this._mdr.close(false)
  }
  ngOnInit() {
  }

  getManufacturingProcessList() {
    this.manufacturingProcessService.getManufacturingProcessList().subscribe(
      data => this.manufacturingProcessTypes = data
    )
  }

  formControl = new FormControl('', [
    Validators.required
  ]);

  update() {
    this.manufacturingProcessService.updateManufacturingProcess(this.data).subscribe(
      () => {
        console.log('updated')
      }
    )
    this._mdr.close(false);
  }

}
