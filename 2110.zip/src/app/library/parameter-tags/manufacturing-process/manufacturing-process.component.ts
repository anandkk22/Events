import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { DeleteItem } from '../equipment-measurement-data/delete/delete';
import { CreateManufacturingProcessComponent } from './create-manufacturing-process/create-manufacturing-process.component';
import { EditManufacturingProcessComponent } from './edit-manufacturing-process/edit-manufacturing-process.component';
import { ManufacturingProcessModel } from './manufacturing-process.model';
import { ManufacturingProcessService } from './manufacturing-process.service';
import { ViewManufacturingProcessComponent } from './view-manufacturing-process/view-manufacturing-process.component';

@Component({
  selector: 'app-manufacturing-process',
  templateUrl: './manufacturing-process.component.html',
  styleUrls: ['../../library.component.scss', './manufacturing-process.component.scss']
})
export class ManufacturingProcessComponent implements OnInit {

  manufacturingProcessList: ManufacturingProcessModel[];
  manufacturingProcess: ManufacturingProcessModel;


  constructor(private manufacturingProcessService: ManufacturingProcessService,
    private _router: Router,
    private matDialog: MatDialog,
    private _route: ActivatedRoute,) { }


  ngOnInit() {
    this.getManufacturingProcessList();
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
    })
  }

  back() {
    this._router.navigate(['/library'])
  }

  getManufacturingProcessList() {
    this.manufacturingProcessService.getManufacturingProcessList().subscribe(
      data => this.manufacturingProcessList = data
    )
  }

  createNewRefKPIFamily() {
    const matDialog = this.matDialog.open(CreateManufacturingProcessComponent, {
      width: '500px',
      height: '400px',
    });

    matDialog.afterClosed().subscribe(res => {
      this.getManufacturingProcessList();
    })
  }

  view(id: number, processType: string, displayName: string) {
    const dialogRef = this.matDialog.open(ViewManufacturingProcessComponent, {
      width: '500px',
      height: '410px',
      data: { id: id, processType: processType, displayName: displayName }
    });
  }

  edit(id: number, processType: string, displayName: string) {
    const dialogRef = this.matDialog.open(EditManufacturingProcessComponent, {
      width: '700px',
      height: '700px',
      data: { id: id, processType: processType, displayName: displayName }
    });
    dialogRef.afterClosed().subscribe(res => {
      this.getManufacturingProcessList();
    })
  }

  confirmDelete(id): void {
    const dialogRef = this.matDialog.open(DeleteItem, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.manufacturingProcessService.deleteManufacturingProcess(id).subscribe(
          () => console.log(`deleted with id =  ${id} deleted`)
        )
        this.getManufacturingProcessList();
      }
      this.getManufacturingProcessList();
    })
  }

}
