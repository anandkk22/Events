import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ManufacturingProcessModel } from '../manufacturing-process.model';
import { ManufacturingProcessService } from '../manufacturing-process.service';

@Component({
  selector: 'app-create-manufacturing-process',
  templateUrl: './create-manufacturing-process.component.html',
  styleUrls: ['./create-manufacturing-process.component.scss']
})
export class CreateManufacturingProcessComponent implements OnInit {
  manufacturingProcessTypes: ManufacturingProcessModel[];
  manufacturingProcessType: ManufacturingProcessModel;


  constructor(private _mdr: MatDialogRef<CreateManufacturingProcessComponent>,
    private manufacturingProcessService: ManufacturingProcessService,
    private matDialog: MatDialog) {
  }

  CloseDialog() {
    this._mdr.close(false)
  }

  ngOnInit() {

  }

  getReferencceKPIFamilyList() {
    this.manufacturingProcessService.getManufacturingProcessList().subscribe(
      data => this.manufacturingProcessTypes = data
    )
  }

  save(formData) {
    this.manufacturingProcessService.createManufacturingProcess(formData.value).subscribe(
      (data: ManufacturingProcessModel) => {
        console.log(data)
      },
      (error: any) => console.log(error)
    )
    this._mdr.close(false);
  }

}
