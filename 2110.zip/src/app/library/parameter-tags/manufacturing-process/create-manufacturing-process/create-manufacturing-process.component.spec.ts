import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateManufacturingProcessComponent } from './create-manufacturing-process.component';

describe('CreateManufacturingProcessComponent', () => {
  let component: CreateManufacturingProcessComponent;
  let fixture: ComponentFixture<CreateManufacturingProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateManufacturingProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateManufacturingProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
