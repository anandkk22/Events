import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewManufacturingProcessComponent } from './view-manufacturing-process.component';

describe('ViewManufacturingProcessComponent', () => {
  let component: ViewManufacturingProcessComponent;
  let fixture: ComponentFixture<ViewManufacturingProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewManufacturingProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewManufacturingProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
