import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ManufacturingProcessModel } from '../manufacturing-process.model';
import { ManufacturingProcessService } from '../manufacturing-process.service';

@Component({
  selector: 'app-view-manufacturing-process',
  templateUrl: './view-manufacturing-process.component.html',
  styleUrls: ['./view-manufacturing-process.component.scss']
})
export class ViewManufacturingProcessComponent implements OnInit {

  manufacturingProcessTypes: ManufacturingProcessModel[];
  manufacturingProcessType: ManufacturingProcessModel;
  constructor(private _mdr: MatDialogRef<ViewManufacturingProcessComponent>,
    private manufacturingProcessService: ManufacturingProcessService,
    private matDialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }

  ngOnInit() {
  }

  CloseDialog() {
    this._mdr.close(false)
  }

  getReferencceKPIFamilyList() {
    this.manufacturingProcessService.getManufacturingProcessList().subscribe(
      data => this.manufacturingProcessTypes = data
    )
  }

  formControl = new FormControl('', [
    Validators.required
  ]);

}
