export class ManufacturingProcessModel {
  id?: number
  processType?: string
  displayName?: string
}
