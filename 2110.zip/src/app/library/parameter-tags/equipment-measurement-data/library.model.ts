export class EquipmentMeasureModel {   
        id: number;
        equipType: number;
        equipTypeCode: number;
        measureParam: string;
        name: string;
        dataType: string;
        dataTypeId: number;
        baseUnit: string;
        nature: string;
        natureId: number
}

export class BaseUnitModel {
    code: number;
    name: string;
}

export class DataTypeModel {
    code: number;
    name: string;
}

export class EquipmentTypeModel {
    code: number;
    name: string;
}

export class NatureEnumModel {
    code: number;
    name: string;
}