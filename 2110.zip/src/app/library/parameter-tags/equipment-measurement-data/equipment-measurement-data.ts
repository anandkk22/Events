import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EquipmentMesurementDataService } from './equipment-measurement-data.service';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { CreateEquipmentMeasurementDataDetailComponent } from './create-equipment-measurement-data-detail.component';
import { EquipmentMeasureModel } from './library.model';
import { EditEquipmentMeasurementDataComponent } from './edit-equipment-measurement-data';
import { DeleteItem } from './delete/delete';
import { ViewEquipmentMeasurementDataComponent } from './view-equipment-measure-data.component';

@Component({
    selector: 'equipment-measurement',
    templateUrl: './equipment-measurement-data.html',
    styleUrls: ['../../library.component.scss', './equipment-measurement-data.scss']
})
export class EquipmentMeasurementDataComponent implements OnInit {
    equipmentMeasureData: EquipmentMeasureModel[];
    equipmentMeasData: EquipmentMeasureModel;
    searchText: string;
    currentSearch: string;
    searchArray = [];

    constructor(
        private _router: Router,
        private _equipmentMesurementDataService: EquipmentMesurementDataService,
        private matDialog: MatDialog, 
        ) { }

    ngOnInit() {
        this.getEquipmentMesData();
    }

    back() {
        this._router.navigate(['/library'])
    }

    getEquipmentMesData() {
        this._equipmentMesurementDataService.getEquipmentMesData().subscribe(
            data => this.equipmentMeasureData = data,
        )
    }

    view(id: number, equipTypeCode: number, measureParam: string, name: string, dataTypeId: number, baseUnitId: number, natureId: number) {
        const dialogRef = this.matDialog.open(ViewEquipmentMeasurementDataComponent, {
            width: '700px',
            height: '700px',
            data: { id: id, equipTypeCode: equipTypeCode, measureParam: measureParam, name: name, dataTypeId: dataTypeId, baseUnitId: baseUnitId, natureId: natureId }
        });
    }


    createNewEquipment() {
        const matDialog = this.matDialog.open(CreateEquipmentMeasurementDataDetailComponent, {
            width: '700px',
            height: '700px',
        });

        matDialog.afterClosed().subscribe(res => {
            this.refreshPage();
        })
    }

    editEquipment(id: number, equipTypeCode: number, measureParam: string, name: string, dataTypeId: number, baseUnitId: number, natureId: number) {
        const dialogRef = this.matDialog.open(EditEquipmentMeasurementDataComponent, {
            width: '700px',
            height: '700px',
            data: { id: id, equipTypeCode: equipTypeCode, measureParam: measureParam, name: name, dataTypeId: dataTypeId, baseUnitId: baseUnitId, natureId: natureId }
        });
        dialogRef.afterClosed().subscribe(res => {
            this.refreshPage();
        })
    }

    confirmDelete(id): void {
        const dialogRef = this.matDialog.open(DeleteItem, {
            width: '250px'
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result === 'delete') {
                this._equipmentMesurementDataService.deleteEquipmentMeasure(id).subscribe(
                    () => console.log(`Area deleted with id =  ${id} deleted`)                    
                )
                this.refreshPage();                
            }
            this.refreshPage();
        })
    }

    private refreshPage() {
        this.getEquipmentMesData()
    }
}