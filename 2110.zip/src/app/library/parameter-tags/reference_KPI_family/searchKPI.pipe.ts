import { Pipe, PipeTransform } from '@angular/core';
import { referenceFamilyModel } from './referenceFamily.Model';


@Pipe({ name: 'searchKpi' })
export class searchByKpiData implements PipeTransform {
  transform(items: referenceFamilyModel[], searchTerm: string): referenceFamilyModel[] {
 
    if (!items || !searchTerm) {
      return items
    }

    return items.filter(item =>
      item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1
    )
  }
}


@Pipe({ name: 'OrderKpi' })
export class OrderKpiData implements PipeTransform {
  transform(items: any[], field: string, reverse: boolean = false): any[] {
    if (!items) return [];
    if (field) items.sort((a, b) => a[field] > b[field] ? 1 : -1);
    else items.sort((a, b) => a > b ? -1 : 1);

    if (field === 'lastUpdated') {
      let values = items.sort((a: any, b: any) => {
        return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
      });
      return values.reverse();
    }
    return items;
  }
}
