import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { referenceFamilyModel, NatureModel, LevelModel, CategoryModel } from '../referenceFamily.Model';
import { ReferenceKPIFamilyService } from '../reference-kpi-family.service';



@Component({
    selector: 'create-reference-kpi-family.component',
    templateUrl: './create-reference-kpi-family.component.html'
})

export class CreateReferenceKpiFamilyComponent implements OnInit {
    refkpiTypes: referenceFamilyModel[];
    refkpiType: referenceFamilyModel;
    levels: LevelModel[];
    natures: NatureModel[];
    categories: CategoryModel[];
    isActive: boolean = false;
    
    constructor(private _mdr: MatDialogRef<CreateReferenceKpiFamilyComponent>,
        private _referenceKPIFamilyService: ReferenceKPIFamilyService, 
        private matDialog: MatDialog) {
    }

    CloseDialog() {
        this._mdr.close(false)
    }

    ngOnInit() {
       this.levels = [{code:1, name:'Plant'}];
       this.natures = [{code:1, name:'Predicted'}];
       this.categories = [{code:1, name:'Performance'}];       
    }

    getReferencceKPIFamilyList(){
        this._referenceKPIFamilyService.getReferencceKPIFamilyList().subscribe(
            data => this.refkpiTypes = data
        )
    }

    save(formData) {
        this._referenceKPIFamilyService.createNewRefKpiFamily(formData.value).subscribe(
            (data: referenceFamilyModel) => {
                console.log(data)
            },
            (error: any) => console.log(error)
        )
        this._mdr.close(false);    
    }
}