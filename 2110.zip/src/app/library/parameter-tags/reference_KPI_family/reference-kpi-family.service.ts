import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { referenceFamilyModel } from './referenceFamily.Model';


@Injectable({providedIn: 'root'})
export class ReferenceKPIFamilyService {
    public referenceKPIFamily: string = environment.PROCESS_API_URL + 'api/kpifamily';     

    constructor(private _http: HttpClient){}

    getReferencceKPIFamilyList(): Observable<referenceFamilyModel[]>{
        return this._http.get<referenceFamilyModel[]>(this.referenceKPIFamily);
    }

    getReferencceKPIFamilyById(id: number): Observable<referenceFamilyModel>{
        return this._http.get<referenceFamilyModel>(`${this.referenceKPIFamily}/${id}`);
    }

    createNewRefKpiFamily(data: referenceFamilyModel): Observable<referenceFamilyModel> {
        return this._http.post<referenceFamilyModel>(`${this.referenceKPIFamily}`, data, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }

    updateRefKpiFamily(data: referenceFamilyModel): Observable<void> {
        return this._http.put<void>(`${this.referenceKPIFamily}`, data, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
    }
    
    deleteRefKpiFamily(id: number): Observable<void> {
        return this._http.delete<void>(`${this.referenceKPIFamily}/${id}`);
    }    
}