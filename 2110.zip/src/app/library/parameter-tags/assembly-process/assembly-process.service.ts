import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AssemblyProcessModel } from './assembly-process.model';


@Injectable({ providedIn: 'root' })
export class AssemblyProcessService {
  public assemblyProcessAPI: string = environment.CNC_API_URL + 'api/mfgconnect-assembly-process';

  constructor(private _http: HttpClient) { }

  getAssemblyProcessList(): Observable<AssemblyProcessModel[]> {
    return this._http.get<AssemblyProcessModel[]>(this.assemblyProcessAPI);
  }

  getAssemblyProcessById(id: number): Observable<AssemblyProcessModel> {
    return this._http.get<AssemblyProcessModel>(`${this.assemblyProcessAPI}/${id}`);
  }

  createAssemblyProcess(data: AssemblyProcessModel): Observable<AssemblyProcessModel> {
    return this._http.post<AssemblyProcessModel>(`${this.assemblyProcessAPI}`, data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  updateAssemblyProcess(data: AssemblyProcessModel): Observable<void> {
    return this._http.put<void>(`${this.assemblyProcessAPI}`, data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
  }

  deleteAssemblyProcess(id: number): Observable<void> {
    return this._http.delete<void>(`${this.assemblyProcessAPI}/${id}`);
  }
}
