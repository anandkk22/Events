import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AssemblyProcessModel } from '../assembly-process.model';
import { AssemblyProcessService } from '../assembly-process.service';

@Component({
  selector: 'app-edit-assembly-process',
  templateUrl: './edit-assembly-process.component.html',
  styleUrls: ['./edit-assembly-process.component.scss']
})
export class EditAssemblyProcessComponent implements OnInit {
  assemblyProcessTypes: AssemblyProcessModel[];
  assemblyProcessType: AssemblyProcessModel;
  constructor(private _mdr: MatDialogRef<EditAssemblyProcessComponent>,
    private assemblyProcessService: AssemblyProcessService,
    private matDialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }
  CloseDialog() {
    this._mdr.close(false)
  }
  ngOnInit() {
  }

  getManufacturingProcessList() {
    this.assemblyProcessService.getAssemblyProcessList().subscribe(
      data => this.assemblyProcessTypes = data
    )
  }

  formControl = new FormControl('', [
    Validators.required
  ]);

  update() {
    this.assemblyProcessService.updateAssemblyProcess(this.data).subscribe(
      () => {
        console.log('updated')
      }
    )
    this._mdr.close(false);
  }
}
