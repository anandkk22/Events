import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAssemblyProcessComponent } from './view-assembly-process.component';

describe('ViewAssemblyProcessComponent', () => {
  let component: ViewAssemblyProcessComponent;
  let fixture: ComponentFixture<ViewAssemblyProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAssemblyProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAssemblyProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
