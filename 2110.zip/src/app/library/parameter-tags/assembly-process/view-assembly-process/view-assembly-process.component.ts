import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AssemblyProcessModel } from '../assembly-process.model';
import { AssemblyProcessService } from '../assembly-process.service';

@Component({
  selector: 'app-view-assembly-process',
  templateUrl: './view-assembly-process.component.html',
  styleUrls: ['./view-assembly-process.component.scss']
})
export class ViewAssemblyProcessComponent implements OnInit {

  assemblyProcessTypes: AssemblyProcessModel[];
  assemblyProcessType: AssemblyProcessModel;
  constructor(private _mdr: MatDialogRef<ViewAssemblyProcessComponent>,
    private assemblyProcessService: AssemblyProcessService,
    private matDialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }

  ngOnInit() {
  }

  CloseDialog() {
    this._mdr.close(false)
  }

  getReferencceKPIFamilyList() {
    this.assemblyProcessService.getAssemblyProcessList().subscribe(
      data => this.assemblyProcessTypes = data
    )
  }

  formControl = new FormControl('', [
    Validators.required
  ]);


}
