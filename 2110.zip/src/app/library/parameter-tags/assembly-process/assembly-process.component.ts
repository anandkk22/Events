import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { DeleteItem } from '../equipment-measurement-data/delete/delete';
import { AssemblyProcessModel } from './assembly-process.model';
import { AssemblyProcessService } from './assembly-process.service';
import { CreateAssemblyProcessComponent } from './create-assembly-process/create-assembly-process.component';
import { EditAssemblyProcessComponent } from './edit-assembly-process/edit-assembly-process.component';
import { ViewAssemblyProcessComponent } from './view-assembly-process/view-assembly-process.component';

@Component({
  selector: 'app-assembly-process',
  templateUrl: './assembly-process.component.html',
  styleUrls: ['../../library.component.scss', './assembly-process.component.scss']
})
export class AssemblyProcessComponent implements OnInit {

  assemblyProcessList: AssemblyProcessModel[];
  assemblyProcess: AssemblyProcessModel;


  constructor(private assemblyProcessService: AssemblyProcessService,
    private _router: Router,
    private matDialog: MatDialog,
    private _route: ActivatedRoute,) { }


  ngOnInit() {
    this.getAssemblyProcessList();
    this._route.paramMap.subscribe(parameterMap => {
      const id = +parameterMap.get('id');
    })
  }

  back() {
    this._router.navigate(['/library'])
  }

  getAssemblyProcessList() {
    this.assemblyProcessService.getAssemblyProcessList().subscribe(
      data => this.assemblyProcessList = data
    )
  }

  createAssemblyProcess() {
    const matDialog = this.matDialog.open(CreateAssemblyProcessComponent, {
      width: '500px',
      height: '400px',
    });

    matDialog.afterClosed().subscribe(res => {
      this.getAssemblyProcessList();
    })
  }

  view(id: number, processType: string, displayName: string) {
    const dialogRef = this.matDialog.open(ViewAssemblyProcessComponent, {
      width: '500px',
      height: '410px',
      data: { id: id, processType: processType, displayName: displayName }
    });
  }

  edit(id: number, processType: string, displayName: string) {
    const dialogRef = this.matDialog.open(EditAssemblyProcessComponent, {
      width: '700px',
      height: '700px',
      data: { id: id, processType: processType, displayName: displayName }
    });
    dialogRef.afterClosed().subscribe(res => {
      this.getAssemblyProcessList();
    })
  }

  confirmDelete(id): void {
    const dialogRef = this.matDialog.open(DeleteItem, {
      width: '250px'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'delete') {
        this.assemblyProcessService.deleteAssemblyProcess(id).subscribe(
          () => console.log(`deleted with id =  ${id} deleted`)
        )
        this.getAssemblyProcessList();
      }
      this.getAssemblyProcessList();
    })
  }

}
