import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { AssemblyProcessModel } from '../assembly-process.model';
import { AssemblyProcessService } from '../assembly-process.service';

@Component({
  selector: 'app-create-assembly-process',
  templateUrl: './create-assembly-process.component.html',
  styleUrls: ['./create-assembly-process.component.scss']
})
export class CreateAssemblyProcessComponent implements OnInit {

  assemblyProcessList: AssemblyProcessModel[];
  assemblyProcess: AssemblyProcessModel;


  constructor(private _mdr: MatDialogRef<CreateAssemblyProcessComponent>,
    private assemblyProcessService: AssemblyProcessService,
    private matDialog: MatDialog) {
  }

  CloseDialog() {
    this._mdr.close(false)
  }

  ngOnInit() {

  }

  getReferencceKPIFamilyList() {
    this.assemblyProcessService.getAssemblyProcessList().subscribe(
      data => this.assemblyProcessList = data
    )
  }

  save(formData) {
    this.assemblyProcessService.createAssemblyProcess(formData.value).subscribe(
      (data: AssemblyProcessModel) => {
        console.log(data)
      },
      (error: any) => console.log(error)
    )
    this._mdr.close(false);
  }
}
