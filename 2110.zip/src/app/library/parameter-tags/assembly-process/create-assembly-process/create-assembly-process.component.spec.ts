import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAssemblyProcessComponent } from './create-assembly-process.component';

describe('CreateAssemblyProcessComponent', () => {
  let component: CreateAssemblyProcessComponent;
  let fixture: ComponentFixture<CreateAssemblyProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateAssemblyProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAssemblyProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
