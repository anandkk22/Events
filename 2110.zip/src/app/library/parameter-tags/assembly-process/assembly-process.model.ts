export class AssemblyProcessModel {
  id?: number
  processType?: string
  displayName?: string
}
