import { Component, OnInit } from '@angular/core';
import { CategoriesService } from './categories.service';
import { Router } from '@angular/router';
import {searchCatetories} from './searchbyCategories.pipe'

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {
  menuDashBoard: any;
  searchText= '';
  welcome = '';

  constructor(private _categoriesService: CategoriesService, private _router: Router) { }

  ngOnInit() {
    this._categoriesService.getcategories().subscribe(
      (menu) => {
        console.error(menu);
        this.menuDashBoard = menu;      
      }
    )
	//  this._categoriesService.welcome().subscribe(
  //     (message) => {
  //       this.welcome = message.message;      
  //     }
  //   )
	
  }

  menuClick(link){
    this._router.navigate([link])
  }

}
