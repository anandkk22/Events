import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { NbThemeModule, NbLayoutModule, NbCardModule } from '@nebular/theme';

import { NgCircleProgressModule } from 'ng-circle-progress';
import { ProductionLiveDashboardComponent } from './production-live-dashboard.component';
import { NbThemeModule, NbLayoutModule } from '@nebular/theme';



@NgModule({
  declarations: [
    ProductionLiveDashboardComponent
  ],
  imports: [
    CommonModule,
    NbLayoutModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NbThemeModule.forRoot({ name: 'default' }),
    NgCircleProgressModule.forRoot({
      // set defaults here
      "radius": 60,
      "space": -10,
      "outerStrokeLinecap": "square",
      "outerStrokeGradient": true,
      "innerStrokeWidth": 10,
      "title": 'auto',
      "titleFontSize": '35',
      "titleFontWeight": 'bold',
      "titleColor": '#000000',
      "units": '%',
      "unitsFontSize": '30',
      "unitsFontWeight": 'normal',
      "unitsColor": '#000000',
      "subtitle": 'OEE',
      "subtitleColor": '#000000',
      "subtitleFontSize": '20',
      "subtitleFontWeight": 'bold',
      "showBackground": true,
      "clockwise": true,
      "startFromZero": false,
      "responsive": true


    })
  ],
  exports: [ProductionLiveDashboardComponent]
})
export class MachineModule { }
