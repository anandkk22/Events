import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductionLiveDashboardComponent } from './production-live-dashboard.component';

describe('ProductionLiveDashboardComponent', () => {
  let component: ProductionLiveDashboardComponent;
  let fixture: ComponentFixture<ProductionLiveDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductionLiveDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductionLiveDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
