import { Injectable } from '@angular/core';
import { flatMap } from 'rxjs/operators';
import { AccountService } from '../authentication/account.service';
import { AuthenticationService } from '../authentication/authentication.service';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class LoginService {
  public url: string = environment.PROCESS_API_URL + 'api/';
  public discretapp: string = environment.CNC_API_URL + 'api/';

  public authApi: string = environment.AUTH_URL + 'api/';

  constructor(private accountService: AccountService, private authServerProvider: AuthenticationService, private http: HttpClient) { }

  login(credentials) {
    return this.authServerProvider.login(credentials).pipe(flatMap(() => this.accountService.identity(true)));
  }

  logout() {
    this.authServerProvider.logout().subscribe(null, null, () => this.accountService.authenticate(null));
  }

  getUserProfileByUserId(id): Observable<any[]> {
    return this.http.get<any[]>(this.discretapp + 'userProfileByUserId/' + id);
  }

  changePassword(passwords): Observable<HttpResponse<any>> {
    return this.http.post<any>(this.authApi + 'account/change-password', passwords, { observe: 'response' });
  }
}
