import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BatchAnalysisServiceService {

  public url: string = "./assets/json/";
  constructor(private http: HttpClient) { }

  public apiUrl = environment.PROCESS_API_URL + 'api/';
  public cnc = environment.CNC_API_URL + 'api';
  public pcaDataUrl = "http://3.7.187.176:5000/";

  getCompareData() {
    return this.http.get(this.url + "batch-analysis.json");
  }

  getLoading() {
    return this.http.get(this.url + "root-cause.json");
  }

  getBatchData(): Observable<any> {
    return this.http.get(this.apiUrl + "findBatchRatingData");
  }

  findBatchMeasurementData(id): Observable<any> {
    return this.http.get<any>(this.apiUrl + "findBatchMeasurementData/" + id);
  }

  getPlantData() {
    return this.http.get(this.apiUrl + "plant/4");
  }

  getGoldenBatches(): Observable<any> {
    return this.http.get<any>(this.apiUrl + "getGoldenBatches");
  }

  getBredCrumbData() {
    return this.http.get(this.apiUrl + "org/plant/area/processCell/processUnit/1");
  }

  getBatchDataFromAndTo(from, to): Observable<any> {
    return this.http.get<any>(this.apiUrl + "getBatchesFromAndTo/" + from + "/" + to);
  }

  getGoldenBatchDataFromAndTo(from, to): Observable<any> {
    return this.http.get<any>(this.apiUrl + "getGoldenBatchesFromAndTo/" + from + "/" + to);
  }

  getRootCauseAnalysisData(data): Observable<any> {
    return this.http.post<any>(this.apiUrl + "rootCauseAnalysis", data);
  }

  getPCAData(data): Observable<any> {
    return this.http.post<any>(this.pcaDataUrl, data);
  }
}
