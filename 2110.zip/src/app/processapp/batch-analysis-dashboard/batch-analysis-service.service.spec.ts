import { TestBed } from '@angular/core/testing';

import { BatchAnalysisServiceService } from './batch-analysis-service.service';

describe('BatchAnalysisServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BatchAnalysisServiceService = TestBed.get(BatchAnalysisServiceService);
    expect(service).toBeTruthy();
  });
});
