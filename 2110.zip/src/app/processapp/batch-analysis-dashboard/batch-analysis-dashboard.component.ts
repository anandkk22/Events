import { Component, OnInit, ViewChild } from '@angular/core';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import * as am4maps from '@amcharts/amcharts4/maps';
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { matMenuAnimations, MatOption, MatDatepickerInputEvent } from '@angular/material';
import { CodeNode } from 'source-list-map';
import { BatchAnalysisServiceService } from './batch-analysis-service.service';
import { NgModel } from '@angular/forms';
import * as moment from 'moment';
import { isEmpty } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';

am4core.useTheme(am4themes_animated);

@Component({
  selector: 'app-batch-analysis-dashboard',
  templateUrl: './batch-analysis-dashboard.component.html',
  styleUrls: ['./batch-analysis-dashboard.component.scss']
})
export class BatchAnalysisDashboardComponent implements OnInit {

  constructor(private service: BatchAnalysisServiceService,
    private spinner: NgxSpinnerService,
  ) { }

  @ViewChild('allSelected', { static: true }) private allSelected: MatOption;

  public kpiName: any = ['Product Performance Rating'];
  public rules: any = ['Std. Deviation', 'Min/Max'];
  public components: any = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  public pcaData: any = ['PC1', 'PC2'];

  public userFilter: any = { displayName: '' };
  public timeSpan: any = ['Live', 'Yesterday', 'This Month']
  public batches: any = [];
  public goldenBatches: any = [];
  public parameters: any = [];
  public scoreData: any = [];
  public algorithms: any = ['PCA'];
  public selected: any = [];
  public batchData: any = [{
    productId: '',
    productName: '',
    batchType: '',
    batchName: '',
    recipeName: '',
    measurementParameter: [],
    startTime: '',
    endTime: '',
    erpBatchCode: '',
    isGoldenBatch: '',
    productPerformanceRating: ''
  }]
  public plant: any = {
    name: ''
  };
  public compareData: any = [];
  public batchD: any;
  public batchC: any = {

  }
  public batchG: any = {

  };
  public rootCauseData: any = [];


  public orgBredCrumb: any = {
    processUnit: '',
    processCellName: '',
    areaName: '',
    plantName: '',
    orgName: ''
  }
  public compareBatchData: any = [];
  public causeAnalysisBatchData: any = [];
  public gbatches: any = [];

  public rootCauseAnalysisData: any = {
    startDateTime: '',
    endDateTime: '',
    batches: '',
    parameters: '',
    components: '',
    algorithm: ''
  };

  public isPca: boolean = false;
  public toDate = new Date();
  public fromDate = new Date(this.toDate.getTime() - (90 * 24 * 60 * 60 * 1000));

  public compareBatchFrom: any;
  public compareBatchTo: any;

  public goldenBatchFrom: any;
  public goldenBatchTo: any;

  public causeAnalysisFrom: any;
  public causeAnalysisTo: any;

  ngOnInit() {
    this.initialComparisionChartLoading();
    let to = moment(this.toDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";
    let from = moment(this.fromDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z";

    this.service.getBatchDataFromAndTo(from, to).subscribe((resp) => {
      this.batchData = resp;
      console.log("batt data....", to, from, this.batchData);
      let namArr = [];

      for (let i = 0; i < this.batchData.length; i++) {
        namArr.push(this.batchData[i].batchName);
      }
      this.batchChartFuc(namArr);
      this.loadBatchChart();
    });

    this.allSelected.select();
    // this.scrollPositionPortfolio();
    this.loadAll();

    this.service.getBredCrumbData().subscribe((resp) => {
      this.orgBredCrumb = resp;
      console.log("bred crumb", this.orgBredCrumb);
    });

    this.service.findBatchMeasurementData(1).subscribe((resp) => {
      this.batchC = resp;
      console.log("cccccc", this.batchC.measurementParameter[0]);
      this.parameters = Object.keys(this.batchC.measurementParameter[0]);
      console.log("parameters", this.parameters);
      this.batchC = [];
    });
  }

  initialComparisionChartLoading() {
    this.spinner.show();
    setTimeout(() => {
      this.service.findBatchMeasurementData(100).subscribe((resp) => {
        this.batchC = resp;
        if (this.batchC != null) {
          this.service.findBatchMeasurementData(90).subscribe((resp) => {
            this.batchG = resp;
            console.log("dattttaa", this.batchC, this.batchG);
            if (this.batchC.measurementParameter != null && this.batchG.measurementParameter != null) {
              this.comparisonChart('chartdiv1', this.batchC.measurementParameter, this.batchG.measurementParameter, 'Q', 'T', 'batch100', 'batch90');
            }
            this.spinner.hide();
          });
        }
      });

    }, 3000);


  }

  loadBatchDataFromandTo(from, to) {
    this.service.getBatchDataFromAndTo(from, to).subscribe((resp) => {
      this.batchData = resp;
      console.log("batt data....", to, from, this.batchData);
      let namArr = [];

      for (let i = 0; i < this.batchData.length; i++) {
        namArr.push(this.batchData[i].batchName);
      }
      this.batchChartFuc(namArr);
    });
  }
  selectBatch(event) {
    this.selected = [];
    this.batchD = [];
    let namArr = [];
    console.log("select batch", event.value);
    for (let i = 0; i < event.value.length; i++) {
      namArr.push(event.value[i].batchName);
    }
    this.batchChartFuc(namArr);
  }
  batchChartFuc(val) {
    for (let i = 0; i < val.length; i++) {
      let name: [] = val[i];
      this.batchD = this.batchData.filter(b => name == b.batchName);
      console.log("updated data", this.batchD);
      this.selected.push({ "productPerformanceRating": this.batchD[0].productPerformanceRating, "batchName": this.batchD[0].batchName });
    }
    console.log("sssssssss", this.selected);
  }

  loadBatchChart() {
    this.BatchAnalysis('chartdiv', this.selected, 'productPerformanceRating', 'batchName');
  }


  loadAll() {
    this.service.getCompareData().subscribe((resp) => {
      this.compareData = resp;
      if (this.compareData != null) {
        console.log("compare", this.compareData);
        // this.comparisonChart('chartdiv1', this.compareData, 'P');
      }
    });
  }

  minus_plus_icon_toggle_h1() {
    const element = document.getElementById('minus-image-h1');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h1');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h2() {
    const element = document.getElementById('minus-image-h2');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h2');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h4() {
    console.log('jhdjsfgdjg');
    const element = document.getElementById('minus-image-h4');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h4');
    element2.classList.toggle('d-none');
  }

  scrollPositionPortfolio() {
    const elmnt = document.getElementById('scroll-position-window-top');
    elmnt.scrollIntoView();
    /* window.scrollTo(0, 0); */
  }

  BatchAnalysis(chartName, data, yValue, xValue) {
    let chart = am4core.create(chartName, am4charts.XYChart);
    // chart.scrollbarX = new am4core.Scrollbar();
    chart.logo.disabled = true;

    // Add data
    chart.data = data;
    console.log("chart data", chart.data);
    // Create axes

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = xValue;

    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 30;


    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

    var gradient = new am4core.LinearGradient();
    gradient.stops.push({ color: am4core.color("#33ccff") })
    gradient.stops.push({ color: am4core.color("#4da6ff") })
    gradient.stops.push({ color: am4core.color("#0073e6") })
    gradient.rotation = 270;
    // Create series
    let series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = yValue;
    series.dataFields.categoryX = xValue;
    series.name = "Rating";
    series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
    series.columns.template.fillOpacity = 1;

    valueAxis.title.fill = am4core.color('#10c3d7');

    let columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 0;
    columnTemplate.strokeOpacity = 1;
    columnTemplate.width = am4core.percent(70);
    // columnTemplate.fill = am4core.color("#6699ff");
    columnTemplate.fill = gradient;
    // categoryAxis.renderer.labels.template.rotation = 270;

    categoryAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");
    valueAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");

    valueAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    categoryAxis.renderer.labels.template.fill = am4core.color('#10c3d7');

    if (chartName == "chartdiv2") {
      categoryAxis.renderer.labels.template.rotation = 280;
      categoryAxis.renderer.fontSize = 9;
    }

    if (chartName == 'chartdiv') {
      valueAxis.title.text = "Product Performance Rating %";
      valueAxis.min = 0;
      valueAxis.max = 100;

      let axisRange = valueAxis.axisRanges.create();
      axisRange.value = 55;
      axisRange.grid.strokeOpacity = 1;
      axisRange.label.text = "Lower Std Deviation";
      axisRange.label.align = "right";
      axisRange.label.fillOpacity = 1;
      axisRange.grid.stroke = am4core.color("#86592d");
      axisRange.grid.above = true;
      axisRange.label.x = 100;
      axisRange.label.fontSize = 9;

      let axisRange1 = valueAxis.axisRanges.create();
      axisRange1.value = 65;
      axisRange1.grid.strokeOpacity = 1;
      axisRange1.label.text = "Mean";
      axisRange1.label.align = "right";
      axisRange1.label.fillOpacity = 1;
      axisRange1.grid.stroke = am4core.color("#66ff66");
      axisRange1.grid.above = true;
      axisRange1.label.fontSize = 9;

      let axisRange2 = valueAxis.axisRanges.create();
      axisRange2.value = 75;
      axisRange2.grid.strokeOpacity = 1;
      axisRange2.label.text = "Upper Std Deviation";
      axisRange2.label.align = "right";
      axisRange2.label.fillOpacity = 1;
      axisRange2.grid.stroke = am4core.color("#ff9900");
      axisRange2.grid.above = true;
      axisRange2.label.fontSize = 9;

    }
    else {
      valueAxis.title.text = yValue;
    }
  }

  comparisonChart(chartName, datab, datag, parameter, parameter2, nBatch, gBatch) {
    let chart = am4core.create(chartName, am4charts.XYChart);
    chart.logo.disabled = true;

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    // valueAxis.tooltip.disabled = true;
    valueAxis.renderer.labels.template.fill = am4core.color("#e59165");

    let valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
    // valueAxis2.tooltip.disabled = true;
    valueAxis2.renderer.labels.template.fill = am4core.color("#dfcc64");
    valueAxis2.syncWithAxis = valueAxis;

    var xAxis = chart.xAxes.push(new am4charts.ValueAxis());
    valueAxis.renderer.labels.template.paddingRight = -100;

    let series = chart.series.push(new am4charts.LineSeries());
    series.data = datab;
    series.name = nBatch;
    series.dataFields.valueX = "h";
    series.dataFields.valueY = parameter;
    series.tooltipText = "{valueY.value}";
    series.fill = am4core.color("#e59165");
    series.stroke = am4core.color("#e59165");
    series.yAxis = valueAxis;
    valueAxis.renderer.grid.template.location = 0;
    valueAxis2.renderer.grid.template.location = 0;

    let series2 = chart.series.push(new am4charts.LineSeries());
    series2.data = datag;
    series2.name = gBatch;
    series2.dataFields.valueX = "h";
    series2.dataFields.valueY = parameter;
    series2.tooltipText = "{valueY.value}";
    series2.fill = am4core.color("#dfcc64");
    series2.stroke = am4core.color("#dfcc64");
    series2.yAxis = valueAxis;

    chart.cursor = new am4charts.XYCursor();
    // chart.cursor.xAxis = xAxis;
    // chart.cursor.yAxis= valueAxis;

    // var scrollbarX = new am4charts.XYChartScrollbar();
    // scrollbarX.series.push(series);

    chart.legend = new am4charts.Legend();
    chart.legend.parent = chart.plotContainer;
    chart.legend.zIndex = 100;
    chart.legend.labels.template.fill = am4core.color("#10c3d7");

    valueAxis.renderer.grid.template.strokeOpacity = 0.2;
    xAxis.renderer.grid.template.strokeOpacity = 0.2;
    valueAxis2.renderer.grid.template.strokeOpacity = 0.2;

    valueAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");
    valueAxis2.renderer.grid.template.stroke = am4core.color("#10c3d7");

    valueAxis.title.text = parameter;
    valueAxis.title.fill = am4core.color('#10c3d7');
    xAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");

    valueAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    valueAxis2.renderer.labels.template.fill = am4core.color('#10c3d7');

    xAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    // valueAxis.renderer.inside = true;
    valueAxis.renderer.grid.template.location = 0;

    ///////////
    if (parameter2 != null) {

      let valueAxis3 = chart.yAxes.push(new am4charts.ValueAxis());
      // valueAxis.tooltip.disabled = true;
      valueAxis3.renderer.opposite = true;

      let valueAxis4 = chart.yAxes.push(new am4charts.ValueAxis());
      // valueAxis2.tooltip.disabled = true;
      valueAxis4.renderer.labels.template.fill = am4core.color("#dfcc64");
      valueAxis4.syncWithAxis = valueAxis3;

      var xAxis = chart.xAxes.push(new am4charts.ValueAxis());

      let series3 = chart.series.push(new am4charts.LineSeries());
      series3.data = datab;
      series3.name = nBatch;
      series3.dataFields.valueX = "h";
      series3.dataFields.valueY = parameter2;
      series3.tooltipText = "{valueY.value}";
      series3.fill = am4core.color("#00ff00");
      series3.stroke = am4core.color("#00ff00");
      series3.yAxis = valueAxis3;

      let series4 = chart.series.push(new am4charts.LineSeries());
      series4.data = datag;
      series4.name = gBatch;
      series4.dataFields.valueX = "h";
      series4.dataFields.valueY = parameter2;
      series4.tooltipText = "{valueY.value}";
      series4.fill = am4core.color("#0066ff");
      series4.stroke = am4core.color("#0066ff");
      series4.yAxis = valueAxis3;

      valueAxis3.title.text = parameter2;
      valueAxis3.title.fill = am4core.color('#10c3d7');

      valueAxis3.renderer.labels.template.fill = am4core.color('#10c3d7');
      valueAxis4.renderer.labels.template.fill = am4core.color('#10c3d7');

      valueAxis3.renderer.grid.template.stroke = am4core.color("#10c3d7");
      valueAxis4.renderer.grid.template.stroke = am4core.color("#10c3d7");
    }
  }

  pareto(data) {
    let chart = am4core.create("chartdiv3", am4charts.XYChart);
    chart.logo.disabled = true;
    // chart.scrollbarX = new am4core.Scrollbar();

    // Add data
    chart.data = data;

    prepareParetoData();

    function prepareParetoData() {
      let total = 0;

      for (var i = 0; i < chart.data.length; i++) {
        let value = chart.data[i].value;
        total += value;
      }

      let sum = 0;

      for (var i = 0; i < chart.data.length; i++) {
        let value = chart.data[i].value;
        sum += value;
        chart.data[i].pareto = sum / total * 100;
      }
    }

    // Create axes
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "ratio";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 60;
    categoryAxis.tooltip.disabled = true;

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.renderer.minWidth = 50;
    valueAxis.min = 0;
    valueAxis.cursorTooltipEnabled = false;

    // Create series
    let series = chart.series.push(new am4charts.ColumnSeries());
    series.sequencedInterpolation = true;
    series.dataFields.valueY = "value";
    series.dataFields.categoryX = "ratio";
    series.tooltipText = "[{categoryX}: bold]{valueY}[/]";
    series.columns.template.strokeWidth = 0;

    series.tooltip.pointerOrientation = "vertical";

    // series.columns.template.column.cornerRadiusTopLeft = 10;
    // series.columns.template.column.cornerRadiusTopRight = 10;
    series.columns.template.column.fillOpacity = 0.8;

    var gradient = new am4core.LinearGradient();
    gradient.stops.push({ color: am4core.color("#33ccff") })
    gradient.stops.push({ color: am4core.color("#4da6ff") })
    gradient.stops.push({ color: am4core.color("#0073e6") })
    gradient.rotation = 270;

    series.columns.template.fill = gradient;

    // on hover, make corner radiuses bigger
    // let hoverState = series.columns.template.column.states.create("hover");
    // hoverState.properties.cornerRadiusTopLeft = 0;
    // hoverState.properties.cornerRadiusTopRight = 0;
    // hoverState.properties.fillOpacity = 1;

    // series.columns.template.adapter.add("fill", function (fill, target) {
    //   return chart.colors.getIndex(target.dataItem.index);
    // })


    let paretoValueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    paretoValueAxis.renderer.opposite = true;
    paretoValueAxis.min = 0;
    paretoValueAxis.max = 100;
    paretoValueAxis.strictMinMax = true;
    paretoValueAxis.renderer.grid.template.disabled = true;
    paretoValueAxis.numberFormatter = new am4core.NumberFormatter();
    paretoValueAxis.numberFormatter.numberFormat = "#'%'"
    paretoValueAxis.cursorTooltipEnabled = false;

    let paretoSeries = chart.series.push(new am4charts.LineSeries())
    paretoSeries.dataFields.valueY = "pareto";
    paretoSeries.dataFields.categoryX = "ratio";
    paretoSeries.yAxis = paretoValueAxis;
    paretoSeries.tooltipText = "pareto: {valueY.formatNumber('#.0')}%[/]";
    paretoSeries.bullets.push(new am4charts.CircleBullet());
    paretoSeries.strokeWidth = 2;
    paretoSeries.stroke = new am4core.InterfaceColorSet().getFor("alternativeBackground");
    paretoSeries.strokeOpacity = 0.5;

    // Cursor
    chart.cursor = new am4charts.XYCursor();
    chart.cursor.behavior = "panX";

    categoryAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");
    valueAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");

    valueAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    categoryAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    paretoValueAxis.renderer.labels.template.fill = am4core.color('#10c3d7');

  }
  pcSelect(event) {
    console.log(event.value);
    this.BatchAnalysis('chartdiv2', this.rootCauseData.pcadata.Loading, event.value, 'parameter');
  }

  scoreCharts(data) {
    am4core.useTheme(am4themes_animated);
    // Themes end

    // Create chart instance
    var chart = am4core.create("chartdiv5", am4charts.XYChart);
    chart.colors.step = 3;
    chart.logo.disabled = true;
    // Add data
    chart.data = data;

    // Create axes
    var xAxis = chart.xAxes.push(new am4charts.ValueAxis());
    xAxis.renderer.minGridDistance = 50;

    var yAxis = chart.yAxes.push(new am4charts.ValueAxis());
    yAxis.renderer.minGridDistance = 50;

    // Create series #1
    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.valueY = "y";
    series.dataFields.valueX = "x";
    series.dataFields.value = "value";
    series.strokeOpacity = 0;
    series.name = "Scores";

    xAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");
    yAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");

    xAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    yAxis.renderer.labels.template.fill = am4core.color('#10c3d7');

    xAxis.title.text = "PC1";
    yAxis.title.text = "PC2";
    xAxis.title.fill = am4core.color('#10c3d7');
    yAxis.title.fill = am4core.color('#10c3d7');

    var bullet = series.bullets.push(new am4charts.CircleBullet());
    bullet.strokeOpacity = 0.2;
    bullet.stroke = am4core.color("#ffffff");
    bullet.nonScalingStroke = true;
    bullet.tooltipText = "x:{valueX} y:{valueY}";
    series.heatRules.push({
      target: bullet.circle,
      min: 10,
      max: 60,
      property: "radius"
    });

    // chart.scrollbarX = new am4core.Scrollbar();
    // chart.scrollbarY = new am4core.Scrollbar();

    // chart.legend = new am4charts.Legend();
  }

  public bat: any;
  toggleAllSelection() {
    if (this.allSelected.selected) {
      // this.bat = this.batchData;
      let namArr = [];
      for (let i = 0; i < this.batchData.length; i++) {
        namArr.push(this.batchData[i].batchName);
      }
      this.batchChartFuc(namArr);

    } else {
      this.bat = [];
    }
  }

  public normalBatch;
  public goldenBatch;

  selectCompareBatch(event) {
    this.normalBatch = event.value.batchName;
    this.service.findBatchMeasurementData(event.value.id).subscribe((resp) => {
      this.batchC = resp;
      console.log("cccccc", this.batchC.measurementParameter[0]);
      this.parameters = Object.keys(this.batchC.measurementParameter[0]);
      console.log("parameters", this.parameters);
    });
  }

  selectGoldenBatch(event) {
    this.goldenBatch = event.value.batchName;
    this.service.findBatchMeasurementData(event.value.id).subscribe((resp) => {
      this.batchG = resp;
      console.log("ggolden", this.batchG, event.value.id);
    });
  }
  public prrm: any;
  selectParameter(event) {
    this.prrm = event.value;
    console.log("prrrm", this.prrm);
  }

  loadComChart() {
    this.spinner.show();
    setTimeout(() => {
      if (this.batchC.measurementParameter != null && this.batchG.measurementParameter != null) {
        if (this.prrm[1] != null) {
          this.comparisonChart('chartdiv1', this.batchC.measurementParameter, this.batchG.measurementParameter, this.prrm[0], this.prrm[1], this.normalBatch, this.goldenBatch);
        }
        else {
          this.comparisonChart('chartdiv1', this.batchC.measurementParameter, this.batchG.measurementParameter, this.prrm[0], null, this.normalBatch, this.goldenBatch);

        }
      }
      this.spinner.hide();
    }, 3000);
  }

  rootCauseDataSelect() {
    this.isPca = true;
    this.rootCauseData = null;
    this.spinner.show();
    setTimeout(() => {
      this.service.getRootCauseAnalysisData(this.rootCauseAnalysisData).subscribe((resp) => {
        console.log("json strng", resp);
        this.service.getPCAData(resp).subscribe((resp) => {
          console.log("pca output", resp);
          this.rootCauseData = resp;
          let jsonLength = Object.keys(this.rootCauseData.pcadata.Scores.PC1).length;
          console.log("loading data");
          this.BatchAnalysis('chartdiv2', this.rootCauseData.pcadata.Loading, 'PC1', 'parameter');
          this.pareto(this.rootCauseData.pcadata.Explained_Variance_Ratio);

          for (let i = 0; i < jsonLength - 1; i++) {
            this.scoreData.push({ "x": this.rootCauseData.pcadata.Scores.PC1[i], "y": this.rootCauseData.pcadata.Scores.PC2[i] })
          }
          // console.log("xy data", this.scoreData);
          this.scoreCharts(this.scoreData);
        });
      });
      this.spinner.hide();
    }, 10000);
  }

  selectBatchesFrom(event: MatDatepickerInputEvent<Date>) {
    this.fromDate = event.value;
    console.log("from", this.fromDate);
    this.batchData = [];
    this.loadBatchDataFromandTo(moment(this.fromDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.toDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z");
    this.allSelected.deselect();
    console.log("newwww", this.batchData);
  }
  selectBatchesTo(event: MatDatepickerInputEvent<Date>) {
    this.toDate = event.value;
    console.log("to", this.toDate);
    this.batchData = [];
    this.loadBatchDataFromandTo(moment(this.fromDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.toDate).utc().format("YYYY-MM-DDTHH:mm:00") + "Z");
    this.allSelected.deselect();
    console.log("newwww", this.batchData);
  }

  selectCompareBatchesFrom(event) {
    this.compareBatchFrom = event.value;
    this.service.getBatchDataFromAndTo(moment(this.compareBatchFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.compareBatchTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z").subscribe((resp) => {
      this.compareBatchData = resp;
    });
  }

  selectCompareBatchesTo(event) {
    this.compareBatchTo = event.value;
    this.service.getBatchDataFromAndTo(moment(this.compareBatchFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.compareBatchTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z").subscribe((resp) => {
      this.compareBatchData = resp;
    });
  }

  selectGoldenBatchesFrom(event) {
    this.goldenBatchFrom = event.value;
    this.service.getGoldenBatchDataFromAndTo(moment(this.goldenBatchFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.goldenBatchTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z").subscribe((resp) => {
      this.goldenBatches = resp;
    });
  }

  selectGoldenBatchesTo(event) {
    this.goldenBatchTo = event.value;
    this.service.getGoldenBatchDataFromAndTo(moment(this.goldenBatchFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.goldenBatchTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z").subscribe((resp) => {
      this.goldenBatches = resp;
    });
  }

  selectCauseAnalysisBatchesFrom(event) {
    this.causeAnalysisFrom = event.value;
    this.service.getBatchDataFromAndTo(moment(this.causeAnalysisFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.causeAnalysisTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z").subscribe((resp) => {
      this.causeAnalysisBatchData = resp;
    });
  }

  selectCauseAnalysisBatchesTo(event) {
    this.compareBatchTo = event.value;
    this.service.getBatchDataFromAndTo(moment(this.causeAnalysisFrom).utc().format("YYYY-MM-DDTHH:mm:00") + "Z", moment(this.causeAnalysisTo).utc().format("YYYY-MM-DDTHH:mm:00") + "Z").subscribe((resp) => {
      this.causeAnalysisBatchData = resp;
    });
  }

}
