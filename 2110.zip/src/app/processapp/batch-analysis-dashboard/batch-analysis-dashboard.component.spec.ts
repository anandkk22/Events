import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchAnalysisDashboardComponent } from './batch-analysis-dashboard.component';

describe('BatchAnalysisDashboardComponent', () => {
  let component: BatchAnalysisDashboardComponent;
  let fixture: ComponentFixture<BatchAnalysisDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchAnalysisDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchAnalysisDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
