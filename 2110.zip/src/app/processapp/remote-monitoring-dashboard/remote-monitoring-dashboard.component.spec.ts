import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoteMonitoringDashboardComponent } from './remote-monitoring-dashboard.component';

describe('RemoteMonitoringDashboardComponent', () => {
  let component: RemoteMonitoringDashboardComponent;
  let fixture: ComponentFixture<RemoteMonitoringDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoteMonitoringDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoteMonitoringDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
