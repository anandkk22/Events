import { Component, OnInit } from '@angular/core';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import * as am4maps from '@amcharts/amcharts4/maps';
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { RemoteMonitoringServiceService } from './remote-monitoring-service.service';
import { matMenuAnimations } from '@angular/material';
import { CodeNode } from 'source-list-map';

am4core.useTheme(am4themes_animated);

@Component({
  selector: 'app-remote-monitoring-dashboard',
  templateUrl: './remote-monitoring-dashboard.component.html',
  styleUrls: ['./remote-monitoring-dashboard.component.scss']
})
export class RemoteMonitoringDashboardComponent implements OnInit {

  constructor(private service: RemoteMonitoringServiceService,
  ) { }

  portfolioKpiFirstFourResult: any = {
    kpiValue: '',
    kpiName: '',
    kpiUnit: '',
    kpiCode: ''
  }
  public results: any = [];

  public stepData: any = [];

  public lineChart: any = [];

  public gaugeData: any = [];

  public stackBar: any = [];

  public qtdData: any = {
    qtdPlanned: '',
    qtdActual: ''
  }
  public ytdData: any = {
    ytdPlanned: '',
    ytdActual: ''
  }
  public batchProcessData: any = {
    batchProcessPlanned: '',
    batchprocessCompleted: ''
  }
  public rwPumpPressure;
  public dosingPumpSpeed;
  public vacuumPumpPressure;
  public hwPumpPressure;

  public rwPumpPressureClr = '#ff6699';
  public dosingPumpSpeedClr = '#ffd633';
  public vacuumPumpPressureClr = '#00ff00';
  public hwPumpPressureClr = '#00ace6';

  public pumpInColor = '#00ace6';
  public heatUpColor = '#ff9900';
  public catalystColor = '#ffd633';
  public pumpOut = '#009900';
  public refactorColor = '#66ff66';
  public betwBatchColor = '#e65c00';

  public apolloUtilityPlants: any = [];
  apolloUtilityPlant = '';
  public userFilter: any = { displayName: '' };
  // public timeSpan: any = ['Live', 'Yesterday', 'This Month']
  // public groups: any = ['Reactor', 'Pump'];
  // public assets: any = ['Reactor01', 'Reactor02'];
  public plant: any = [{
    name: ''
  }];

  public orgBredCrumb: any = {
    processUnit:'',
    processCellName: '',
    areaName: '',
    plantName: '',
    orgName: ''
  }
  public timeSpan = 'Live';
  public timeSpans: any = ['Live', 'Yesterday', 'This Month'];
  public technicalKpis: any = ['Capacity Utilization', 'Performance', 'Quality', 'Production Volume', 'Energy Consumption', 'Sp Energy Consumption', 'Health', 'Cumulative Production'];
  public processStatusBatches: any = ['Batch21', 'Batch22', 'Batch23'];
  public processStatusTimeSpans: any = ['Last 30 Min', 'Last Hour', 'Custom'];
  public isCustom: boolean = false;
  ngOnInit() {
    // this.scrollPositionPortfolio();
    this.getAllData();

    this.service.getBredCrumbData().subscribe((resp) => {
      this.orgBredCrumb = resp;
      console.log("bred crumb", this.orgBredCrumb);
    });
  }

  getAllData() {
    this.rwPumpPressure = 2.06;
    this.vacuumPumpPressure = 3.03;
    this.hwPumpPressure = 2.2;
    this.dosingPumpSpeed = 3500;
    this.service.getQTDData().subscribe((resp) => {
      console.log("qtd", resp);
      this.qtdData = resp;
    });

    this.service.getYTDData().subscribe((resp) => {
      this.ytdData = resp;
    });

    this.service.getBatchProcessData().subscribe((resp) => {
      this.batchProcessData = resp;
    });

    this.service.getCircleProgressData().subscribe((resp) => {
      this.results = resp;
    });

    this.service.getGaugeData().subscribe((resp) => {
      this.gaugeData = resp;
      if (this.gaugeData != null) {
        this.chartShow('chartdiv', this.gaugeData[0].energy);
        this.chartShow('chartdiv12', this.gaugeData[0].energy);
        this.chartShow('chartdiv13', this.gaugeData[1].health);
        this.chartShow('chartdiv14', this.gaugeData[0].energy);
      }
    });

    this.service.getPumpInData().subscribe((resp) => {
      this.stepData = resp;
      console.log('data   jskjdlshd', this.stepData.heatUp)
      if (this.stepData != null) {
        this.stepChart('chartdiv2', this.stepData[0].pumpIn, this.pumpInColor);
        this.stepChart('chartdiv4', this.stepData[1].heatUp, this.heatUpColor);
      }
    });

    this.service.getBetwBatchData().subscribe((resp) => {
      this.stepData = resp;
      if (this.stepData != null) {
        this.stepChart('chartdiv10', this.stepData, this.betwBatchColor);
      }
    });
    this.service.getLineChartData().subscribe((resp) => {
      this.lineChart = resp;
      if (this.lineChart != null) {
        this.linechart('chartdiv1', this.lineChart[1].pressure, this.rwPumpPressureClr);
        this.linechart('chartdiv3', this.lineChart[1].pressure, this.vacuumPumpPressureClr)
        this.linechart('chartdiv5', this.lineChart[0].lineData, this.catalystColor);
        this.linechart('chartdiv6', this.lineChart[0].lineData, this.pumpOut);
        this.linechart('chartdiv7', this.lineChart[0].lineData, this.refactorColor);
        this.linechart('chartdiv8', this.lineChart[2].speed, this.dosingPumpSpeedClr);
        this.linechart('chartdiv9', this.lineChart[1].pressure, this.hwPumpPressureClr);
      }
    });

    this.service.getStackBarData().subscribe((resp) => {
      this.stackBar = resp;
      if (this.stackBar != null) {
        this.stackbarChart('chartdiv15', this.stackBar);
      }
    });

  }

  minus_plus_icon_toggle_h1() {
    const element = document.getElementById('minus-image-h1');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h1');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h2() {
    const element = document.getElementById('minus-image-h2');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h2');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h3() {
    const element = document.getElementById('minus-image-h3');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h3');
    element2.classList.toggle('d-none');
  }
  minus_plus_icon_toggle_h4() {
    const element = document.getElementById('minus-image-h4');
    element.classList.toggle('d-none');
    const element2 = document.getElementById('plus-image-h4');
    element2.classList.toggle('d-none');
  }

  scrollPositionPortfolio() {
    const elmnt = document.getElementById('scroll-position-window-top');
    elmnt.scrollIntoView();
    /* window.scrollTo(0, 0); */
  }

  chartShow(chartName, data) {
    am4core.useTheme(am4themes_animated);

    var chart = am4core.create(chartName, am4charts.GaugeChart);
    chart.innerRadius = -15;
    chart.logo.disabled = true;

    var axis = chart.xAxes.push(new am4charts.ValueAxis() as any);
    if (chartName != 'chartdiv13') {
      axis.min = 50;
      axis.max = 200;
    }
    else {
      axis.min = 50;
      axis.max = 95;
    }

    var gradient = new am4core.LinearGradient();
    gradient.stops.push({ color: am4core.color("green") })
    gradient.stops.push({ color: am4core.color("yellow") })
    gradient.stops.push({ color: am4core.color("red") })

    if (chartName != 'chartdiv14') {
      axis.renderer.line.stroke = gradient;
    }
    else {
      axis.renderer.line.stroke = am4core.color("#00e600");
    }
    axis.renderer.fontSize = 10;
    axis.renderer.line.strokeWidth = 10;
    axis.renderer.line.strokeOpacity = 1;

    axis.renderer.grid.template.disabled = true;
    axis.renderer.labels.template.fill = am4core.color('#10c3d7');

    var hand = chart.hands.push(new am4charts.ClockHand());
    hand.value = 80;  //we have to pass this
    hand.fill = am4core.color("#10c3d7");
    hand.stroke = am4core.color("#10c3d7");
  }

  linechart(id, data, chartColor) {
    var chart = am4core.create(id, am4charts.XYChart);
    chart.logo.disabled = true;

    // Add data
    chart.data = data;
    // Create axes
    // var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    // categoryAxis.dataFields.category = "hour";

    chart.dateFormatter.inputDateFormat = "hh";

    // First value axis

    // Second value axis
    var valueAxis2 = chart.yAxes.push(new am4charts.ValueAxis());
    // valueAxis2.renderer.opposite = true;

    let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
    dateAxis.baseInterval = { timeUnit: "hour", count: 1 };
    // First series

    // Second series
    var series2 = chart.series.push(new am4charts.LineSeries());
    series2.dataFields.valueY = "units";
    dateAxis.renderer.minGridDistance = 45;

    series2.dataFields.dateX = "hour";
    series2.name = "Units";
    series2.tooltipText = "{name}: [bold]{valueY}[/]";
    series2.strokeWidth = 1.5;
    series2.yAxis = valueAxis2;

    if (chartColor != null) {
      series2.propertyFields.stroke = "color";
      series2.stroke = am4core.color(chartColor);
    }
    valueAxis2.renderer.grid.template.stroke = am4core.color("#10c3d7");
    dateAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");

    dateAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    valueAxis2.renderer.labels.template.fill = am4core.color('#10c3d7');

    // Add legend
    // chart.legend = new am4charts.Legend();

    // Add cursor
    chart.cursor = new am4charts.XYCursor();
    chart.cursor.xAxis = dateAxis;
    chart.cursor.fullWidthLineX = true;
  }

  stepChart(chartName, data, chartColor) {
    let chart = am4core.create(chartName, am4charts.XYChart);
    // chart.paddingRight = 20;
    chart.logo.disabled = true;

    chart.data = data;
    chart.dateFormatter.inputDateFormat = "hh";

    let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
    dateAxis.renderer.minGridDistance = 45;
    dateAxis.baseInterval = { timeUnit: "hour", count: 1 };

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.tooltip.disabled = true;

    let series = chart.series.push(new am4charts.StepLineSeries());
    series.dataFields.dateX = "hour";
    series.dataFields.valueY = "value";
    series.tooltipText = "{valueY.value}";
    series.strokeWidth = 2;
    series.connect = false;

    if (chartColor != null) {
      series.propertyFields.stroke = "color";
      series.stroke = am4core.color(chartColor);
    }

    valueAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");
    dateAxis.renderer.grid.template.stroke = am4core.color("#10c3d7");

    dateAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    valueAxis.renderer.labels.template.fill = am4core.color('#10c3d7');

    if (chartName == 'chartdiv2') {
      valueAxis.min = 0;
      valueAxis.max = 1;
      valueAxis.strictMinMax = true;
      valueAxis.maxPrecision = 0;
    }

    if (chartName == 'chartdiv10') {
      valueAxis.min = 0;
      valueAxis.max = 7;
      valueAxis.maxPrecision = 0;
      valueAxis.renderer.minGridDistance = 20;
    }

    chart.cursor = new am4charts.XYCursor();
    chart.cursor.xAxis = dateAxis;
    chart.cursor.fullWidthLineX = true;
    chart.cursor.lineX.strokeWidth = 0;
    chart.cursor.lineX.fill = chart.colors.getIndex(2);
    chart.cursor.lineX.fillOpacity = 0.1;
  }

  stackbarChart(chartName, data) {
    var chart = am4core.create(chartName, am4charts.XYChart);
    chart.hiddenState.properties.opacity = 0; // this creates initial fade-in
    chart.logo.disabled = true;
    // valueAxis.renderer.grid.template.stroke = am4core.color("#A0CA92");

    chart.data = data;

    chart.colors.step = 2;
    // chart.legend = new am4charts.Legend();

    var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "category";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.fontSize = 10;
    categoryAxis.renderer.labels.template.fill = am4core.color('#10c3d7');
    categoryAxis.renderer.minGridDistance = 0.1;

    var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.min = 0;
    valueAxis.max = 100;
    valueAxis.calculateTotals = true;
    valueAxis.renderer.minWidth = 50;
    valueAxis.renderer.hidden = true;

    var series1 = chart.series.push(new am4charts.ColumnSeries());
    series1.columns.template.width = am4core.percent(60);
    series1.columns.template.tooltipText =
      "{valueY.totalPercent.formatNumber('#.00')}%";
    series1.name = "Series 1";
    series1.dataFields.categoryX = "category";
    series1.dataFields.valueY = "value1";
    series1.dataFields.valueYShow = "totalPercent";
    series1.dataItems.template.locations.categoryX = 0.5;
    series1.stacked = true;
    series1.tooltip.pointerOrientation = "vertical";
    series1.fill = am4core.color('#00ff00');

    var series2 = chart.series.push(new am4charts.ColumnSeries());
    series2.columns.template.width = am4core.percent(60);
    series2.columns.template.tooltipText =
      "{valueY.totalPercent.formatNumber('#.00')}%";
    series2.name = "Series 2";
    series2.dataFields.categoryX = "category";
    series2.dataFields.valueY = "value2";
    series2.dataFields.valueYShow = "totalPercent";
    series2.dataItems.template.locations.categoryX = 0.5;
    series2.stacked = true;
    series2.tooltip.pointerOrientation = "vertical";
    series2.fill = am4core.color('#3399ff');
  }

  selectProcessStatusTimeSpan(event) {
    if (event.value == 'Custom') {
      this.isCustom = true;
    }
    else {
      this.isCustom = false;
    }
  }

  loadPlants() {

  }
}
