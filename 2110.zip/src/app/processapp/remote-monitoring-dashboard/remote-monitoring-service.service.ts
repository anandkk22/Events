import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RemoteMonitoringServiceService {

  public url: string = "./assets/json/";
  public apiUrl = environment.PROCESS_API_URL + 'api/';

  constructor(private http: HttpClient) { }

  getPumpInData() {
    return this.http.get(this.url + "step-graph.json");
  }

  getQTDData() {
    return this.http.get(this.url + "/qtd.json");
  }

  getYTDData() {
    return this.http.get(this.url + "/ytd.json");
  }

  getBatchProcessData() {
    return this.http.get(this.url + "/batchProcess.json");
  }

  getCircleProgressData() {
    return this.http.get(this.url + "/circleChart.json");
  }

  getLineChartData() {
    return this.http.get(this.url + "/line-graph.json");
  }

  getGaugeData() {
    return this.http.get(this.url + "/gauge.json");
  }

  getBetwBatchData() {
    return this.http.get(this.url + "/betw-batch.json");
  }
  getStackBarData() {
    return this.http.get(this.url + "/stackBar.json");
  }

  // getPlantData() {
  //   return this.http.get(this.apiUrl +"api/plant/org/3");
  // }

  getBredCrumbData(): Observable<any>  {
    return this.http.get<any>(this.apiUrl + "org/plant/area/processCell/processUnit/1");
  }
}
