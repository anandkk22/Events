import { TestBed } from '@angular/core/testing';

import { EnergyServiceService } from './energy-service.service';

describe('EnergyServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EnergyServiceService = TestBed.get(EnergyServiceService);
    expect(service).toBeTruthy();
  });
});
