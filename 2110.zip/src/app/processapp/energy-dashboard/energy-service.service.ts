import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnergyServiceService {

  public apiUrl = environment.PROCESS_API_URL + 'api/';
  public cncUrl = environment.CNC_API_URL + 'api/';

  public url: string = "./assets/json/";

  constructor(private http: HttpClient) { }

  getBredCrumbData(): Observable<any> {
    return this.http.get<any>(this.apiUrl + "org/plant/area/processCell/processUnit/1");
  }
  getLineChartData() {
    return this.http.get(this.url + "batchProcess.json");
  }

  getAreaByPlantId(plantId) {
    return this.http.get<any>(this.cncUrl + "area/plant/" + plantId);
  }

  getProductionLineByAreaId(id) {
    return this.http.get<any>(this.cncUrl + "productionLine/area/" + id);
  }

  getWorkCellByProductionLineId(id) {
    return this.http.get<any>(this.cncUrl + "workCell/productionLine/" + id);
  }

  getMachineByWorCellId(id) {
    return this.http.get<any>(this.cncUrl + "machine/workCell/" + id);
  }

  getActivePowerData(equipId, from, to): Observable<any> {

    return this.http.get<any>(`${this.cncUrl}active-power/${equipId}?startTime=${from}&endTime=${to}`);
    // return this.http.get<any>(this.url + "batchProcess.json");

  }

  getMonthlyPowerCut(plantId, year): Observable<any> {
    return this.http.get<any>(this.cncUrl + "getMonthlyPowerCut/" + plantId + '/' + year);
  }

  getPlant() {
    return this.http.get<any>(this.apiUrl + "plant/65");
  }

  getProductionRejection(plantId, from, to): Observable<any> {

    return this.http.get<any>(`${this.cncUrl}production-rejection/${plantId}?from=${from}&to=${to}`);

  }

  getUtilityConsumption(plantId, areaId, from, to): Observable<any> {

    return this.http.get<any>(`${this.cncUrl}plantUtilityEnergyConsumption/${plantId}/${areaId}?from=${from}&to=${to}`);

  }

  getShopFloorConsumption(plantId, areaId, from, to): Observable<any> {

    return this.http.get<any>(`${this.cncUrl}shopFloorConsumptionProduction/${plantId}/${areaId}?from=${from}&to=${to}`);

  }

  getEnergyConsumptionByArea(plantId, from, to): Observable<any> {

    return this.http.get<any>(`${this.cncUrl}energyConsumptionByArea/${plantId}?from=${from}&to=${to}`);

  }

  getQuarterData(plantId, year): Observable<any> {
    return this.http.get<any>(this.cncUrl + "quarterWiseData/" + plantId + '/' + year);
  }

  getConsumptionWithArea(plantId, year): Observable<any> {
    return this.http.get<any>(this.cncUrl + "consumptionWithArea/" + plantId + '/' + year);
  }

  getMTDValue(plantId, from, to): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}mtd/${plantId}?from=${from}&to=${to}`);
  }

  getAvgDaily(plantId, from, to): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}avgDaily/${plantId}?from=${from}&to=${to}`);
  }

  getSpecificEnergy(plantId, from, to): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}specificEnergy/${plantId}?from=${from}&to=${to}`);
  }

  overAllConsumption(plantId, from, to): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}overAllEnergyConsumption/${plantId}?from=${from}&to=${to}`);
  }

  getLastMonth(plantId, from, to): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}lastMonth/${plantId}?from=${from}&to=${to}`);
  }

  getLastYear(plantId, year): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}lastYear/${plantId}/${year}`);
  }

  getSankeyDataplantId(plantId, from, to): Observable<any> {
    return this.http.get<any>(`${this.cncUrl}energyDistribution/${plantId}?from=${from}&to=${to}`);
  }
}