import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { PlantsComponent } from "./plants/plants.component";
import { CategoriesComponent } from "./categories/categories.component";
import { PlantDetailsComponent } from "./plants/plant-details/plant-details.component";
import { ScheduleComponent } from "./schedule/schedule.component";
import { EquipmentComponent } from "./equipment/equipment.component";
import { IdeComponent } from "./equipment/ide/ide.component";
import { AddPlantComponent } from "./plants/add-plant/add-plant.component";
import { PlantConfigurationComponent } from "./plants/plant-configuration/plant-configuration.component";
import { AreaComponent } from "./plants/plant-configuration/area/area.component";
import { ProcessCellComponent } from "./plants/plant-configuration/process-cell/process-cell.component";
import { SidenavComponent } from './shared/sidenav/sidenav.component';
import { ProcessUnitComponent } from './plants/plant-configuration/process-unit/process-unit.component';
import { ReactorComponent } from './plants/plant-configuration/reactors/reactors.component';
import { PumpsComponent } from './plants/plant-configuration/pumps/pumps.component';
import { LibraryComponent } from './library/library.component';
import { EquipmentMeasurementDataComponent } from './library/parameter-tags/equipment-measurement-data/equipment-measurement-data';

import { ProductionLiveDashboardComponent } from './production-live-dashboard/production-live-dashboard.component';
import { PlanningDashboardComponent } from './planning-dashboard/planning-dashboard.component';
import { CncMachineComponent } from './plants/plant-configuration/cnc-machine/cnc-machine.component';
import { OperatorDashboardComponent } from './operator-dashboard/operator-dashboard.component';
import { AgitatorsComponent } from './plants/plant-configuration/agitators/agitators.component';
import { CentrifugesComponent } from './plants/plant-configuration/centrifuges/centrifuges.component';
import { CompressorsComponent } from './plants/plant-configuration/compressors/compressors.component';
import { ReferenceKPIComponent } from './library/parameter-tags/reference_KPI_family/reference-kpi-family';
import { RemoteMonitoringDashboardComponent } from './processapp/remote-monitoring-dashboard/remote-monitoring-dashboard.component';
import { BatchAnalysisDashboardComponent } from './processapp/batch-analysis-dashboard/batch-analysis-dashboard.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { RoleManagementComponent } from './user-management/role-managment/role-management.component';
import { PermissionManagementComponent } from './user-management/permission-management/permission-management.component';
import { AdminPanelFrontPage } from './user-management/admin-panel-frontPage';
import { EnergyDashboardComponent } from './processapp/energy-dashboard/energy-dashboard.component';
import { ViewPermissionComponent } from './user-management/permission-management/view/view-permission-management';
import { CreatePermissionComponent } from './user-management/permission-management/create/create-permission-management';
import { EditPermissionComponent } from './user-management/permission-management/edit/edit-permission-management';
import { ProductConfigurationComponent } from './product-configurator/product-configurator.component';
import { productFamilyComponent } from './product-configurator/product-family/product-family.component';
import { Product } from './product-configurator/product/product.component';
import { ComponentProduct } from './product-configurator/component-product/component-product';
import { MoldMasterComponent } from './product-configurator/mold-master/mold-master.component';
import { InjectionMoldComponent } from './plants/plant-configuration/injection-mold/injection-mold.component';
import { InjectionMoldingMachineComponent } from './plants/plant-configuration/injection-molding-machine/injection-molding-machine.component';
import { ProductionLineComponent } from './plants/plant-configuration/production-line/production-line.component';
import { ManufacturingProcessComponent } from './library/parameter-tags/manufacturing-process/manufacturing-process.component';
import { AssemblyProcessComponent } from './library/parameter-tags/assembly-process/assembly-process.component';
import { PlanteventsComponent } from './plantevents/plantevents/plantevents.component';
import { ManufacturingOperationComponent } from './product-configurator/manufacturing-operation/manufacturing-operation.component';
import { AddProduct } from './product-configurator/product/add-product/add-product.component';
import { OrganizationManagementComponent } from './user-management/organization-management/organization-management.component';
import { CreateOrganizationComponent } from './user-management/organization-management/create-organization';
import { CreateUserManagementComponent } from './user-management/create/create-user-management';
import { AddComponent } from './product-configurator/component-product/add/add-component.component';
import { UserProfileComponent } from './user-management/user-profile/user-profile.component';
import { CreateUserProfileComponent } from './user-management/user-profile/create-user-profile';
import { OrganizationRoleManagementComponent } from './user-management/organization-role-management/organization-role-management.component';
import { CreateOrganizationRoleComponent } from './user-management/organization-role-management/create-organization-role';
import { AccessMenuComponent } from './user-management/access-menu/access-menu.component';
import { PlantOrgRelationComponent } from './user-management/plant-org-relation/plant-org-relation.component';
import { CreatePlantOrgRelComponent } from './user-management/plant-org-relation/create-plant-org-relation';
import { DiscreteOperatorDashboardComponent } from './discrete-operator-dashboard/discrete-operator-dashboard.component';


const routes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  {
    path: "plants",
    component: PlantsComponent,
  },
  {
    path: "edit-plant/:id",
    component: AddPlantComponent,
  },
  {
    path: "category",
    component: CategoriesComponent,
  },

  {
    path: "dashboard",
    component: RemoteMonitoringDashboardComponent,
  },
  {
    path: "batch-analysis",
    component: BatchAnalysisDashboardComponent
  },
  {
    path: "plant-events",
    component: PlanteventsComponent
  },

  {
    path: "energy",
    component: EnergyDashboardComponent
  },
  {
    path: "discrete-app",
    component: ProductionLiveDashboardComponent
  },
  {
    path: "operator-dashboard/:id",
    component: OperatorDashboardComponent
  },
  {
    path: "discrete-operator-dashboard",
    component: DiscreteOperatorDashboardComponent
  },
  {
    path: "planning-dashboard",
    component: PlanningDashboardComponent
  },
  {
    path: "plant-details/:id",
    component: PlantDetailsComponent,
  },
  {
    path: "equipment",
    component: EquipmentComponent,
  },
  {
    path: "ide",
    component: IdeComponent,
  },
  {
    path: "schedule",
    component: ScheduleComponent,
  },
  {
    path: "plantConfig/:id",
    component: PlantConfigurationComponent,
    children: [
      {
        path: "area",
        component: AreaComponent,
      },
      {
        path: "processcell",
        component: ProcessCellComponent,
      },
      {
        path: "processunit",
        component: ProcessUnitComponent,
      },
      {
        path: "production-line",
        component: ProductionLineComponent,
      },
      {
        path: "reactor",
        component: ReactorComponent,
      },
      {
        path: "pump",
        component: PumpsComponent,
      },
      {
        path: "agitator",
        component: AgitatorsComponent,
      },
      {
        path: "compressor",
        component: CompressorsComponent,
      },
      {
        path: "centrifuge",
        component: CentrifugesComponent,
      },
      {
        path: "cnc-machine",
        component: CncMachineComponent
      },
      {
        path: "injection-mold",
        component: InjectionMoldComponent
      },
      {

        path: "injection-molding-machine",
        component: InjectionMoldingMachineComponent
      }

    ],
  },
  {
    path: "library",
    component: LibraryComponent
  },
  {
    path: "equipment-measurement-data",
    component: EquipmentMeasurementDataComponent
  },
  {
    path: 'kpi-performance-indicator',
    component: ReferenceKPIComponent
  },
  {
    path: 'manufacturing-process',
    component: ManufacturingProcessComponent
  },
  {
    path: 'assembly-process',
    component: AssemblyProcessComponent
  },
  {
    path: 'user-management',
    children: [
      {
        path: '',
        component: UserManagementComponent,
      },

      {
        path: 'new',
        component: CreateUserManagementComponent
      },
      {
        path: ':login/edit',
        component: CreateUserManagementComponent
      },
      {
        path: ':login/view',
        component: CreateUserManagementComponent
      },
    ]
  },
  {
    path: 'role-management',
    component: RoleManagementComponent
  },
  {
    path: 'permission-management',
    component: PermissionManagementComponent
  },
  {
    path: 'plant-org-rel',
    children: [
      {
        path: '',
        component: PlantOrgRelationComponent
      },

      {
        path: 'new',
        component: CreatePlantOrgRelComponent
      },
      {
        path: ':id/edit',
        component: CreatePlantOrgRelComponent
      },
      {
        path: ':id/view',
        component: CreatePlantOrgRelComponent
      },
    ]
  },
  {
    path: 'user-profile',
    children: [
      {
        path: '',
        component: UserProfileComponent,
      },

      {
        path: 'new',
        component: CreateUserProfileComponent
      },
      {
        path: ':id/edit',
        component: CreateUserProfileComponent
      },
      {
        path: ':id/view',
        component: CreateUserProfileComponent
      },
    ]
  },
  {
    path: 'organization-role',
    children: [
      {
        path: '',
        component: OrganizationRoleManagementComponent,
      },

      {
        path: 'new',
        component: CreateOrganizationRoleComponent
      },
      {
        path: ':id/edit',
        component: CreateOrganizationRoleComponent
      },
      {
        path: ':id/view',
        component: CreateOrganizationRoleComponent
      },
    ]
  },
  {
    path: 'organization',
    children: [
      {
        path: '',
        component: OrganizationManagementComponent,
      },

      {
        path: 'new',
        component: CreateOrganizationComponent
      },
      {
        path: ':id/edit',
        component: CreateOrganizationComponent
      },
      {
        path: ':id/view',
        component: CreateOrganizationComponent
      },
    ]
  },

  {
    path: 'adminpanel-accessmanagement',
    component: AccessMenuComponent
  },
  {
    path: 'createNewPermission',
    component: CreatePermissionComponent
  },
  {
    path: 'viewPermissionComponent/:id',
    component: ViewPermissionComponent
  },
  {
    path: 'editNewPermission/:id',
    component: EditPermissionComponent
  },
  {
    path: "productConfig",
    component: ProductConfigurationComponent,
    children: [
      {
        path: 'manufacturing-operation',
        component: ManufacturingOperationComponent
      },
      {
        path: 'productFamily',
        component: productFamilyComponent
      },
      {
        path: 'product',
        component: Product
      },
      {
        path: 'component',
        component: ComponentProduct
      },
      {
        path: 'moldMaster',
        component: MoldMasterComponent
      }
    ]
  },
  {
    path: 'add-product',
    component: AddProduct
  },
  {
    path: 'add-product/:id',
    component: AddProduct
  },
  {
    path: 'add-component',
    component: AddComponent
  },
  {
    path: 'add-product/:id',
    component: AddProduct
  },
  {
    path: 'add-component/:id',
    component: AddComponent
  }

];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
