import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { LoginService } from '../core/login/login.service';
import { UserPreferenceSetting } from '../header/user-preference-setting/user-preference-setting';
import { UserProfile } from '../header/user-profile/user-profile';
import { OrganizationManagementService } from '../user-management/organization-management/organization-management.service';
import { UserManagementService } from '../user-management/user-management.service';


@Component({
    selector: 'app-dashoboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss', '../header/header.component.scss']
})
export class Dashboard implements OnInit {
    todaysDate = new Date();
    showDashaboard: boolean = false;
    planingDashboard: string = '';
    productionDashboard: string = '';
    matDialogRefuserSettings: MatDialogRef<UserPreferenceSetting>;
    matDialogRef: MatDialogRef<UserProfile>;
    userProfile: any;
    organization: any;
    userId: any;
    login: any;
    user: any;

    constructor(private _router: Router, private matDialog: MatDialog,
        private service: LoginService, private orgService: OrganizationManagementService,
        private userService: UserManagementService, private router: Router) { }

    ngOnInit() {
        this.planingDashboard = 'Planning Dashboard';
        this.productionDashboard = 'Production Dashboard';
        this.login = localStorage.getItem('login');
        this.userService.getUserById(this.login).subscribe((resp) => {
            this.user = resp;
            console.log("useeee", this.user);
        });
        this.userId = localStorage.getItem('userId');
        this.service.getUserProfileByUserId(this.userId).subscribe((resp) => {
            this.userProfile = resp;
            console.log("profillee", this.userProfile);
            if (this.userProfile != null) {
                this.orgService.getOrganizationById(this.userProfile.organisationId).subscribe((resp) => {
                    this.organization = resp;
                    console.log("profillee22", this.organization);
                });
            }
        });
    }

    showDashboard() {
        this.showDashaboard = !this.showDashaboard;
    }

    categoryPage() {
        this._router.navigate(['/category']);
    }

    openUserProfileSetting(): void {
        this.matDialogRefuserSettings = this.matDialog.open(UserPreferenceSetting, {
            panelClass: ['dark-theme-dialog-container-large-dialog-left'],
        });
    }

    openUserProfile(): void {
        this.matDialogRef = this.matDialog.open(UserProfile, {
            panelClass: ['dark-theme-dialog-container-large-dialog-left'],
        });
    }
    productionLive() {
        this.router.navigate(['discrete-app']);
    }

    planningDashboard() {
        this.router.navigate(['planning-dashboard']);
    }

    energy() {
        this.router.navigate(['energy']);
    }


}