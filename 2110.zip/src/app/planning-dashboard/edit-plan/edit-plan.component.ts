import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-plan',
  templateUrl: './edit-plan.component.html',
  styleUrls: ['./edit-plan.component.scss']
})
export class EditPlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
