import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PlanningDashboardService {

  editPlanData;

  private currentEditPlanValue = new BehaviorSubject({});

  updatedEditPlanMessage = this.currentEditPlanValue.asObservable();

  constructor(private _http: HttpClient, public dialog: MatDialog) { }

  public changeEditPlanMessage(editplan) {
    console.log("Editplan object: ", editplan);
    this.currentEditPlanValue.next(editplan);
  }
  public saveEditPlanData(data) {
    this.editPlanData = data;
  }

  // public getProdutionPlanSchedules() {
  //     return this._http.get(environment.CNC_API_URL + "api/mfgconnect-production-schedules");
  // }

  // public getMaintenancePlan() {
  //     return this._http.get(environment.CNC_API_URL + "api/mfgconnect-maintainence-schedules");
  // }

  // public getToolChange() {
  //     return this._http.get(environment.CNC_API_URL + "api/mfgconnect-tool-schedules");
  // }
  // public getMachineDownTime() {
  //     return this._http.get(environment.CNC_API_URL + "api/mfgconnect-equipment-downtimes");
  // }
  public getCNCMachines() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-cnc-machines");
  }
  //list of apis to get planned data:
  public getProdutionSchedulesPlan() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-production-schedule/planned-status");
  }
  public getMaintenanceSchedulePlan() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-maintainence-schedule/planned-status");
  }
  public getToolSchedulePlan() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-tool-schedule/planned-status");
  }

  //api to get production schedule data with status running:
  public getProdutionSchedules() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-production-schedule/running-status");
  }
  //api to get maintenance schedule with status undergoing:
  public getMaintenanceSchedule() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-maintainence-schedule/undergoing-status");
  }
  //api to get tool schedule with status running:
  public getToolSchedule() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-tool-schedule/running-status");
  }

  //apis to get equipment downtime with status started or over
  public getEquipmentDowntime() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-equipment-downtime/started-status");
  }
  public getEquipmentDowntimeOver() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-equipment-downtime/over-status");
  }

  //get all apis for all the schedules
  public getAllProductionSchedules() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-production-schedules");
  }

  public getAllMaintenanceSchedules() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-maintainence-schedules")
  }

  public getAllToolSchedules() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-tool-schedules")
  }

  public getAllEquipmentDowntime() {
    return this._http.get(environment.CNC_API_URL + "api/mfgconnect-equipment-downtimes")
  }

}
